
/* dummy module psym.c */

/* used in place of putsymx.c */

double dscaln;

getln()

{}

putsymc()
{}

putsymx()
{}

