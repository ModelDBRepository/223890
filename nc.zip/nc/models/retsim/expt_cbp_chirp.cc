/* Experiment cbp_cclamp */
/*  for nc script retsim.cc */

#include <stdio.h>
#include <string.h>
#include <math.h>
#include <sys/types.h>
#include <unistd.h>
#include "ncfuncs.h"
#include "retsim.h"
#include "retsim_var.h"
#include "ncio.h"
#include "stimfuncs.h"




int ct;
int ct2 = -1;
int ivplot;
int elnode;
int bp_morph;
int set_cones;
int amarr;

int stimloc;

#define R8 8

int tip1 = R8*100+1;
int tip2 = R8*100+2;
int tip3 = R8*100+3;
int tip4 = R8*100+4;
int tip5 = R8*100+5;
int tip6 = R8*100+6;
int tip7 = R8*100+7;
int tip8 = R8*100+8;
int tip9 = R8*100+9;
int tip10 = R8*100+10;
int tip11 = R8*100+11;
int tip12 = R8*100+12;
int tip13 = R8*100+13;
int tip14 = R8*100+14;
int tip15 = R8*100+15;
int tip16 = R8*100+16;
int tip17 = R8*100+17;
int tip18 = R8*100+18;
int tip19 = R8*100+19;
int tip20 = R8*100+20;
int tip21 = R8*100+21;
int tip22 = R8*100+22;
int tip23 = R8*100+23;
int tip24 = R8*100+24;
int tip25 = R8*100+25;
int tip26 = R8*100+26;
int tip27 = R8*100+27;
int tip28 = R8*100+28;
int tip29 = R8*100+29;
int tip30 = R8*100+30;
int recpnt1;
int recpnt2;
int recpnt3;
int recpnt4;
int recpnt5;
int recpnt6;
int recpnt7;
int recpnt8;
int recpnt9;
int presyn1;
int presyn2;
int ampar;
int ampar2;
int dbp1_am;
int dbp2_am;

const char *cbptype;
const char *cbptype2;

double kdr_cond;
double dbp1_gtau;
double dbp2_gtau;
double am_sdur;
double am2_sdur;
double am_atau;
double am2_atau;
double g_am;
double g_am2;
double g_dbp1;
double g_dbp2;

double drmab;
double driab;
double dria;
double dvreva;
double dcmab;
double axdia;
double ddia;
double naax;
double naab;
double nahd;
double ksoma;
double cadist;
double set_drm;
double dbp1_soma_z;
double dbp2_soma_z;
double spacing;
double c2rot;
double c2yrot;

double varicos_dia;

double predur;
double prestimdur;
double spotdur;
double stimdur;
double tailcurdur;
double poststimdur;
double stimtime;
double temp_freq;
double spotdia;

double fstart;
double fincr;
double c1;
double c2;
double cmult;
double minten;

double istart;
double istop;
double istep;
double ipre;
double itail;
double dci;
double scontrast;

double voltage;
double current;
double maxCurrent;
double pscal;
double elec_rs;
double elec_cap;




char savefile[30] = {0};

/*------------------------------------------------------*/

void defparams(void) { 

  setptr("cbptype",	&cbptype);
  setptr("cbptype2",	&cbptype2);
  setptr("ivplot",	&ivplot);
  setptr("bp_morph",	&bp_morph);
  setptr("set_cones",	&set_cones);
  setptr("amarr",	&amarr);
  setptr("dbp1_am",	&dbp1_am);
  setptr("dbp2_am",	&dbp2_am);

  setptrn("tip1",	&tip1);		/* Use predefined values (801,802, etc) from above, */
  setptrn("tip2",	&tip2);		/*  but allow user to change on command line.       */
  setptrn("tip3",	&tip3);
  setptrn("tip4",	&tip4);
  setptrn("tip5",	&tip5);
  setptrn("tip6",	&tip6);
  setptrn("tip7",	&tip7);
  setptrn("tip8",	&tip8);
  setptrn("tip9",	&tip9);
  setptrn("tip10",	&tip10);
  setptrn("tip11",	&tip11);
  setptrn("tip12",	&tip12);
  setptrn("tip13",	&tip13);
  setptrn("tip14",	&tip14);
  setptrn("tip15",	&tip15);
  setptrn("tip16",	&tip16);
  setptrn("tip17",	&tip17);
  setptrn("tip18",	&tip18);
  setptrn("tip19",	&tip19);
  setptrn("tip20",	&tip20);
  setptrn("tip21",	&tip21);
  setptrn("tip22",	&tip22);
  setptrn("tip23",	&tip23);
  setptrn("tip24",	&tip24);
  setptrn("tip25",	&tip25);
  setptrn("tip26",	&tip26);
  setptrn("tip27",	&tip27);
  setptrn("tip28",	&tip28);
  setptrn("tip29",	&tip29);
  setptrn("tip30",	&tip30);

  setptr("stimloc",	&stimloc);
  setptr("recpnt1",	&recpnt1);
  setptr("recpnt2",	&recpnt2);
  setptr("recpnt3",	&recpnt3);
  setptr("recpnt4",	&recpnt4);
  setptr("recpnt5",	&recpnt5);
  setptr("recpnt6",	&recpnt6);
  setptr("recpnt7",	&recpnt7);
  setptr("recpnt8",	&recpnt8);
  setptr("recpnt9",	&recpnt9);
  setptr("presyn1",	&presyn1);
  setptr("presyn2",	&presyn2);

  setptr("set_drm",     &set_drm);
  setptr("drmab",       &drmab);
  setptr("driab",       &driab);
  setptr("dria",        &dria);
  setptr("dvreva",      &dvreva);
  setptr("dcmab",       &dcmab);
  setptr("axdia",       &axdia);
  setptr("ddia",        &ddia);
  setptr("naax",        &naax);
  setptr("naab",        &naab);
  setptr("nahd",        &nahd);
  setptr("ksoma",	&ksoma);
  setptr("cadist",	&cadist);
  setptr("kdr_cond",    &kdr_cond);
  setptr("g_am",        &g_am);
  setptr("g_am2",       &g_am2);
  setptr("g_dbp1",      &g_dbp1);
  setptr("g_dbp2",      &g_dbp2);

  setptr("varicos_dia", &varicos_dia);
  setptr("am_sdur",     &am_sdur);
  setptr("am2_sdur",    &am2_sdur);
  setptr("am_atau",     &am_atau);
  setptr("am2_atau",    &am2_atau);
  setptr("dbp1_gtau",   &dbp1_gtau);
  setptr("dbp2_gtau",   &dbp2_gtau);
  setptr("ampar",       &ampar);
  setptr("ampar2",      &ampar2);

  setptr("dbp1_soma_z",	&dbp1_soma_z);
  setptr("dbp2_soma_z",	&dbp2_soma_z);
  setptr("spacing",     &spacing);
  setptr("c2rot",       &c2rot);
  setptr("c2yrot",      &c2yrot);

  setptr("predur",	&predur);
  setptr("prestimdur",	&prestimdur);
  setptr("spotdur",	&spotdur);
  setptr("stimdur",	&stimdur);
  setptr("tailcurdur",	&tailcurdur);
  setptr("poststimdur",	&poststimdur);
  setptr("spotdia",	&spotdia);

  setptr("stimtime",	&stimtime);
  setptr("temp_freq",	&temp_freq);
  
  setptr("fstart",	&fstart);
  setptr("fincr",	&fincr);
  setptr("c1",		&c1);
  setptr("c2",		&c2);
  setptr("cmult",	&cmult);
  setptr("minten",	&minten);

  setptr("istart",	&istart);
  setptr("istop",	&istop);
  setptr("istep",	&istep);
  setptr("ipre",	&ipre);
  setptr("itail",	&itail);
  setptr("dci",		&dci);
  setptr("scontrast",	&scontrast);

  setptr("maxCurrent", &maxCurrent);
  setptr("pscal", &pscal);

  nvalfile = "nval_cbp_chirp.n";
  chanparamsfile = "chanparams_cbp_chirp";

  // dbp1_file = "morph_bp";			// default set in retsim.cc 
  // dbp1_file = "morph_DB_111005_12_db4";	// morphology file in retsim.cc 
  // dbp1_file = "cell504_t4";			// morphology file in retsim.cc 
  dbp1_file = "morph_cbp_0572_t5r";		// morphology file in retsim.cc 
  dbp2_file = "morph_cbp_0572_t5r";		// morphology file in retsim.cc 
  hbp1_file = "morph_cbp_0572_t5r";		// morphology file in retsim.cc 

  dbp1_densfile  = "dens_cbp_chirp.n";		// cbplam
  dbp1_densfile2 = "dens_cbp_chirpc.n";		// cbplam2
  dbp2_densfile  = "dens_cbp_chirpc.n";
  dbp2_densfile2 = "dens_cbp_chirpc.n";
  hbp1_densfile  = "dens_cbp_chirp.n";
  hbp1_densfile2 = "dens_cbp_chirpc.n";

  if (notinit(g_am))   g_am = 5e-10; 		/* am cond, feedback to dbp1, nval_cbp_chirp.n */
  if (notinit(g_am2)) g_am2 = 5e-10; 		/* am2 cond, feedback to dbp2, nval_cbp_chirp.n */
  if (notinit(g_dbp1)) g_dbp1 = 8e-10; 		/* dbp1 cond, output to am, nval_cbp_chirp.n */
  if (notinit(g_dbp2)) g_dbp2 = 8e-10; 		/* dbp2 cond, output to am, am2, nval_cbp_chirp.n */
  if (notinit(presyn1)) presyn1 = 807; 	 	/* label for morphology filep_chirp.n */
  if (notinit(presyn2)) presyn2 = 803; 	 	/* label for morphology filep_chirp.n */
  if (notinit(dbp1_gtau)) dbp1_gtau = 1; 	/* tau multiplier for GABA1 channel in dbp1 */
  if (notinit(dbp2_gtau)) dbp2_gtau = 1; 	/* tau multiplier for GABA1 channel in dbp2 */
  if (notinit(am_atau))     am_atau  = 15; 	/* tau multiplier for AMPA1 channel in am */
  if (notinit(am2_atau))    am2_atau = 15; 	/* tau multiplier for AMPA1 channel in am2 */
  if (notinit(am_sdur))     am_sdur  = 1; 	/* sdur for GABA am->dbp1 synapse */
  if (notinit(am2_sdur))    am2_sdur = 1; 	/* sdur for GABA am2->dbp1 synapse */
  if (notinit(ampar))      ampar  = xampa; 	/* AMPA response (=2) for dbp1->am synapse */
  if (notinit(ampar2))     ampar2 = xampa; 	/* AMPA response (=2) for dbp1->am synapse */

  make_dbp1_am2 = 0;
  make_dbp2_am  = 0;
  make_am2_dbp1 = 1;		/* lateral feedback from second amacrine type to the first bp type */

}

/*------------------------------------------------------*/

int makrow (int ncells, double spacing, double rowtheta, double xloc, double yloc, double zrot, 
		double  *xarr, double *yarr, double *tharr, double dist, int skip, int i)

/* make one row of cells along an orientation */

{
  int j,s;

  s = skip - 1;
  for (j=0;j<ncells; i++,j++) {
       if (j==s) {i--; continue;}
       xarr[i]  = -cosdeg(rowtheta) * (-j*spacing + dist) + xloc;
       yarr[i]  =  sindeg(rowtheta) * (-j*spacing + dist) + yloc;
       tharr[i] = zrot-rowtheta;
  }
  return i;
}

/* - - - - - - - - - - - - - - - - - - - */

int dbp1row (int ncells, double spacing, double rowtheta, double zrot, double xloc, double yloc, int skip, int i)
{
      double dist;		// radial distance from (xloc, yloc)

    return makrow (ncells, spacing, rowtheta, xloc, yloc, zrot, dbp1xarr, dbp1yarr, dbp1tharr, dist=(skip-1)*spacing, skip, i);
}

/* - - - - - - - - - - - - - - - - - - - */

int dbp1row (int ncells, double spacing, double rowtheta, double zrot, int skip, int i)
{
      double dist;		// radial distance from (xloc, yloc)

    return makrow (ncells, spacing, rowtheta, 0, 0, zrot, dbp1xarr, dbp1yarr, dbp1tharr, dist=(skip-1)*spacing, skip, i);
}

/* - - - - - - - - - - - - - - - - - - - */

int dbp2row (int ncells, double spacing, double rowtheta, double zrot, double xloc, double yloc, int skip, int i)
{
      double dist;		// radial distance from (xloc, yloc)

    return makrow (ncells, spacing, rowtheta, xloc, yloc, zrot, dbp2xarr, dbp2yarr, dbp2tharr, dist=(skip-1)*spacing, skip, i);
}

/* - - - - - - - - - - - - - - - - - - - */

int dbp2row (int ncells, double spacing, double rowtheta, double zrot, double dist, int skip, int i)
{

    return makrow (ncells, spacing, rowtheta, 0, 0, zrot, dbp2xarr, dbp2yarr, dbp2tharr, dist, skip, i);
}

/* - - - - - - - - - - - - - - - - - - - */

int dbp2row (int ncells, double spacing, double rowtheta, double zrot, int skip, int i)
{
      double dist;		// radial distance from (xloc, yloc)

    return makrow (ncells, spacing, rowtheta, 0, 0, zrot, dbp2xarr, dbp2yarr, dbp2tharr, dist=(skip-1)*spacing, skip, i);
}

/* - - - - - - - - - - - - - - - - - - - */

int dbp1cent (int ncells, double theta, double zrot, int skip, int i)
{
      double spacing;		// cell spacing along row (here, none)
      double dist;		// radial distance from (xloc, yloc)

    return makrow (ncells, spacing=0, theta, 0, 0, zrot, dbp1xarr, dbp1yarr, dbp1tharr, dist=0, skip, i);
}
/* - - - - - - - - - - - - - - - - - - - */

int dbp2cent (int ncells, double theta, double zrot, int skip, int i)
{
      double spacing;		// cell spacing along row (here, none)
      double dist;		// radial distance from (xloc, yloc)

    return makrow (ncells, spacing=0, theta, 0, 0, zrot, dbp2xarr, dbp2yarr, dbp2tharr, dist=0, skip, i);
}
/* - - - - - - - - - - - - - - - - - - - */

int make_am_cell (double theta, int i, double somadist)
{

   make_ct(am);
   amxarr[i]  = -cosdeg(theta) * somadist;
   amyarr[i]  =  sindeg(theta) * somadist;
   amtharr[i++] = theta;
   return (i);
}

/* - - - - - - - - - - - - - - - - - - - */

int make_am2_cell (double theta, int i, double somadist)
{
   make_ct(am2);
   am2xarr[i]  = -cosdeg(theta) * somadist;
   am2yarr[i]  =  sindeg(theta) * somadist;
   am2tharr[i++] = theta;
   return (i);
}

/*------------------------------------------------------*/
   
void setparams(void)
{
#define CBPARR 100
#define AMARR  20

     int i,j,k, dist, sk, skip;
     double theta;						/* orientation of amacrine cell to follow */
     double dbp1_zrot=60, dbp2_zrot=0; 				/* rotation of cell at amacrine cell */


  if (!notinit(set_cones)) {
      make_cones = set_cones;
  }
  if (!notinit(cbptype)) {			/* primary cbp type */
       ct = find_ct(cbptype);
  } else {
       ct = dbp1;
  }

  if (!notinit(cbptype2)) {			/* secondary cbp type */
       ct2 = find_ct(cbptype2);
  }

  if (!notinit(dbp1_soma_z)) setn(dbp1,SOMAZ,dbp1_soma_z);
  if (!notinit(dbp2_soma_z)) setn(dbp2,SOMAZ,dbp2_soma_z);
  if (notinit(spacing)) spacing = 40;

  make_ct(ct);
  if (ct2>0) make_ct(ct2);

  SOMA = R_3;			/* defined in retsim_var.cc, retsim.h */

  if (notinit(dbp1_nscale)) dbp1_nscale = -2.09;
  if (notinit(dbp2_nscale)) dbp2_nscale = -2.09;

  if (notinit(dbp1_am)) dbp1_am = 11;
  if (notinit(amarr)) amarr = 0;

  if (amarr == 0) {
	  skip = int((dbp1_am+1)/2);			/* skip the central dbp (when needed) */
          dbp1xarr   = (double *)emalloc(CBPARR*sizeof(double));   /* used by makrow() above */
          dbp1yarr   = (double *)emalloc(CBPARR*sizeof(double));
          dbp1tharr  = (double *)emalloc(CBPARR*sizeof(double));
	  dbp1cent (1,      theta=  0,   dbp1_zrot,   sk=0, i=0);
  }

  switch (amarr) {						/* set up dbp1s */

     case 0: 
	if      (n_dbp1<=1) { } 
	else if (n_dbp1==2) {
	  dbp1xarr[0] = 0;
	  dbp1yarr[0] = 0;
	  dbp1tharr[0] = 0;
	  dbp1xarr[1] = spacing;
	  dbp1yarr[1] = 0;
	  if (notinit(c2rot)) c2rot = 5;
	  dbp1tharr[1] = c2rot;
	  if (c2yrot!=0) {		// if stereo pair seen from bottom
             dbp1ytharr  = (double *)emalloc(CBPARR*sizeof(double));
	     dbp1ytharr[0] = 0;
	     dbp1ytharr[1] = -c2yrot;
	  }
	}
	remove_nconns = 0;
	break;

     case 1:	
	 // dbp1_am = 6;
	 if (n_dbp1 < 0 || n_dbp1 > dbp1_am) n_dbp1 = dbp1_am;			/* limit to 6 dbp1s */
	 i = dbp1row (dbp1_am, spacing=30, theta=  180, dbp1_zrot, skip,  i=1);
	break; 

     case 2:
	break;

     case 11:	
	  if (n_dbp1 < 0 || n_dbp1 > dbp1_am) n_dbp1 = dbp1_am;			/* limit to 11 dbp1s */
	  i = dbp1row (dbp1_am, spacing=30, theta=  0,   dbp1_zrot, skip,  i=1);
	  break;
 
     case 21:

	  if (n_dbp1 < 0 || n_dbp1 > 2*dbp1_am) n_dbp1 = 2*dbp1_am - 1; 	  /* limit to 21 dbp1s */
	  i = dbp1cent (1,                  theta=  45, dbp1_zrot,  sk=0, i=0); /* set cell rot near both ams */
	  i = dbp1row (dbp1_am, spacing=30, theta=  90, dbp1_zrot,  skip,  i=1);
	  i = dbp1row (dbp1_am, spacing=30, theta=   0, dbp1_zrot,  skip,  i);
	  setn(dbp1,MAXSDIST,15); 
	 break;
 
     case 22: 									/* use with dbp1, dbp2 */
          if (n_dbp1 == 0) {			/* random array */
             dbp1xarrsiz = dbp1_am * spacing;
             dbp1yarrsiz = 30;
 	     dbp1_first_cent = 1;
          } 
	  else {
	      if (n_dbp1 < 0 || n_dbp1 > dbp1_am) n_dbp1 = dbp1_am;		/* limit to 11 dbp1s */
	      i = dbp1cent (1,      theta=  0,   dbp1_zrot+315,         sk=0, i=0);
	      i = dbp1row (dbp1_am, spacing=28, theta= 0, dbp1_zrot+45, skip, i);
	      setn(dbp1,MAXSDIST,25); 
	  }
	  break;

     case 3:
	  if (n_dbp1 < 0 || n_dbp1 > 3*dbp1_am-2) n_dbp1 = 3*dbp1_am-2;		/* limit to 31 dbp1s */
	  i = dbp1cent (1,                  theta=  45, dbp1_zrot, sk=0, i=0);  /* set cell rot near both ams */
	  i = dbp1row (dbp1_am, spacing=32, theta=  0,  dbp1_zrot, skip, i=1);
	  i = dbp1row (dbp1_am, spacing=32, theta=  60, dbp1_zrot, skip, i);
	  i = dbp1row (dbp1_am, spacing=32, theta= -60, dbp1_zrot, skip, i);
	  setn(dbp1,MAXSDIST,14);
	  break;

     case 4:
	  if (n_dbp1 < 0 || n_dbp1 > 4*dbp1_am-3) n_dbp1 = 4*dbp1_am-3;		/* limit to 41 dbp1s */
	  i = dbp1cent (1,                  theta=  45, dbp1_zrot, sk=0, i=0);  /* set cell rot near both ams */
	  i = dbp1row (dbp1_am, spacing=36, theta=   0, dbp1_zrot, skip, i=1);
	  i = dbp1row (dbp1_am, spacing=36, theta=  45, dbp1_zrot, skip, i);
	  i = dbp1row (dbp1_am, spacing=36, theta= -45, dbp1_zrot, skip, i);
	  i = dbp1row (dbp1_am, spacing=36, theta=  90, dbp1_zrot, skip, i);
	  setn(dbp1,MAXSDIST,14.7);
	 break;

     default: break;
 
  }  /* switch (amarr) */

  setn(dbp1,DENS,pow(spacing*0.5,-2)*1e6);
 
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

  if (notinit(dbp2_am)) {
     if (!notinit(dbp1_am)) dbp2_am = dbp1_am;
     else dbp2_am = 11;
  }

  if (amarr > 0) {
     skip = int((dbp2_am+1)/2);					/* skip the central dbp (when needed) */
     dbp2xarr   = (double *)emalloc(CBPARR*sizeof(double));
     dbp2yarr   = (double *)emalloc(CBPARR*sizeof(double));
     dbp2tharr  = (double *)emalloc(CBPARR*sizeof(double));
     dbp2cent (1,      theta=  0,   dbp2_zrot,   sk=0, i=0);
  }

  if (n_dbp2 > 0) {
    switch (amarr) {						/* set up dbp2s */

     case 0:
	  n_dbp2 = 1;								/* just 1 dbp2 */
	  remove_nconns = 0;
	  break;

     case 1:
	  dbp2_am = 6;
	  if (n_dbp2 > dbp2_am+1) n_dbp2 = dbp2_am;				/* limit to 5 dbp2s */
	  i = dbp2row (dbp2_am, spacing=30, theta=  180, dbp2_zrot, skip,  i=1);
	  break;

     case 11:
	  if (n_dbp2 > dbp2_am) n_dbp2 = dbp2_am;				/* limit to 11 dbp2s */
	  i = dbp2row (dbp2_am, spacing=30, theta=  0,   dbp2_zrot, skip,  i=1);
	  break;

     case 21: 
	  if (n_dbp2 > 2*dbp2_am) n_dbp2 = 2*dbp2_am - 1; 			   /* limit to 21 dbp2s */
	  i = dbp2cent (1,                  theta=  45, dbp2_zrot,  sk=0,  i=0); /* set cell rot near both ams */
	  i = dbp2row (dbp2_am, spacing=30, theta=  90, dbp2_zrot,  skip,  i=1);
	  i = dbp2row (dbp2_am, spacing=30, theta=   0, dbp2_zrot,  skip,  i);
	  setn(dbp2,MAXSDIST,15); 
	  break;

	case 22: 		 						/* use with dbp1, dbp2 */
	  if (n_dbp1 == 0) {				/* random array */
             dbp2xarrsiz = 30;
             dbp2yarrsiz = dbp2_am * spacing;
	     dbp2_first_cent = 0;
	  } else {
	     if (n_dbp2 >= dbp2_am) n_dbp2 = dbp2_am - 1;				/* limit to 10 dbp2s */
	     i = dbp2row (dbp2_am, spacing=28, theta=  90,   dbp2_zrot, skip,  i=0);
	  }
	 break;

        case 23:	
	  if (n_dbp2 > 2*dbp2_am+1) n_dbp2 = 2*dbp2_am - 1; 			   /* limit to 21 dbp2s */
	  i = dbp2cent (1,                  theta=  45, dbp2_zrot,  sk=-1, i=0); /* set cell rot near both ams */
	  i = dbp2row (dbp2_am, spacing=30, theta=  45, dbp2_zrot,  skip,  i=1);
	  i = dbp2row (dbp2_am, spacing=30, theta= 135, dbp2_zrot,  skip,  i);
	  setn(dbp2,MAXSDIST,15); 
	 break;

     case 3:
	  if (n_dbp2 > 3*dbp2_am+1) n_dbp2 = 3*dbp2_am - 2;			   /* limit to 31 dbp2s */
	  i = dbp2cent (1,                  theta=  45, dbp2_zrot, sk=-1, i=0);  /* set cell rot near both ams */
	  i = dbp2row (dbp2_am, spacing=35, theta=  0,  dbp2_zrot, skip, i=1);
	  i = dbp2row (dbp2_am, spacing=35, theta=  60, dbp2_zrot, skip, i);
	  i = dbp2row (dbp2_am, spacing=35, theta= -60, dbp2_zrot, skip, i);
	  setn(dbp2,MAXSDIST,14);
	  break;

     case 4:
	  if (n_dbp2 > 4*dbp2_am+1) n_dbp2 = 4*dbp2_am - 3;			   /* limit to 41 dbp2s */
	  i = dbp2cent (1,                  theta=  45, dbp2_zrot, sk=-1, i=0);  /* set cell rot near both ams */
	  i = dbp2row (dbp2_am, spacing=36, theta=   0, dbp2_zrot, skip, i=1);
	  i = dbp2row (dbp2_am, spacing=36, theta=  45, dbp2_zrot, skip, i);
	  i = dbp2row (dbp2_am, spacing=36, theta= -45, dbp2_zrot, skip, i);
	  i = dbp2row (dbp2_am, spacing=36, theta=  90, dbp2_zrot, skip, i);
	  setn(dbp2,MAXSDIST,14.7);
          break;

    }       /* switch (amarr) */
  }       /* if (ndbp2 > 0) */

  setn(dbp2,DENS,pow(spacing*0.5,-2)*1e6);

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

  if (!notinit(amarr)) {
        int i,j;
        double theta;
	double spacing = 35;
	double dtreedia;
	double somadist;

   make_ct(am);

   setn(ct,AXARBT,BRANCHED);		/* connect to bipolar cell branched axonal arbor */
   if (ct2>0) setn(ct2,AXARBT,BRANCHED);	/* connect to bipolar cell branched axonal arbor */

   amxarr  = (double *)emalloc(AMARR*sizeof(double));
   amyarr  = (double *)emalloc(AMARR*sizeof(double));
   amtharr = (double *)emalloc(AMARR*sizeof(double));

   am2xarr  = (double *)emalloc(AMARR*sizeof(double));
   am2yarr  = (double *)emalloc(AMARR*sizeof(double));
   am2tharr = (double *)emalloc(AMARR*sizeof(double));

   // dtreedia = n_dbp1 * spacing;
   switch (amarr) {
	    default:
	    case 1:
	    case 11:
	    case 22:
	    case 21: spacing = 32; break;
	    case 3:  spacing = 35; break;
	    case 4:  spacing = 36; break;
   }
 
   dtreedia = dbp1_am * spacing * 2;
   if (dtreedia <= 0) dtreedia = 650;
   somadist = dtreedia * 0.3;

   if (ninfo >= 2) ncfprintf (stderr,"# setparams(): am dtreedia %g somadist %g\n",dtreedia,somadist);

   setn(am, DTREEDIA,dtreedia);
   setn(am2,DTREEDIA,dtreedia);

   switch (amarr) {

     case 1:
	  if (n_dbp1 <= 6 && n_dbp2 <=6) setn(am,DTREEDIA,dtreedia);
          make_am_cell (theta=180, i=0, somadist);
	  n_am = 1;
          break;
   
    case 2: 
	  // if (n_dbp1 <= 6 && n_dbp2 <=6) setn(am,DTREEDIA,dtreedia);
          // make_am_cell (theta=180, i=0, somadist);
	  n_am = 0;
          break;

    case 11:
	  if (n_dbp1 <= 11 && n_dbp2 <=11) setn(am,DTREEDIA,dtreedia);
          make_am_cell (theta=180, i=0, somadist);
	  n_am = 1;
          break;

    case 21:
          i = make_am_cell (theta=180, i=0, somadist);
          i = make_am_cell (theta=90,  i,   somadist);
          n_am = 2;
          break;

    case 22:
          make_am_cell  (theta=180, i=0, somadist);
          make_am2_cell (theta=90,  i=0, somadist);
	  n_am  = 1;
	  n_am2 = 1;
          break;

    case 23:
          i = make_am_cell (theta=135, i=0, somadist);
          i = make_am_cell (theta=45,  i,   somadist);
          n_am = 2;
          break;

    case 3:
          i = make_am_cell (theta=0,   i=0, somadist);
          i = make_am_cell (theta=60,  i,   somadist);
          i = make_am_cell (theta=-60, i,   somadist);
          n_am = 3;
          break;
 
    case 4:
          i = make_am_cell (theta=0,   i=0, somadist);
          i = make_am_cell (theta=45,  i, somadist);
          i = make_am_cell (theta=-45, i, somadist);
          i = make_am_cell (theta=90,  i, somadist);
          n_am = 4;
          break;
   }  /* switch (amarr) */

  }  /* if (!notinit(amarr)) */

  if (n_amh > 0) {
	  make_ct(amh);
          setn(ct,AXARBT,BRANCHED);	/* connect to bipolar cell branched axonal arbor */
	  amhxarr  = (double *)emalloc(AMARR*sizeof(double));
	  amhyarr  = (double *)emalloc(AMARR*sizeof(double));
	  amhtharr = (double *)emalloc(AMARR*sizeof(double));
	  
	  amhxarr[0]  = 150;
	  amhyarr[0]  = 0;
	  amhtharr[0] = 180;

	  amhxarr[1]  = 0;
	  amhyarr[1]  = 150;
	  amhtharr[1] = 90;

	  amhxarr[2]  = 100;
	  amhyarr[2]  = 100;
	  amhtharr[2] = 135;

	  amhxarr[3]  = -100;
	  amhyarr[3]  = 100;
	  amhtharr[3] = 45;
  }

  if (notinit(bp_morph)) setn(ct,MORPH,0);		/* set cell morphology from file, default = "morph_bp" */
  else                   setn(ct,MORPH,bp_morph);
  setn(ct,BIOPHYS,1);		/* set cell biophys from file, default = "dens_default" */
  setn(ct,NCOLOR,RCOLOR);	/* set cell display color from region */

  if (ct2>0) {
    if (notinit(bp_morph)) setn(ct2,MORPH,0);		/* set cell morphology from file, default = "morph_bp" */
    else                   setn(ct2,MORPH,bp_morph);
    setn(ct2,BIOPHYS,1);				/* set cell biophys from file, default = "dens_default" */
    // setn(ct2,NCOLOR,RCOLOR);				/* set cell display color from region */
  }

  if (notinit(cbplam))   cbplam = 0.05; 	/* default complam for regions in density file */
  if (notinit(cbplam2)) cbplam2 = 0.2; 		/* default complam for regions in density file 2 (large comps) */
  // if (notinit(dispsize)) dispsize = 80; 	/* default display size */
  if (notinit(node_scale)) node_scale = -3.15;  /* 3: nodenum, 0.2 medium font, 0.05: small font */

  if (notinit(ddia))    ddia  = 1; 		/* multiplier for dendrite diameter */
  if (notinit(axdia))  axdia  = 1; 		/* multiplier for axon diameter */
  if (notinit(dvrev))  dvrev  = -0.065;		/* Vrev for dens_dbp1.n */
  if (notinit(dvst))   dvst   = dvrev;		/* Vstart for dens_dbp1.n */
  if (notinit(dvreva)) dvreva = -0.07;		/* Vrev for axon terminal in dens_dbp1.n */
  if (notinit(cadist)) cadist = 1e-3;		/* Ca chan density in axonal tips, dens_cbp_chirp.n */

  if (notinit(ivplot)) ivplot = 0; 		/* make I/V plot */
  if (notinit(pscal)) pscal   = 50e-12;		/* plot scale */

  if (!notinit(set_drm)) {			/* user set default Rm */
       setn(ct,NRM,set_drm); /* set default Rm */
       drm = set_drm;
  }
   if (notinit(drmab)) drmab = drm;              /* user set default Rm for axon branches */
   if (notinit(driab)) driab = dri;              /* user set default Ri for axon branches */
   if (notinit(dria))  dria  = dri;              /* user set default Ri for axon branches */
   if (notinit(dcmab)) dcmab = dcm;              /* user set default Cm for axon branches */
   if (notinit(naax))   naax = 0;                /* user set Na density in axon */
   if (notinit(naab))   naab = 0;                /* user set Na density in axon branches */
   if (notinit(nahd))   nahd = 0e-3;             /* user set Na high density region in axon */
   if (notinit(ksoma)) ksoma = 0e-3; 		 /* Kdr chan density in soma, dens_cbp_chirp.n */

   if (notinit(stimloc)) stimloc = 0; 		 /* trandsucer stimulus location (default: soma) */

  // dicafrac = 1;				/* remove Ca flux from ICa */

  // Set channel types in density file.
  // To change, check manual, and uncomment and modify these:  
  //
  //  _NA  = _NA5;		// NaV1.1 channel from Clancy & Kass (2004)
  //  _KA  = _K3;
  //  _KH  = _K4;
  //  _KIR = _K5;

  if (!notinit(disp_zmax) || !notinit(disp_zmin)) {

  //  display_z(disp_zmax=-5, disp_zmin=-15);          /* display sublamina a */
  //  display_z(disp_zmax=-15, disp_zmin=-50);         /* display sublamina b */
      display_z(disp_zmax, disp_zmin);                 /* limit z display range */
  }
}

/*------------------------------------------------------*/

void setdens(void)
/* set density and conductance parameters */

{
   int i, cn, maxnum;

    // if (!notinit(kdr_cond))    celdens[dbp1][0][_KDR][R_SOMA] = kdr_cond;  
    // setsv (ct,SCOND,1, 0);
    // if (arrsiz==100) {
    //  setsv (dbp1,SCOND,1, 25e-10);
    //} 
    if (make_dbp1>0) {
       if (amarr==0 && n_dbp1==2) {
          ndens[dbp1][cn=1] = 0;              // set cn 1 to use dbp1_densfile
          ndens[dbp1][cn=2] = 0;              // set cn 2 to use dbp1_densfile
      } else {
        maxnum = getn(dbp1,MAXNUM);
        ndens[dbp1][cn=1] = 0;              // set cn 1 to use dbp1_densfile
        for (cn=2; cn<maxnum; cn++) {
            ndens[dbp1][cn] = 1;            // set other cns to use dbp1_densfile2
       }
      }
    } 
    else if (make_dbp2>0) {
        maxnum = getn(dbp2,MAXNUM);
        ndens[dbp2][cn=1] = 0;              // set cn 1 to use dbp2_densfile
        for (cn=2; cn<maxnum; cn++) {
            ndens[dbp2][cn] = 1;            // set other cns to use dbp2_densfile2
       }
    }
    else if (make_hbp1>0) {
        maxnum = getn(hbp1,MAXNUM);
        ndens[hbp1][cn=1] = 0;              // set cn 1 to use hbp1_densfile
        for (cn=2; cn<maxnum; cn++) {
            ndens[hbp1][cn] = 1;          // set other cns to use hbp1_densfile2
       }
    }
}

/*------------------------------------------------------*/

void addlabels(void)
{ 
     int i, c, ncells=0;

   if (ct==dbp1) {
     c = ct;
     for (i=1; i<=ndbp1; i++) {
       if (!notinit(tip1))    {label(nde(c,i,dendn_node(c,tip1)),red,"Tip1");}
       if (amarr > 2) continue;
       if (!notinit(tip2))    {label(nde(c,i,dendn_node(c,tip2)),red,"Tip2");}
       if (!notinit(tip3))    {label(nde(c,i,dendn_node(c,tip3)),red,"Tip3");}
       if (!notinit(tip4))    {label(nde(c,i,dendn_node(c,tip4)),red,"Tip4");}
       if (!notinit(tip5))    {label(nde(c,i,dendn_node(c,tip5)),red,"Tip5");}
       if (!notinit(tip6))    {label(nde(c,i,dendn_node(c,tip6)),red,"Tip6");}
       if (!notinit(tip7))    {label(nde(c,i,dendn_node(c,tip7)),red,"Tip7");}
       if (!notinit(tip8))    {label(nde(c,i,dendn_node(c,tip8)),red,"Tip8");}
       if (!notinit(tip9))    {label(nde(c,i,dendn_node(c,tip9)),red,"Tip9");}
       if (!notinit(tip10))   {label(nde(c,i,dendn_node(c,tip10)),red,"Tip10");}
       if (!notinit(tip11))   {label(nde(c,i,dendn_node(c,tip11)),red,"Tip11");}
       if (!notinit(tip12))   {label(nde(c,i,dendn_node(c,tip12)),red,"Tip12");}
       if (!notinit(tip13))   {label(nde(c,i,dendn_node(c,tip13)),red,"Tip13");}
       if (!notinit(tip14))   {label(nde(c,i,dendn_node(c,tip14)),red,"Tip14");}
       if (!notinit(tip15))   {label(nde(c,i,dendn_node(c,tip15)),red,"Tip15");}
       if (!notinit(tip16))   {label(nde(c,i,dendn_node(c,tip16)),red,"Tip16");}
       if (!notinit(tip17))   {label(nde(c,i,dendn_node(c,tip17)),red,"Tip17");}
       if (!notinit(tip18))   {label(nde(c,i,dendn_node(c,tip18)),red,"Tip18");}
       if (!notinit(tip19))   {label(nde(c,i,dendn_node(c,tip19)),red,"Tip19");}
       if (!notinit(tip20))   {label(nde(c,i,dendn_node(c,tip20)),red,"Tip20");}
       if (!notinit(tip21))   {label(nde(c,i,dendn_node(c,tip21)),red,"Tip21");}
       if (!notinit(tip22))   {label(nde(c,i,dendn_node(c,tip22)),red,"Tip22");}
       if (!notinit(tip23))   {label(nde(c,i,dendn_node(c,tip23)),red,"Tip23");}
       if (!notinit(tip24))   {label(nde(c,i,dendn_node(c,tip24)),red,"Tip24");}
       if (!notinit(tip25))   {label(nde(c,i,dendn_node(c,tip25)),red,"Tip25");}
       if (!notinit(tip26))   {label(nde(c,i,dendn_node(c,tip26)),red,"Tip26");}
       if (!notinit(tip27))   {label(nde(c,i,dendn_node(c,tip27)),red,"Tip27");}
       if (!notinit(tip28))   {label(nde(c,i,dendn_node(c,tip28)),red,"Tip28");}
       if (!notinit(tip29))   {label(nde(c,i,dendn_node(c,tip29)),red,"Tip29");}
       if (!notinit(tip30))   {label(nde(c,i,dendn_node(c,tip30)),red,"Tip30");}
     }
   }

   if (ct==dbp2) {
     c = ct;
     for (i=1; i<=ndbp2; i++) {
       if (!notinit(tip1))    {label(nde(c,i,dendn_node(c,tip1)),red,"Tip1");}
       if (amarr > 2) continue;
       if (!notinit(tip2))    {label(nde(c,i,dendn_node(c,tip2)),red,"Tip2");}
       if (!notinit(tip3))    {label(nde(c,i,dendn_node(c,tip3)),red,"Tip3");}
       if (!notinit(tip4))    {label(nde(c,i,dendn_node(c,tip4)),red,"Tip4");}
       if (!notinit(tip5))    {label(nde(c,i,dendn_node(c,tip5)),red,"Tip5");}
       if (!notinit(tip6))    {label(nde(c,i,dendn_node(c,tip6)),red,"Tip6");}
       if (!notinit(tip7))    {label(nde(c,i,dendn_node(c,tip7)),red,"Tip7");}
       if (!notinit(tip8))    {label(nde(c,i,dendn_node(c,tip8)),red,"Tip8");}
       if (!notinit(tip9))    {label(nde(c,i,dendn_node(c,tip9)),red,"Tip9");}
       if (!notinit(tip10))   {label(nde(c,i,dendn_node(c,tip10)),red,"Tip10");}
       if (!notinit(tip11))   {label(nde(c,i,dendn_node(c,tip11)),red,"Tip11");}
     }
   }

   if (ct2==dbp2) {
     c = ct2;
     for (i=1; i<=ndbp2; i++) {
       if (!notinit(tip1))    {label(nde(c,i,dendn_node(c,tip1)),red,"Tip1");}
       if (amarr > 2) continue;
       if (!notinit(tip2))    {label(nde(c,i,dendn_node(c,tip2)),red,"Tip2");}
       if (!notinit(tip3))    {label(nde(c,i,dendn_node(c,tip3)),red,"Tip3");}
       if (!notinit(tip4))    {label(nde(c,i,dendn_node(c,tip4)),red,"Tip4");}
       if (!notinit(tip5))    {label(nde(c,i,dendn_node(c,tip5)),red,"Tip5");}
       if (!notinit(tip6))    {label(nde(c,i,dendn_node(c,tip6)),red,"Tip6");}
       if (!notinit(tip7))    {label(nde(c,i,dendn_node(c,tip7)),red,"Tip7");}
       if (!notinit(tip8))    {label(nde(c,i,dendn_node(c,tip8)),red,"Tip8");}
       if (!notinit(tip9))    {label(nde(c,i,dendn_node(c,tip9)),red,"Tip9");}
       if (!notinit(tip10))   {label(nde(c,i,dendn_node(c,tip10)),red,"Tip10");}
       if (!notinit(tip11))   {label(nde(c,i,dendn_node(c,tip11)),red,"Tip11");}
     }
   }

   if (ct>=0) {
     if (!notinit(stimloc)) {label(nde(ct,1,dendn_node(ct,stimloc)),yellow,"stim");}
     if (!notinit(recpnt1)) {label(nde(ct,1,recpnt1),white,"Rec1");}
     if (!notinit(recpnt2)) {label(nde(ct,1,recpnt2),white,"Rec2");}
     if (!notinit(recpnt3)) {label(nde(ct,1,recpnt3),white,"Rec3");}
     if (!notinit(recpnt4)) {label(nde(ct,1,recpnt4),white,"Rec4");}
     if (!notinit(recpnt5)) {label(nde(ct,1,recpnt5),white,"Rec5");}
     if (!notinit(recpnt6)) {label(nde(ct,1,recpnt6),white,"Rec6");}
     if (!notinit(recpnt7)) {label(nde(ct,1,recpnt7),white,"Rec7");}
     if (!notinit(recpnt8)) {label(nde(ct,1,recpnt8),white,"Rec8");}
     if (!notinit(recpnt9)) {label(nde(ct,1,recpnt9),white,"Rec9");}
     //label(ndn(ct,1,dendn_node(ct,0)),blue); 
     //label(ndn(ct,1,0),red);
  }

  vna = 0.04;
}

/*------------------------------------------------------*/


void runonexit (void)
{
  if (savefile[0]!=0)  unlink (savefile);
}

/*------------------------------------------------------*/

void onplot(void) {
    current = i(ndn(ct, 1, soma));
    voltage = v(ndn(ct, 1, soma));
    
    if (maxCurrent > current) {
      maxCurrent = current;
      //fprintf(stderr, "v: %g, i: %g\n", voltage, maxCurrent);
    }
    
     // fprintf(stderr, "i: %g, maxi: %g\n", current, maxCurrent);    
}

/*------------------------------------------------------*/

void runexpt(void) {

    int cn, i, n, plnum, electrode_node;
    int colr, midcone;
    double dst, t, fmax,fmin;
    double rmin, rmax, plsize;

    double xoffset = 0, yoffset = 0;
    double x,y;
    double Vmin, Vmax;
    double Imin, Imax;
    double cmin, cmax;
    double ipulse;
    double time2=0;
    photorec *p;
    node *npnt;

  timinc = 10e-6;
  ploti = 1e-3;
  crit = 1e-10;


if (!make_cones) {
  for(npnt=nodepnt; npnt=foreach(npnt,ct,-1,soma,NULL,&cn,NULL); npnt=npnt->next) {  	// add transducer to dendrite  
         int transdloc;
        transdloc  = dendn_node(ct,stimloc);
	if ((p=(photorec*)make_transducer(ndn(ct,cn,transdloc))) != NULL) {
          p->xpos=npnt->xloc;                                                                     
          p->ypos=npnt->yloc;
	}
	if (ninfo >= 3) fprintf(stderr,"# ct  %s cn %-2d transducer node %d\n",cname[ct],cn, transdloc);
  }
  if (ct2>0)
   for(npnt=nodepnt; npnt=foreach(npnt,ct2,-1,soma,NULL,&cn,NULL); npnt=npnt->next) {  	// add transducer to dendrite  
         int transdloc;
        transdloc  = dendn_node(ct2,stimloc);
        if ((p=(photorec*)make_transducer(ndn(ct2,cn,transdloc))) != NULL) {
          p->xpos=npnt->xloc;                                                                     
          p->ypos=npnt->yloc;
	}
	if (ninfo >= 3) fprintf(stderr,"# ct2 %s cn %-2d transducer node %d\n",cname[ct2],cn, transdloc);
  }
}

  cn = 1;
  electrode_node = 5000;
  setonplot(onplot);

  if (notinit(prestimdur))   prestimdur = 0.5;
  if (notinit(spotdur))      spotdur    = 0.5;
  if (notinit(stimdur))      stimdur    = 2.0;
  if (notinit(poststimdur)) poststimdur = 0.05;

  if (notinit(stimtime))       stimtime = 0.1;
  if (notinit(temp_freq))     temp_freq = 10;
  if (notinit(fstart))           fstart = 1.0;
  if (notinit(fincr))             fincr = 0.005;
  if (notinit(c1))                   c1 = 0.01;
  if (notinit(c2))                   c2 = 1;
  if (notinit(cmult))             cmult = 0.03;
  if (notinit(minten))           minten = -0.045;
  if (notinit(scontrast))     scontrast = 0.5;
  if (notinit(spotdia))         spotdia = 300;

  if (notinit(itail)) itail  = 0e-12;
  if (notinit(dci))    dci   = 0e-12;
  if (notinit(ipre))   ipre  = dci;

  if (notinit(istart))      istart =   40e-12;
  if (notinit(istop))        istop =   120e-12;
  if (notinit(istep))        istep =   10e-12;

  if (notinit(elec_rs))  elec_rs   = 20e6;
  if (notinit(elec_cap)) elec_cap  = 1e-14;
  if (notinit(elnode))     elnode  = soma;

  if (elnode==electrode_node) {
      make_electrode  (nd(ct,cn=1,elnode), ndn(ct,cn=1,soma), elec_rs, elec_cap);
  }
	
  // midcbp  = findmid(ct,0,0);
   midcone  = findmid(xcone,0,0);

  if (ncones>0) plot_v_nod(xcone, midcone, soma, Vmin = -0.08, Vmax = -0.01, colr=blue, "", 10, 1.0);
 
  plot_v_nod(ct, cn, soma, Vmin = -0.07,    Vmax = -0.03,    colr=blue,   "", 1, 1.0);

  if (!notinit(stimloc)) plot_v_nod(ct,cn,dendn_node(ct,stimloc),Vmin = -0.07, Vmax = -0.03, colr=blue,"Stim",3, 1.0);
  if (!notinit(tip1))    plot_v_nod(ct, cn, dendn_node(ct,tip1),   Vmin = -0.07, Vmax = -0.03, colr=red,  "", 3, 1.0);
  if (!notinit(tip2))    plot_v_nod(ct, cn, dendn_node(ct,tip2),   Vmin = -0.07, Vmax = -0.03, colr=green,"", 3, 1.0);
  if (!notinit(tip3))    plot_v_nod(ct, cn, dendn_node(ct,tip3),   Vmin = -0.07, Vmax = -0.03, colr=white,"", 3, 1.0);
  if (!notinit(tip1))    plot_v_nod(ct2,cn, dendn_node(ct2,tip2),  Vmin = -0.07, Vmax = -0.03, colr=brown,"", 3, 1.0);

  if (!notinit(recpnt1)) plot_v_nod(ct, cn, recpnt1,   Vmin = -0.07, Vmax = -0.03, colr=magenta,  "", 3, 1.0);
  if (!notinit(recpnt2)) plot_v_nod(ct, cn, recpnt2,   Vmin = -0.07, Vmax = -0.03, colr=brown,    "", 3, 1.0);
  if (!notinit(recpnt3)) plot_v_nod(ct, cn, recpnt3,   Vmin = -0.07, Vmax = -0.03, colr=yellow,   "", 3, 1.0);

  // plot_i_nod(ct, cn, soma, Imin = -3e-11, Imax = 3e-11, colr=magenta, "", 0, 0.5); 
  // plot_ca_nod(ct, cn, axtrm, 10e-6, cyan, "Ca axterm", 1, 0.5); 

  //if (!notinit(tip1)) plot_cabufb_nod(ct, cn, dendn_node(ct,tip1), 1, 10e-6, colr=red,   "Cabufb tip1", 6,1.0);
  //if (!notinit(tip2)) plot_cabufb_nod(ct, cn, dendn_node(ct,tip2), 1, 10e-6, colr=green, "Cabufb tip2", 6,1.0);
  //if (!notinit(tip3)) plot_cabufb_nod(ct, cn, dendn_node(ct,tip3), 1, 10e-6, colr=white, "Cabufb tip3", 6,1.0);
  if (!notinit(tip1))     plot_ca_nod(ct, cn, dendn_node(ct,tip1), 1, 30e-6, cyan,       "Ca tip1",     6,1.0); 

    plot_synves(findsynloc(dbp1,1,0,0),    fmin=0,fmax=1e-4,      brown,  8,"",1);

    plot_syncond(findsynloc(dbp1,1,0,0),   cmin=0,cmax=100e-12, red, 10,"",1);
    plot_syncond(findsynloc(dbp2,1,0,60),  cmin=0,cmax=100e-12, green, 10,"",1);
     
    plot_v_nod(am,  1, findnodloc(am,1,0,0),  Vmin = -0.08, Vmax = 0.0, colr=red,    "", 12, 1.0);
    plot_v_nod(am2, 1, findnodloc(am2,1,0,0), Vmin = -0.08, Vmax = 0.0, colr=green,  "", 12, 1.0);
    // plot_v_nod(am, 1, findnodloc(am,1,100,0), Vmin = -0.08, Vmax = 0.0, colr=white,  "", 12, 1.0);

   
    plot_syncond(findsynloc(am,1,0,0),    cmin=0,cmax=500e-12, magenta, 14,"",1);
    plot_syncond(findsynloc(am2,1,0,0),   cmin=0,cmax=500e-12, green,   14,"",1);

   if (disp) {                        // display the stimulus
        double t, dscale, starttime, disp_end;

      stim_backgr(minten);
      time2 = spot_chirp(spotdia, 0, 0, fstart, fincr, cmult, scontrast, stimtime,stimdur);
      //time2 += spot_vcontrast(spotdia, 0, 0, temp_freq, 0, cmult, 0.005, 0.8,  stimtime,stimdur);

      display_size(500);
      disp_end = time2+0.05;
      for (starttime=simtime,t=stimtime; t<disp_end; starttime = t, t+= 0.001) {
           display_stim(starttime, t, dscale=4, -0.035, -0.055);
           //display_stim(t, dscale=4, -0.035, -0.045); 
           //display_stim(0+t, dscale=4); 
           simwait(0.10);
      }
      return;
   }

  if (notinit(setxmin)) setxmin = 0;			// set plot to start at 0
  if (notinit(predur)) predur = 0.5;
  simtime = 0 - predur;
  endexp = stimtime+2*stimdur+2*spotdur+2*prestimdur+poststimdur;
  stim_backgr(minten);

  // cclamp(ndn(ct,cn,soma), ipre, simtime, predur+stimtime);
  step (predur);

  if (dci>0) {
     cclamp (ndn(ct,cn,elnode),dci,stimtime,2*stimdur);
  }

  stim_spot (spotdia, x=0, y=0,  cmult/2, stimtime, spotdur);
  stim_spot (spotdia, x=0, y=0, -cmult/2, stimtime+spotdur, spotdur);
  time2 = spot_chirp (spotdia, x=0, y=0, fstart, fincr, cmult, scontrast, stimtime+2*spotdur+prestimdur, stimdur);

  spot_vcontrast (spotdia, x=0, y=0, temp_freq, cmult, c1, c2, time2+prestimdur, stimdur);

  step (endexp);
}


