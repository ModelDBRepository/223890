/* Experiment cone_hz */
/*  for nc script retsim.cc */

#include <stdio.h>
#include <string.h>
#include <math.h>
#include "ncfuncs.h"
#include "retsim.h"
#include "retsim_var.h"
#include "colors.h"

double temp_freq;
double ntrials;
double stimdur;
double taildur;
double sdia;
double stimtime;
double minten;
double scontrast;
double Rext; 
double ph_tau; 
double ph_gain; 
double ph_offset; 
double phh_tau; 
double phh_gain; 
double phh_offset; 
double phn_gain; 
double phn_offset; 
double phn_ntoffset; 
double gHemi;
double dvsha;
double dvsc;
double coneha_cond;
double stimvolt;
double clca_cond;  
double clcac_cond;  
double coneca_cond;
double khz_cond;
double ca_pump;
double dcrm;
double predur;
double set_sarea;
double frac_clca;
double frac_ampa;
double Imax;
double Imin;
double stimcur;
int cone_vc;
int cone_stim;
int light_stim;
int set_cclamp;
int vnoise;
int gjmod;

int rec_ct;
int rec_cn;

/*------------------------------------------------------*/

void defparams(void) 
{
  setptr("temp_freq", &temp_freq);
  setptr("ntrials",   &ntrials);
  setptr("stimdur",   &stimdur);
  setptr("taildur",   &taildur);
  setptr("sdia",      &sdia);
  setptr("stimtime",  &stimtime);
  setptr("minten",    &minten);
  setptr("scontrast", &scontrast);
  setptr("Rext",      &Rext);
  setptr("ph_tau",    &ph_tau);
  setptr("ph_gain",   &ph_gain);
  setptr("ph_offset", &ph_offset);
  setptr("phh_tau",   &phh_tau);
  setptr("phh_gain",  &phh_gain);
  setptr("phh_offset",&phh_offset);
  setptr("phn_gain",  &phn_gain);
  setptr("phn_offset",&phn_offset);
  setptr("phn_ntoffset",&phn_ntoffset);
  setptr("gHemi",     &gHemi);
  setptr("dvsha",     &dvsha);
  setptr("dvsc",      &dvsc);
  setptr("vnoise",    &vnoise);
  setptr("stimvolt",  &stimvolt);
  setptr("coneha_cond", &coneha_cond);
  setptr("clca_cond",  &clca_cond);
  setptr("clcac_cond",  &clcac_cond);
  setptr("coneca_cond", &coneca_cond);
  setptr("khz_cond",    &khz_cond);
  setptr("ca_pump",     &ca_pump);
  setptr("dcrm",	&dcrm);
  setptr("predur",	&predur);
  setptr("set_sarea",   &set_sarea);
  setptr("frac_clca",   &frac_clca);
  setptr("frac_ampa",   &frac_ampa);
  setptr("Imax",        &Imax);
  setptr("Imin",        &Imin);
  setptr("cone_vc",     &cone_vc);
  setptr("cone_stim",   &cone_stim);
  setptr("light_stim",  &light_stim);
  setptr("set_cclamp",  &set_cclamp);
  setptr("stimcur",     &stimcur);
  setptr("gjmod",       &gjmod);
  nvalfile = "nval_bphz.n";
}

/*------------------------------------------------------*/

void setparams(void)
{
  make_rods = 0;
  make_cones= 1;        /* make cones, cbp, gc */
  make_ha   = 1;
  make_hb   = 0;
  make_hbat = 0;
  make_dbp1 = 0;
  make_dbp2 = 0;
  make_rbp  = 0;
  make_gca  = 0;
  make_dsgc = 0;
  make_ha_dbp1 = 0;
  make_ha_hbp1 = 0;
  make_cone_hb = 0;

  // set lamcrit smaller to keep comps presynaptic to cones separate 

  lamcrit = 0.01;
  setn(ha,NCOLOR,RCOLOR);       /* set cell display color from region */

  //Set Cone and Horizontal Cell Resting Potentials
  
  vk = -0.082;
  if (notinit(dvsc))  dvsc  = -0.04;		// for dens_cone.n
  if (notinit(dvsha)) dvsha = -0.04;		// for dens_ha.n
  if (notinit(dcrm))   dcrm = 0.5e3;  
  cone_maxcond = 880e-12;  

  if (!notinit(set_sarea)) dcasarea = set_sarea; // shell area, changes [Ca]i given ICa.
  if (notinit(cone_vc))       cone_vc = 1; 
  if (notinit(cone_stim))     cone_stim = 0; 
  if (notinit(light_stim)) light_stim = 0; 
  if (notinit(set_cclamp)) set_cclamp = 0; 
  if (notinit(stimcur))       stimcur = -10e-12; 
}

void setdens(void)
{
  // Set Ephaptic Parameters
  //
  setsv (ha,SCOND,1, 0);	//Set a value from the synaptic parameter table
  // setsv (xcone, SCOND,5,getsv(xcone, SCOND, 5)); 
   if (!notinit(coneha_cond)) setsv (xcone, SCOND,5,coneha_cond); 

  if (!notinit(vnoise)) setsv (xcone, SVNOISE,5,vnoise); 
 
 // set some channel conductances if wanted from the command line
 
  if (!notinit(clca_cond))   celdens[xcone][0][_CLCA][AXOND] = clca_cond;  
  if (!notinit(clcac_cond))  celdens[xcone][0][_CLCAC][AXOND]= clcac_cond;  
  if (!notinit(coneca_cond)) celdens[xcone][0][_CA]  [AXOND] = coneca_cond;  
  if (!notinit(ca_pump))     celdens[xcone][0][_CAP] [AXOND] = ca_pump;  
  //if (!notinit(khz_cond))    celdens[ha][0] [_KHZ] [SOMA] = khz_cond;  

  //setsv (hb,SCOND,1, 0);
  if(notinit(rec_ct)) rec_ct = gca;
  if (notinit(arrsiz)) arrsiz = 50;
  if (notinit(bg_inten)) bg_inten = 1e3;      /* background light intensity */
}

/*------------------------------------------------------*/
double voffset;
double voffset_midcone;
double voffset2_midcone;
double currentampa;
double currenthemi;
double currentca;
double currentclca;
double currentclcac;
double voffsets;
double currentampas;
double currenthemis;
double currentclcas;
double currentclcacs;
double sumcurrent;
int midcone, surrcone, htipcent, htipsurr;

/*------------------------------------------------------*/

// double pnx_func(double atp) 

#include "phbuf_inc.cc"

/*------------------------------------------------------*/

int node1 = 2000;
int nodeatp = 3000;
int nres = 2;
int nodeclca = 0;
int nodeampa = 0;
int nodeph = 4000;
int nodephl = 5000;
int nodephh = 6000;
#define NRESMUL 100

void ephapsynapnode(void)
{
    int i, pa, pb, ct1, cn1, cd1, ct2, cn2, cd2;
    synapse *sepnt = NULL;
    elem *epnt = NULL;
    resistor *r1;
    gapjunc *gj1;
    pannex *pnx1;
    loadelem *re = NULL;
    capac *ce = NULL;
    synap *spnt = NULL;
    conlst *c = NULL;
    chan *c1,*c2,*c3;
    comp *rext_pnt = NULL;
    node *nd = NULL;
    vbuf *vb = NULL;
    nbuf *nb = NULL;

   // add external resistors and capacitor
 
   if (notinit(ph_gain))   ph_gain   = 0;		// gain for pH effect, 0 => off
   if (notinit(ph_tau))    ph_tau    = 200e-3;		// pH low pass filter time constant
   if (notinit(ph_offset)) ph_offset = -0.035;		// offset for pH effect 
   if (notinit(phh_gain))  phh_gain   = 0;		// gain for pH effect, 0 => off
   if (notinit(phh_tau))   phh_tau    = 5e-3;		// pH high pass filter time constant
   if (notinit(phh_offset)) phh_offset = 0;		// offset for pH HP effect 
   if (notinit(phn_offset)) phn_offset = 0;		// volt offset for volt -> pH translation 
   if (notinit(phn_ntoffset)) phn_ntoffset = 7.4;	// pH offset for volt -> pH translation 
   if (notinit(phn_gain))  phn_gain = 100;		// gain for volt -> pH translation 

   for(epnt=elempnt; epnt = foreach (epnt, SYNAPSE, xcone, -1, &pa, &pb); epnt=epnt->next){
     sepnt = (synapse *)epnt;
     if (sepnt->node2a==ha || sepnt->node2a==hb) {  /* if the postsynaptic cell is ha or hb */
        ct1 = sepnt->node1a;
        cn1 = sepnt->node1b;
	cd1 = sepnt->node1c;
        ct2 = sepnt->node2a;
	cn2 = sepnt->node2b;
	cd2 = sepnt->node2c;
	// r1 = (resistor *)conn(ct2, cn2, cd2+node1, ct2, cn2, cd2, RESISTOR);   
	// r1->r = 1/gHemi;
	gj1  = (gapjunc *)conn(ct2, cn2, cd2+node1, ct2, cn2, cd2, GJ);   
	if (gjmod>0) {
	   gj1->gmax = gHemi*1.5;
	   gj1->gnv = 0.1;		// fraction non voltage-sensitive
	   gj1->vgain = 0.9;		// mV for e-fold change in rate
	   gj1->voff = 0.01;		// V (not mV) offset for e-fold change in rate
	   gj1->taun = 100.;		// relative rate for opening and closing
	} else {
	   gj1->gmax = gHemi;
	   gj1->gnv = 1;		// fraction non voltage-sensitive
	}

	pnx1 = (pannex *)conn(ct2, cn2, cd2, ct2, cn2, cd2+nodeatp, PNX);   
	pnx1->gmax = gHemi* 0.002;
	pnx1->gnv = 0.1;		// fraction non voltage-sensitive
	pnx1->vgain = 0.9;		// mV for e-fold change in rate
	pnx1->voff = 0.01;		// V (not mV) offset for e-fold change in rate
	pnx1->taun = 100.;		// relative rate for opening and closing
	pnx1->rect = 1;			// rectifying pannexin
	pnx1->atp_decr = 1 - 0.002;	// pannexin atp decrement
        pnx1->pnxfunc = (double(*)(pannex*,double))pnx_func;	// set pannexin function for atp, etc

	// 	pnx1->atp  = atp;

	ce = (capac *)at(ct2, cn2, cd2+nodeatp, GNDCAP);
	ce->c = 0.5e-12;
	re = (loadelem *)at(ct2, cn2, cd2+nodeatp, LOAD);   
	re->r = 1e8;
	re->vrev = re->vrest = -0.05;

	for (i=0; i<nres-1; i++) {
	  r1 = (resistor *)conn(ct2, cn2, cd2+node1+i*NRESMUL, ct2, cn2, cd2+node1+(i+1)*NRESMUL, RESISTOR);   
	  r1->r = Rext/nres;
	}
	re = (loadelem *)at(ct2, cn2, cd2+node1+(nres-1)*NRESMUL, LOAD);   
	re->r = Rext/nres;
	re->vrev = re->vrest = 0;
	for (i=0; i<nres; i++) {
	  ce = (capac *)at(ct2, cn2, cd2+node1+i*NRESMUL, GNDCAP);
	  ce->c = 0.5e-12;
	}
	if (cn1==midcone)  htipcent = cd2;
	if (cn1==surrcone) htipsurr = cd2;

	// add low-pass filter from horizontal cell to external compartment for lowp pH feedback

	vb = (vbuf *)conn(ct2, cn2, cd2, ct2, cn2, cd2+nodephl, BUF);
	vb->offset = ph_offset;
	vb->gain = ph_gain;
	vb->tau = ph_tau;
	// vb->delay = 0.01;
	ce = (capac *)at(ct2, cn2, cd2+nodephl, GNDCAP);
	ce->c = 1e-12;

	// add resistor to ph compartment
	
	r1 = (resistor *)conn(ct2, cn2, cd2+nodephl, ct2, cn2, cd2+nodeph, RESISTOR);   
	r1->r = 1e6;
	ce = (capac *)at(ct2, cn2, cd2+nodeph, GNDCAP);
	ce->c = 1e-12;

	// add high-pass filter from cone  to external compartment for highp pH feedback

	vb = (vbuf *)conn(ct1, cn1, cd1, ct2, cn2, cd2+nodephh, BUF);
	vb->offset = phh_offset;
	vb->gain = phh_gain;
	vb->tau = phh_tau;
	vb->lphp = HP;
	// vb->delay = 0.01;
	ce = (capac *)at(ct2, cn2, cd2+nodephh, GNDCAP);
	ce->c = 1e-12;

	// add resistor to ph compartment
	
	r1 = (resistor *)conn(ct2, cn2, cd2+nodephh, ct2, cn2, cd2+nodeph, RESISTOR);   
	r1->r = 1e6;

	// add ntrans buf to convert voltage to pH for ext comp 
	
	nb = (nbuf *)conn(ct2, cn2, cd2+nodeph, ct2, cn2, cd2+node1, NBUF);
	nb->offset = phn_offset;
	nb->ntoffset = phn_ntoffset;
	nb->gain = phn_gain;
	nb->ntrans = PH;

      }  /* if (sepnt->node2a==ha) */

   }  /* foreach (epnt, SYNAPSE) */

   initsim();		//  generate compartments

   /* add extracellular compartment from Rext to channels capture channel currents */

  if (notinit(frac_ampa))   frac_ampa = 0.5;
  if (notinit(frac_clca))   frac_clca = 1;


   nodeclca = node1 + (nres - int(nres*frac_clca + 0.5)) * NRESMUL;
   nodeclca = max(nodeclca,node1);
   nodeclca = min(nodeclca,node1+(nres-1)*NRESMUL);

   nodeampa = node1 + (nres - int(nres*frac_ampa + 0.5)) * NRESMUL;
   nodeampa = max(nodeampa,node1);
   nodeampa = min(nodeampa,node1+(nres-1)*NRESMUL);

   if (ninfo >= 2) fprintf (stderr,"# nodeampa %d\n",nodeampa);
   if (ninfo >= 2) fprintf (stderr,"# nodeclca %d\n",nodeclca);
   if (ph_gain  != 0) if (ninfo >= 2) fprintf (stderr,"# nodephl  %d\n",nodephl);
   if (phh_gain != 0) if (ninfo >= 2) fprintf (stderr,"# nodephh  %d\n",nodephh);

   for(epnt=elempnt; epnt = foreach (epnt, SYNAPSE, xcone, -1, &pa, &pb); epnt=epnt->next){
     sepnt = (synapse *)epnt;
     if (sepnt->node2a==ha || sepnt->node2a==hb) {	/* if the postsynaptic cell is ha or hb */
        ct1 = sepnt->node1a;
        cn1 = sepnt->node1b;
	cd1 = sepnt->node1c;
        ct2 = sepnt->node2a;
	cn2 = sepnt->node2b;
	cd2 = sepnt->node2c;
	if ((nd=ndn(ct2, cn2, cd2+node1))!=NULL) {	/* get Rext node 1 */
	  rext_pnt = nd->comptr;			/* get pointer to Rext comp */
          if ((spnt=(synap *)sepnt->lptr)!=NULL) {	/* get run-time synapse struct */
            if ((c=spnt->comp1->clst)!=NULL){		/* get conn list for presyn compartment */
	       if ((c1=findchan(c,CA,-1))!=NULL) {	/* find channel in cone terminal */
	         addchan_extern_ca(rext_pnt, c1);	/* add external comp to channel */
		 // setnt(rext_pnt, PH, 7.4);		/* set external pH */
	       }
	    }  /* if (comp1->clst) */
	  }  /* if (spnt=sepnt->lptr) */
	}  /* if (nd=ndn()) */

	if ((nd=ndn(ct2, cn2, cd2+nodeclca))!=NULL) {	/* get Rext node for ClCa from frac_clca */
	  rext_pnt = nd->comptr;			/* get pointer to Rext comp */
          if ((spnt=(synap *)sepnt->lptr)!=NULL) {	/* get run-time synapse struct */
            if ((c=spnt->comp1->clst)!=NULL){		/* get conn list for presyn compartment */
	       if ((c2=findchan(c,ClCa,1))!=NULL) {	/* find channel in cone terminal */
	         addchan_extern(rext_pnt, c2);		/* add external comp to channel */
	       }
	    }  /* if (comp1->clst) */
	  }  /* if (spnt=sepnt->lptr) */
	}  /* if (nd=ndn()) */

	if ((nd=ndn(ct2, cn2, cd2+nodeampa))!=NULL) { /* get Rext node 2 for synapse */
	  rext_pnt = nd->comptr;			/* get pointer to Rext comp */
          if ((spnt=(synap *)sepnt->lptr)!=NULL) {	/* get run-time synapse struct */
            if ((c=spnt->comp2->clst)!=NULL){		/* get conn list for postsyn compartment */
	       if ((c3=findchan(c,AMPA,-1))!=NULL) {	/* find channel in Hz dendr tip */
	         addchan_extern(rext_pnt, c3);		/* add external comp to channel */
	       }
	    }  /* if (comp2->clst) */
	  }  /* if (spnt=sepnt->lptr) */
	}  /* if (nd=ndn()) */

      }  /* if (sepnt->node2a==ha) */
   }  /* foreach (epnt, SYNAPSE) */
}

/*----------------------------------------------------------------------------------------*/

void readephapticfeedback(void)

/* connect cone (ct1) to horizontal cell (ct2) with ephaptic feedback */

{
  int pa, pb, pc, pd, ct1, cn1, cd1, ct2, cn2, cd2;
  synapse *sepnt = NULL;
  synap *spnt = NULL;
  elem *epnt = NULL;
  int pct, pcn;
  node *nd1 = NULL, *nd2 = NULL;
  capac *ce = NULL;
  conlst *c = NULL;
  chan *c1 = NULL;
  chan *c2 = NULL;
  chan *c3 = NULL;
  cable *cb1 = NULL;
  attrib *apnt = NULL;
  double dtrial = 1;
  double t, st, fmax,fmin, vol;
  double gs,vs,rs, vcone, vhz;
  int midha, midcbp;
  double rmin, rmax, plsize;
  struct conn *r1pnt = NULL;
  struct conn *r2pnt = NULL;
  struct conn *r3pnt = NULL;
  // double R1, R2, R;
  double gclca=0, gclcac=0, gca=0, ggj=0;

       for(epnt=elempnt; epnt = foreach (epnt, SYNAPSE, xcone, -1, &pa, &pb); epnt=epnt->next){
	 sepnt = (synapse *)epnt;
	 if (sepnt->node2a==ha || sepnt->node2a==hb) {  /* if the postsynaptic cell is ha or hb */
            ct1 = sepnt->node1a;
	    cn1 = sepnt->node1b;
	    cd1 = sepnt->node1c;
            ct2 = sepnt->node2a;
	    cn2 = sepnt->node2b;
	    cd2 = sepnt->node2c;
	    if ((spnt=(synap *)sepnt->lptr)!=NULL) {	/* run-time synapse struct */
	      gs = record_chan(((elem*)sepnt), G, 0);
	      // fprintf(stderr, "ampacond= %g\n", gs);
	      vcone = spnt->comp1->v;
	      vhz   = spnt->comp2->v;
	      // fprintf(stderr, "vhz %g \n" , vhz);
	      if (spnt->spre) spnt = spnt->spre->sdyad;

	      if ((nd2=ndn(ct2, cn2, cd2+node1))!=NULL) {	/* get Rext node */
	         voffset = nd2->comptr->v; 
	         if ((nd1=ndn(ct1, cn1, cd1))!=NULL) {		/* get presyn node */
	           if ((c=nd1->comptr->clst)!=NULL){
		      if ((c1=findchan(c,CA,-1))!=NULL) {
		        gca = c1->conduct;
		        // fprintf (stderr,"ctype1 %d %g\n",c1->ctype,c1->conduct);
		      }
		      if ((c2=findchan(c,ClCa,1))!=NULL) {
		        gclca = c2->conduct;
		      }
		      if ((c2=findchan(c,ClCa,2))!=NULL) {
		        gclcac = c2->conduct;
		      }
		     }
	           } /* if (comp1->clst) */

	           if ((nd2=ndn(ct2, cn2, cd2))!=NULL) {	/* get gHemi node */
	               if ((c=nd2->comptr->clst)!=NULL){
		          if ((c3=findchan(c,GJ,-1))!=NULL) {
			     ggj = c3->conduct;			/* hemichannel conductance */
	                  }
	               }
	           }

		   if (cn1==midcone) {
		       // fprintf(stderr, "midcone %d  ha tip %d\n" , midcone, cd2);
		       // fprintf(stderr, "voltagedropext %g \n" , voffset);
		       // currenthemi = (vhz - voffset) * gHemi;
		       currenthemi = (vhz - voffset) * ggj;
		       // fprintf(stderr, "currenthemi %g \n" , currenthemi);
		       currentca   = (vcone - voffset - c1->gvrev) * (gca);
		       // fprintf(stderr, "currentca %g \n" , currentca);
		       // fprintf(stderr, "gca %g v %g voff %g gvrev %g\n" , gca, vcone, voffset, c1->gvrev);
		       
	               nd2=ndn(ct2, cn2, cd2+nodeampa);	/* get Rext node for ClCa */
	               voffset2_midcone = nd2->comptr->v; 
		       currentampa = (vhz - voffset2_midcone) * (gs);
		       // fprintf(stderr, "currentampa %g %g\n" , currentampa,gs);
		       
	               nd2=ndn(ct2, cn2, cd2+nodeclca);	/* get Rext node for ClCa */
	               voffset2_midcone = nd2->comptr->v; 
		       currentclca = (vcone - voffset2_midcone - vcl) * (gclca);
		       currentclcac   = (vcone - vcl) * (gclcac);
		       sumcurrent = currentca + currentclca + currentclcac;
		       // fprintf (stderr,"gclca %g\n",gclca);
		       // fprintf(stderr, "currentclca %g \n" , currentclca);
		       voffset_midcone = voffset;
		   } /* if (cn1==midcone) */

                   if (cn1==surrcone) {
                       // fprintf(stderr, "midcone %d  ha tip %d\n" , midcone, cd2);
                       // fprintf(stderr, "voltagedropext %g \n" , voffset);
                       // fprintf(stderr, "currentampa %g %g\n" , currentampa,gs);
                       //currenthemis = (vhz - voffset) * gHemi;
                       currenthemis = (vhz - voffset) * ggj;
                       // fprintf(stderr, "currenthemi %g \n" , currenthemi);
		       
	               nd2=ndn(ct2, cn2, cd2+nodeampa);	/* get Rext node for ClCa */
	               voffset2_midcone = nd2->comptr->v; 
                       currentampas = (vhz - voffset2_midcone) * (gs);
		       // fprintf(stderr, "currentampa %g %g\n" , currentampa,gs);
		       
	               nd2=ndn(ct2, cn2, cd2+nodeclca);	/* get Rext node for ClCa */
	               voffset2_midcone = nd2->comptr->v; 
		       currentclcas = (vcone - voffset2_midcone - vcl) * (gclca);
		       currentclcacs  = (vcone - vcl) * (gclcac);
                       // fprintf (stderr,"gclca %g\n",gclca);
                       // fprintf(stderr, "currentclca %g \n" , currentclca);
                       voffsets = voffset;
                   } /* if (cn1==surrcone) */

	        }  /* if (nd=ndn()) */
	    }  /* if ((spnt=sepnt->lptr) */
         }   /* if sepnt */
       }    /* for (epnt;;) */
}
       
/*------------------------------------------------------------------------------------*/

void clca_speed (int stype, double tau)
{
     int pa, pb;
     elem *epnt;
     chan *cp;

     for(epnt=elempnt; epnt = foreach (epnt, CHAN, xcone, -1, &pa, &pb); epnt=epnt->next) {
	 //fprintf (stderr,"clca %d ctype %d\n",pb, epnt->ctype);
         if ((cp=(chan *)epnt->lptr)!= NULL) {
	     if (cp->ctype==ClCa && cp->stype==stype) {
                //fprintf (stderr,"chan type %d arate %g\n",cp->ctype,cp->arate);
		cp->arate *= tau;
		cp->brate *= tau;
                // fprintf (stderr,"chan type %d arate %g brate %g\n",cp->ctype,cp->arate,cp->brate);
	     }
         }
     }
}
/*------------------------------------------------------------------------------------*/

void runexpt(void)

{
    int ct, cn, n, pct, pcn, plnum, cn1, pa, pb;
    int colr, nc, pl, pves, prate;
    int midha, midcbp;
    double t, st, fmax,fmin, vol;
    double rmin, rmax, plsize, voffset;
    double dtrial,exptdur;
    double Vmin, Vmax, phmin, phmax;
    //double volinc = 0.01; //VCLAMP 1
    elem *epnt;

  midcone = findmid(xcone,0,0);
  midcone = 25;
  midha   = findmid(ha, 0,0);
  midcbp  = findmid(dbp1, 0,0);
  surrcone = 22;

  if (ninfo >=1) fprintf (stderr,"# mid cone # %d\n", midcone);
  if (ninfo >=1) fprintf (stderr,"# mid cbp  # %d\n",  midcbp);
  if (ninfo >=1) fprintf (stderr,"# mid ha  # %d\n",  midha);  

  if(notinit(Rext))  Rext  = 75e6;
  if(notinit(gHemi)) gHemi = 5e-9;
  if(notinit(gjmod)) gjmod = 0;
 
  ephapsynapnode();
    
  // if (ninfo >=1) fprintf (stderr,"# midcone %d htipcent %d\n",  midcone, htipcent);  
  // if (ninfo >=1) fprintf (stderr,"# surrcone %d htipsurr %d\n", surrcone, htipsurr);  

  if (notinit(temp_freq)) temp_freq = 4;
  // fprintf(stderr, "# temp freq %d\n", temp_freq);
  if (notinit(ntrials)) ntrials = 1;
  if (temp_freq == 0) {
    fprintf (stderr,"## retsim1: temp_freq = 0, STOPPING\n");
    temp_freq = 1;
  };
  

  if (notinit(stimtime))   stimtime = 0.20;  /* stimulus time */
  if (notinit(stimdur))     stimdur = 0.30;  /* stimulus duration */
  if (notinit(taildur))     taildur = 0.20;  /* tail current duration */
  if (notinit(sdia))           sdia = 300;  /* spot diameter */
  if (notinit(minten))       minten = bg_inten;  /* background intensity (for make cone)*/
  if (notinit(scontrast)) scontrast = 0.9;   /* stimulus contrast */

  exptdur = stimtime + stimdur + taildur;
  endexp  = exptdur;


  plot_v_nod(ct=xcone,cn=midcone,n=axtrm,Vmin=-.055,Vmax =-.030,colr=red,"Vcone_cent", -1, -1); 
  plot_v_nod(ct=xcone,cn=surrcone,     n=axtrm,Vmin=-.055,Vmax =-.030,colr=green,"Vcone_surr", -1, -1); 
  plot_synrate_out(ct=xcone,cn=midcone,1,ha,1,rmin=0,rmax=500,fmax=1,colr=magenta,prate=1,pves=0,"cone_cent",1.0); 
  plot_synrate_out(ct=xcone,cn=surrcone,1,     ha,1,rmin=0,rmax=500,fmax=1,colr=blue,   prate=1,pves=0,"cone_surr",1.0); 

  Imax = 10e-12;
  Imin = -30e-12;

  plot_var(&currentampa,1,Imax,Imin);		        /* plot AMPA chan current */
  plot_param ("IAMPA_cent", colr=7, pl=8, plsize=1);
   
  plot_var(&currentampas,1,Imax,Imin);		        /* plot AMPA chan current */
  plot_param ("IAMPA_surr", colr=9, pl=8, plsize=1);
   
//  plot_var(&currentca,1,Imax,Imin);		        /* plot hemichannel current */
//  plot_param ("ICa_cent", colr=1, pl=8, plsize=1);
   
  plot_var(&currenthemi,1,Imax,Imin);		        /* plot hemichannel current */
  plot_param ("IHemi_cent", colr=6, pl=8, plsize=1);
   
//  plot_var(&currenthemis,1,Imax,Imin);		        /* plot hemichannel current */
//  plot_param ("IHemi_surr", colr=4, pl=8, plsize=1);
   
  plot_var(&currentclca,1,Imax/10,Imin/10);		        /* plot ClCa current */
  plot_param ("IClCa_cent", colr=5, pl=8, plsize=1);
   
  plot_var(&currentclcas,1,Imax/10,Imin/10);		        /* plot ClCa current */
  plot_param ("IClCa_surr", colr=2, pl=8, plsize=1);
   
  plot_var(&voffset_midcone,1,0, -0.02);	        	/* plot voffset */
  plot_param ("Vext_cent", colr=4, pl=6, plsize=1);

  plot_var(&voffsets,1,0, -0.02);		        	/* plot voffset */
  plot_param ("Vext_surr", colr=2, pl=6, plsize=1);

  plot_v_nod(ct=ha,cn=midha,n=soma,Vmin=-.08,Vmax=0,colr=green,"Vhz_soma",5, 1.5); /* plot Vha*/
  //plot_v_nod(ct=ha,cn=midha,n=htipcent,Vmin=-.07,Vmax=0,colr=ltgreen,"",5,1.5); /* plot Vha*/
  //plot_v_nod(ct=ha,cn=midha,n=10,Vmin=-.07,Vmax=0,colr=blue,"",         5, 1.5); /* plot Vha*/
  plot_v_nod(ct=ha,cn=midha,n=htipcent,Vmin=-.08,Vmax=0,colr=ltgreen,"Vhz_tip_cent", 5, 1.5); /* plot Vha*/
  plot_v_nod(ct=ha,cn=midha,n=htipsurr,Vmin=-.08,Vmax=0,colr=ltmag,"Vhz_tip_surr",   5, 1.5); /* plot Vha*/
  if (ph_gain != 0 || phh_gain != 0) {
   plot_v_nod(ct=ha,cn=midha,n=htipcent+nodeph,Vmin=-.01,Vmax=0.02,colr=ltgreen,"Vhz_tip_centph",   4, 1.5); /* plot Vha*/
   plot_v_nod(ct=ha,cn=midha,n=htipsurr+nodeph,Vmin=-.01,Vmax=0.02,colr=ltmag  ,"Vhz_tip_surrph",   4, 1.5); /* plot Vha*/

   plot_ph_nod(ct=ha,cn=midha,n=htipcent+node1,phmin=7,phmax=8,colr=ltgreen,"pH_tip_centph",   3, 1.5); /* plot Vha*/
   // plot_ph_nod(ct=ha,cn=midha,n=htipsurr+node1,phmin=7,phmax=8,colr=ltmag,  "pH_tip_surrph",   3, 1.5); /* plot Vha*/
  }
  // plot_v_nod(ct=ha,cn=midha,n=htipcent+nodeatp,Vmin=-.06,Vmax=0.02,colr=blue,"Vhz_tip_centatp",   2, 1.5); 
  plot (ATP,ndn(ha,midha,htipcent+nodeatp), 1e-6, 0); plot_param("ATP", red, 2, 1.);

  // plot_i_nod(ct=ha, cn=1, n=soma, -2e-9, 1e-9, colr=blue, "",   -1,-1.5);
  // plot_synrate_out(ct=ha,cn=midha,pct=xcone,pcn=midcone,rmin=0,rmax=5000,colr=yellow,1); 
  // plot_v_nod(ct=dbp1,cn=midcbp,n=soma,Vmin=-.045,Vmax =-.040,colr=red,"", -1, -1);
  // plot_synrate_out(ct=dbp1,cn=midcbp,rmin=0,rmax=200,colr=magenta);
  // plot_v_nod(ct=gca,cn=1,n=soma,Vmin=-.075,Vmax =-.055,colr=blue,"", -1, -1);
  //if (getn(gca,BIOPHYS)) { plot(CA,1,ndn(gca,1,soma),fmax=0.5e-6,fmin=0); 
  //				plot_param("Cai", plnum=0,plsize=0.3);}

 // if (getn(xcone,BIOPHYS)) plot(CA,1,ndn(xcone,midcone,1),fmax=3.0e-6,fmin=0); 
 //  				plot_param("Cai coneterm",magenta, plnum=0,plsize=1.0);
 // if (getn(xcone,BIOPHYS)) plot(CA,1,ndn(xcone,surrcone,1),fmax=3.0e-6,fmin=0); 
 //  				plot_param("Cai conesurr", blue,plnum=0,plsize=1.0);
 
 // if (getn(xcone,BIOPHYS)) plot(CA,100,ndn(xcone,midcone,1),fmax=3.0e-6,fmin=0); 
 // 				plot_param("Caicore", plnum=0,plsize=1.0);
  //if (getn(xcone,BIOPHYS)) plot(CA,-1,ndn(xcone,midcone,1),fmax=dcao,fmin=0); 
  // 				plot_param("Cao coneterm", plnum=0,plsize=1.0);
  //if (getn(xcone,BIOPHYS)) plot(CA,-100,ndn(xcone,midcone,1),fmax=dcao,fmin=0); 
  // 				plot_param("Caocore coneterm", plnum=0,plsize=1.0);

   stim_backgr(minten);
   if (notinit(stimvolt)) stimvolt = -0.045; 

//   if (notinit(setxmin)) setxmin = 0;                    // set plot to start at 0
   if (notinit(predur)) predur = 0.05;			// equilib time before simulation starts
//   simtime = 0 - predur;

  if (light_stim) {
    for (n=1; n<=ncones; n++) {
      if (n!=midcone) {
	  stim_cone (ndn(xcone,n,0), 1e5, stimtime, stimdur, 1);
      } 
    }
  } else {
    for(epnt=elempnt; epnt = foreach (epnt, CONE, xcone, -1, &pa, &pb); epnt=epnt->next){
      //fprintf (stderr,"cone # %d\n",pb);
      if (pb!=midcone) {
         if (set_cclamp) cclamp(ndn(xcone,pb,axtrm), stimcur, stimtime, stimdur );
         else            vclamp(ndn(xcone,pb,axtrm), stimvolt, stimtime, stimdur );
      }
      else {
	 if (cone_vc)   vclamp(ndn(xcone,pb,axtrm), -0.040, simtime, 2 );
	 else if (cone_stim) {
            if (set_cclamp) cclamp(ndn(xcone,pb,axtrm), stimcur, stimtime, stimdur );
            else            vclamp(ndn(xcone,pb,axtrm), stimvolt, stimtime, stimdur );
	 }
      }
    }
  }

   clca_speed (1,2);		// speed up channels in cleft
   clca_speed (2,3);		// set slow channels faster
   for (st=0; st<predur; st+= stiminc){
       readephapticfeedback();
       step(stiminc);
   } 
   clca_speed (2,0.333);	// set slow channels slower again

   for (st=0; st<exptdur; st+= stiminc){
       readephapticfeedback();
       step(stiminc);
   } 
}


