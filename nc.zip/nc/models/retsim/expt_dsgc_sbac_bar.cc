/* Experiment dsgc_sbac for retsim */


#include <stdio.h>
#include <string.h>
#include <math.h>
#include <unistd.h>
#include <stdlib.h>
#include "ncfuncs.h"
#include "retsim.h"
#include "retsim_var.h"
#include "colors.h"

#include "stimfuncs.h"
#include "onplot_dsgc_movie.cc"

#define NDSGC 50

extern int dsgc_pref[NDSGC]; /* dsgc's pref dir, default 0 deg*/
extern int n_dsgc;
extern int rec_ct;

double theta;
double iroff;
int light_inhib;
int dsgc_prefdir;
int node_dist;

int no_inhib;
int sbarr;
int rec_ct;
int rec_cn;
int set_vclamp;
int movein;

double ampa_cond;
double nmda_cond;

double barwidth;
double minten;
double sinten;
double velocity;
double disptime;
double stimdur;
double prestimdur;
double poststimdur;
double sblur;
double ioffset;
double istim;
double predur;
double sdia;
double sbaclm;
double sb_rii;
double sb_rip;
double sb_rid;
double sb_rm;
double sb_vr;
double sb_vs;

double namid;
double nadist;

double kprox;
double kdist;
double kmid;
double ksoma;

double camid;
double cadist;

char savefile[30] = {0};

void sb_init(void);

/*--------------------------------------------------------*/

void defparams(void)

{
  defparams_dsgc_movie();
  defparams_onplot_movie();

  setptr("theta", 	 &theta);
  setptr("iroff", 	 &iroff);
  setptr("light_inhib",  &light_inhib);
  setptr("dsgc_prefdir", &dsgc_prefdir);
  setptr("node_dist",    &node_dist);
  setptr("no_inhib",	 &no_inhib);
  setptr("ampa_cond",	 &ampa_cond);
  setptr("nmda_cond",	 &nmda_cond);
  setptr("rec_ct",	 &rec_ct);
  setptr("rec_cn",	 &rec_cn);
  setptr("sbarr",	 &sbarr);
  setptr("set_vclamp",	 &set_vclamp);

  setptr("barwidth",   &barwidth);
  setptr("minten",     &minten);
  setptr("sinten",     &sinten);
  setptr("velocity",   &velocity);
  setptr("disptime",   &disptime);
  setptr("ioffset",    &ioffset);
  setptr("istim",      &istim);
  setptr("stimdur",    &stimdur);
  setptr("prestimdur", &prestimdur);
  setptr("poststimdur",&poststimdur);
  setptr("sblur",      &sblur);
  setptr("movein",     &movein);
  setptr("predur",     &predur);
  setptr("sdia",       &sdia);
  setptr("sbaclm",     &sbaclm);
  setptr("sb_rid",     &sb_rid);
  setptr("sb_rii",     &sb_rii);
  setptr("sb_rip",     &sb_rip);
  setptr("sb_rm",      &sb_rm);
  setptr("sb_vs",      &sb_vs);
  setptr("sb_vr",      &sb_vr);

  setptr("namid",      &namid);
  setptr("nadist",     &nadist);

  setptr("kdist",      &kdist);
  setptr("kmid",       &kmid);
  setptr("kprox",      &kprox);
  setptr("ksoma",      &ksoma);

  setptr("camid",      &camid);
  setptr("cadist",     &cadist);

  nvalfile = "nval_dsgc_sbac.n";
  //fprintf (stderr,"makestim %d\n",makestim);
  sb_init();
}

/*--------------------------------------------------------*/

void setparams(void)

  /*  set up default configuration for sb expts */
  /* cones, cone bipolars, sb, dsgc */

{
   int i, ct;
   double zmax, zmin;

  make_rods  = 0;
  make_cones = 0;
  make_dbp1  = 1;
  make_dbp2  = 0;
  make_hbp1  = 0;
  make_hbp2  = 0;
  make_ams   = 0;
  make_sbac  = 1;
  make_dsgc  = 1;

  make_sbac_sbac = 1;
  ct=sbac;
  setn(ct,NCOLOR,RCOLOR);
  
#define SBARR 20

 if (!notinit(sbarr)) {		// array of sbac locations
   sbxarr = (double *)emalloc(SBARR*sizeof(double));
   sbyarr = (double *)emalloc(SBARR*sizeof(double));

   if (notinit (sbtheta)) sbtheta = 0;
   if (notinit(sdia)) sdia = 0.2;
   if (notinit(sbaclm)) sbaclm = 0.1;
   if (notinit(sb_rid)) sb_rid = dri;
   if (notinit(sb_rii)) sb_rii = dri;
   if (notinit(sb_rip)) sb_rip = dri;
   if (notinit(sb_rm))  sb_rm = drm;
   if (notinit(sb_vr))  sb_vr = -0.07;
   if (notinit(sb_vs))  sb_vs = -0.07;

   if (notinit(nadist))  nadist = 0e-3;
   if (notinit(namid))    namid = 0e-3;
   if (notinit(kdist))    kdist = 0e-3;
   if (notinit(kmid))      kmid = 0e-3;
   if (notinit(kprox))    kprox = 0e-3;
   if (notinit(ksoma))    ksoma = 0e-3;
   if (notinit(camid))    camid = 0e-3;
   if (notinit(cadist))  cadist = 0e-3;


   if (strcmp(sbac_file,"morph_sbac3b")==0 || strcmp(sbac_file,"morph_sbac3c")==0) {
      DENDD     = R_1;
      DEND_DIST = R_1;
      DEND      = R_2;	/* definitions of regions for dens_ file */
      DENDP     = R_3;
      DEND_PROX = R_3;
      SOMA      = R_4;
      HCK       = R_5;
      HILLOCK   = R_5;
      AXONT     = R_6;
      AXON_THIN = R_6;
      AXON      = R_7;
      AXONP     = R_7;
      AXON_PROX = R_7;
      AXOND     = R_8;
      AXON_DIST = R_8;
      VARIC     = R_9;
      VARICOS   = R_9;
     if (sbarr==0) {
       sbxarr[0] =  25; sbyarr[0] = 0;	/* only 1 SBAC */
       n_sbac = 1;
     }
     if (sbarr==1) {			/* sbac3b morphology, opposing dendrites */
       sbxarr[0] =  85; sbyarr[0] = 0;
       sbxarr[1] = -85; sbyarr[1] = 0;
       n_sbac = 2;
     }
     if (sbarr==2) {			/* sbac3b morphology, aligned dendrites */
       sbxarr[0] =  15; sbyarr[0] = 0;
       sbxarr[1] = -15; sbyarr[1] = 0;
       n_sbac = 2;
     }
     if (sbarr==4) {			/* sbac3b morphology, 3 aligned, 1 opposing */
       sbxarr[0] =  100; sbyarr[0] = 0;
       sbxarr[1] =   50; sbyarr[1] = 0;
       sbxarr[2] =    0; sbyarr[2] = 0;
       sbxarr[3] =  -50; sbyarr[3] = 0;
       n_sbac = 4;
     }
     if (sbarr==7) {			/* sbac3b morphology, 7 overlapping */
       sbxarr[0] =  150; sbyarr[0] = 0;
       sbxarr[1] =  100; sbyarr[1] = 0;
       sbxarr[2] =   50; sbyarr[2] = 0;
       sbxarr[3] =    0; sbyarr[3] = 0;
       sbxarr[4] =  -50; sbyarr[4] = 0;
       sbxarr[5] = -100; sbyarr[5] = 0;
       sbxarr[6] = -150; sbyarr[6] = 0;
       n_sbac = 7;
     }
     if (sbarr==102) {
       sbxarr[0] =  145; sbyarr[0] =  50;
       sbxarr[1] =  145; sbyarr[1] = -50;
       n_sbac = 2;
     }
   }
   else 
   if (strcmp(sbac_file,"morph_sb1")==0) {
      DENDD     = R_1;
      DEND_DIST = R_1;
      DEND      = R_2;	/* definitions of regions for dens_ file */
      DENDP     = R_3;
      DEND_PROX = R_3;
      SOMA      = R_4;
      HCK       = R_5;
      HILLOCK   = R_5;
      AXONT     = R_6;
      AXON_THIN = R_6;
      AXON      = R_7;
      AXONP     = R_7;
      AXON_PROX = R_7;
      AXOND     = R_8;
      AXON_DIST = R_8;
      VARIC     = R_9;
      VARICOS   = R_9;
     if (sbarr==0) {
       sbxarr[0] =  125; sbyarr[0] = 0;	/* only 1 SBAC */
       n_sbac = 1;
     }
     if (sbarr==1) {			/* sb1 morphology, opposing dendrites */
       sbxarr[0] =  105; sbyarr[0] = 0;
       sbxarr[1] = -105; sbyarr[1] = 0;
       n_sbac = 2;
     }
     if (sbarr==2) {			/* sb1 morphology, aligned dendrites */
       sbxarr[0] =  20; sbyarr[0] = 0;
       sbxarr[1] = -20; sbyarr[1] = 0;
       n_sbac = 2;
     }
     if (sbarr==4) {			/* sb1 morphology, 3 aligned, 1 opposing */
       sbxarr[0] =  100; sbyarr[0] = 0;
       sbxarr[1] =   50; sbyarr[1] = 0;
       sbxarr[2] =    0; sbyarr[2] = 0;
       sbxarr[3] =  -50; sbyarr[3] = 0;
       n_sbac = 4;
     }
     if (sbarr==7) {			/* sb1 morphology, 7 overlapping */
       sbxarr[0] =  150; sbyarr[0] = 0;
       sbxarr[1] =  100; sbyarr[1] = 0;
       sbxarr[2] =   50; sbyarr[2] = 0;
       sbxarr[3] =    0; sbyarr[3] = 0;
       sbxarr[4] =  -50; sbyarr[4] = 0;
       sbxarr[5] = -100; sbyarr[5] = 0;
       sbxarr[6] = -150; sbyarr[6] = 0;
       n_sbac = 7;
     }
     if (sbarr==102) {
       sbxarr[0] =  145; sbyarr[0] =  50;
       sbxarr[1] =  145; sbyarr[1] = -50;
       n_sbac = 2;
     }
   }
   if (strcmp(sbac_file,"morph_sbac_168")==0) {

      DENDD     = 100;
      DEND_DIST = 100;
      DEND      = 100;	/* definitions of regions for dens_ file */
      DENDP     = 100;
      DEND_PROX = 100;
      SOMA      = R_4;
      HCK       = 100;
      HILLOCK   = 100;
      AXONT     = 100;
      AXON_THIN = 100;
      AXON      = 100;
      AXONP     = 100;
      AXON_PROX = 100;
      AXOND     = 100;
      AXON_DIST = 100;
      VARIC     = 100;
      VARICOS   = 100;
     if (sbarr==0) {
       sbxarr[0] =  125; sbyarr[0] = 0;	/* only 1 SBAC */
       n_sbac = 1;
     }
     if (sbarr==1) {			/* sb1 morphology, opposing dendrites */
       sbxarr[0] =  105; sbyarr[0] = 0;
       sbxarr[1] = -105; sbyarr[1] = 0;
       n_sbac = 2;
     }
     if (sbarr==2) {			/* sb1 morphology, aligned dendrites */
       sbxarr[0] =  20; sbyarr[0] = 0;
       sbxarr[1] = -20; sbyarr[1] = 0;
       n_sbac = 2;
     }
     if (sbarr==4) {			/* sb1 morphology, 3 aligned, 1 opposing */
       sbxarr[0] =  100; sbyarr[0] = 0;
       sbxarr[1] =   50; sbyarr[1] = 0;
       sbxarr[2] =    0; sbyarr[2] = 0;
       sbxarr[3] =  -50; sbyarr[3] = 0;
       n_sbac = 4;
     }
     if (sbarr==7) {			/* sb1 morphology, 7 overlapping */
       sbxarr[0] =  150; sbyarr[0] = 0;
       sbxarr[1] =  100; sbyarr[1] = 0;
       sbxarr[2] =   50; sbyarr[2] = 0;
       sbxarr[3] =    0; sbyarr[3] = 0;
       sbxarr[4] =  -50; sbyarr[4] = 0;
       sbxarr[5] = -100; sbyarr[5] = 0;
       sbxarr[6] = -150; sbyarr[6] = 0;
       n_sbac = 7;
     }
     if (sbarr==102) {
       sbxarr[0] =  145; sbyarr[0] =  50;
       sbxarr[1] =  145; sbyarr[1] = -50;
       n_sbac = 2;
     }
   }
  }

  onplot_dsgc_movie_init();		/* initialize dsgc movie stuff */
  onplot_movie_init();			/* initialize onplot_movie stuff */

  gcdistnod  = 582;
  pickden[dsgc] = 0; //941;       	/* pick one dendrite to allow connections */
  if (notinit(ath_dia)) ath_dia = 0.4;	/* diameter of initial thin axon segment */

  if (n_dsgc>0) make_ct(dsgc);		/* make dsgcs if user specifies */

  if (!notinit(no_inhib)) { if (no_inhib==1) setsv(sbac,SCOND,3,0); } 


  if (notinit(dvrev)) dvrev = -0.06;
  if (notinit(dvst))  dvst  = -0.06;
  
  if (!notinit(ampa_cond)) setsv(dbp1,SCOND,2,ampa_cond);
  if (!notinit(nmda_cond)) setsv(dbp1,SCOND,7,nmda_cond);

  if(notinit(dsgc_prefdir)) dsgc_prefdir=0;
  for (i=0; i<NDSGC; i++) dsgc_pref[i] = dsgc_prefdir;
 

  if (strcmp(sbac_file,"morph_sb1")==0) {
    setsv (sbac,SYNANNI,3,75);                    /* don't connect close to soma */
  }
  else if (strcmp(sbac_file,"morph_sbac3b")==0) {
    setsv (sbac,SYNANNI,3,20);                    /* don't connect close to soma */
  }

  setn (dbp1,SDURH2,50);                    /* set 50 ms transient excit input to dsgc */
  setn (dbp1,SDURH7,50);                    /* set 50 ms transient nmda input to dsgc */
  setn (ams,SDURH1,50);                     /* set 50 ms transient inhib input to dsgc */

  // display_z(zmax=-24, zmin=-15);	    /* exclude dsgc Off-arborization layer */
}

/*--------------------------------------------------------*/

void runonexit (void)
{
       if (savefile[0]!=0)  unlink (savefile);
}

/*--------------------------------------------------------*/


void runexpt(void)

{
#define NUMCBPS 12
    int c, i, ct, cn, cbp_cn, pl, plnum;
    double start, dur, dscale, plsize;
    double ixoff, iyoff, disp_end, psize;
    double rmax, rmin;
    double Imax, Imin;
    double vhold, mvbrt1;
    node *npnt;
    elem *e;
    photorec *p;
    chattrib *a;
    int cbps[NUMCBPS];
    char sbuf[30];

  //ploti = 1e-3;
  ploti = 1e-4;
  timinc = 1e-6;

  cbp_cn    = 68;
  gcdistnod = 582;

  // e = at (ndn(dsgc,1,297), CHAN);
  // a = make_chan (e,NA,2);
  // chset(e);
  // xxx = e->elnum;
  // /* at [dsgc][1][297] chan Na type 2 chset ename xxx; */

  if (notinit(sblur)) sblur = 10;
//  if (notinit(stimdur))   stimdur=0.45;	/* used for non-moving stimuli */
  if (notinit(stimdur))     stimdur=0;	/* used for non-moving stimuli */
  if (notinit(poststimdur)) poststimdur = 0.1;
  
  Vmax  = -0.02;
  Vmaxg = 0.00;
  Vmin = -0.07;

   /* add light transducer to each bipolar cell */

   for(npnt=nodepnt; npnt=foreach(npnt,dbp1,-1,soma,NULL,&cn,NULL); npnt=npnt->next) {
     p = (photorec*)make_transducer(ndn(dbp1,cn,soma)); 
     p->xpos=npnt->xloc; 
     p->ypos=npnt->yloc;
   }

   if (notinit(theta))   theta = 0;	/* orientation of bar */
   if (notinit(iroff))   iroff = 1000;	/* r offset for inhib transducers */

   ixoff = iroff * cosdeg(theta);
   iyoff = iroff * -sindeg(theta);

   if (notinit(light_inhib)) light_inhib = 0; 
   if (light_inhib) {

     /* Add light transducer to each small-field amacrine cell */
     /*  offset so that inhibition can be controlled separately */

     for(npnt=nodepnt; npnt=foreach(npnt,ams,-1,soma,NULL,&cn,NULL); npnt=npnt->next) {
       p = (photorec*)make_transducer(ndn(ams,cn,soma)); 
       p->xpos=npnt->xloc + ixoff; 
       p->ypos=npnt->yloc + iyoff;
     }
   }

  /*  - - - - - - - - - - - - - - - - - - - */

   if (notinit(barwidth))        barwidth = 100;
   if (notinit(minten))            minten = -0.05;
   if (notinit(sinten))            sinten =  0.009;
   if (notinit(velocity))        velocity =  2000; 
   if (notinit(prestimdur))    prestimdur =  0;
   if (notinit(poststimdur))  poststimdur =  0.05;
   if (notinit(disptime))        disptime =  0.15;

   for (i=0; i<NUMCBPS; i++) {
      cbps[i] = 0;
   }

   cbps[0]  = findmid(dbp1,300,0);
   cbps[1]  = findmid(dbp1,250,0);
   cbps[2]  = findmid(dbp1,200,0);
   cbps[3]  = findmid(dbp1,150,0);
   cbps[4]  = findmid(dbp1,100,0);
   cbps[5]  = findmid(dbp1, 50,0);
   cbps[6]  = findmid(dbp1,  0,0);
   cbps[7]  = findmid(dbp1,-50,0);
   cbps[8]  = findmid(dbp1,-100,0);
   cbps[9]  = findmid(dbp1,-150,0);
   cbps[10]  = findmid(dbp1,-200,0);
   cbps[11]  = findmid(dbp1,-250,0);
   cbps[12]  = findmid(dbp1,-300,0);

   //cbps[0]  = 328;
   //cbps[1]  = 424;
   //cbps[2]  = 331;
   //cbps[3]  = 295;
   //cbps[4]  = 369;
   //cbps[5]  =  77;
   //cbps[6]  =  58;
   //cbps[7]  =  24;
   //cbps[8]  =  37;
   //cbps[9]  = 189;
 
  if (strcmp(sbac_file,"morph_sbac3b")==0) {
    if (sbarr==1) { 					// opposing sbacs
      synapse_add (1, sbac, 1, 1215, sbac, 2);		// add synapse for rate plot
      //synapse_add (1, sbac, 1, 1332, sbac, 2);		// add synapse for rate plot
      //synapse_add (1, sbac, 1, 1810, sbac, 2);		// add synapse for rate plot
      //synapse_add (1, sbac, 1, 3589, sbac, 2);		// add synapse for rate plot

      synapse_add (2, sbac, 2,  632, sbac, 1);		// add synapse for rate plot
      //synapse_add (2, sbac, 2,  293, sbac, 1);		// add synapse for rate plot
      //synapse_add (2, sbac, 2,   76, sbac, 1);		// add synapse for rate plot
      //synapse_add (2, sbac, 2,  271, sbac, 1);		// add synapse for rate plot
    }
    else if (sbarr==2) { 				// opposing sbacs
      synapse_add (1, sbac, 1, 1215, sbac, 2);		// add synapse for rate plot
      //synapse_add (1, sbac, 1, 1589, sbac, 2);		// add synapse for rate plot
      //synapse_add (1, sbac, 1, 1110, sbac, 2);		// add synapse for rate plot
      //synapse_add (1, sbac, 1, 1934, sbac, 2);		// add synapse for rate plot

      synapse_add (2, sbac, 2, 1718, sbac, 1);		// add synapse for rate plot
      //synapse_add (2, sbac, 2, 2023, sbac, 1);		// add synapse for rate plot
      //synapse_add (2, sbac, 2, 1157, sbac, 1);		// add synapse for rate plot
      //synapse_add (2, sbac, 2, 1166, sbac, 1);		// add synapse for rate plot
    }
  }
  if (strcmp(sbac_file,"morph_sb1")==0) {
    if (sbarr==1) { 					// opposing sbacs
     synapse_add (1, sbac, 1, 1173, sbac, 2);		// add synapse for rate plot
     synapse_add (1, sbac, 1, 1181, sbac, 2);
     synapse_add (1, sbac, 1, 1210, sbac, 2);
     synapse_add (1, sbac, 1, 1139, sbac, 2);
     synapse_add (1, sbac, 1,   76, sbac, 2);
     synapse_add (1, sbac, 1,   98, sbac, 2);

     synapse_add (2, sbac, 2, 502, sbac, 1);		// add synapse for rate plot
     synapse_add (2, sbac, 2, 447, sbac, 1);
     synapse_add (2, sbac, 2, 611, sbac, 1);
     synapse_add (2, sbac, 2, 397, sbac, 1);
     synapse_add (2, sbac, 2, 403, sbac, 1);
     synapse_add (2, sbac, 2, 685, sbac, 1);
    }
    else if (sbarr==2) {					// aligned sbacs
     synapse_add (1, sbac, 1,   34, sbac, 2);		// add synapse for rate plot
     synapse_add (1, sbac, 1, 1173, sbac, 2);
     synapse_add (1, sbac, 1,   46, sbac, 2);
     synapse_add (1, sbac, 1,   98, sbac, 2);
     synapse_add (1, sbac, 1, 1141, sbac, 2);

     synapse_add (2, sbac, 2, 1062, sbac, 1);		// add synapse for rate plot
     synapse_add (2, sbac, 2,   29, sbac, 1);
     synapse_add (2, sbac, 2,   72, sbac, 1);
     synapse_add (2, sbac, 2, 1112, sbac, 1);
     synapse_add (2, sbac, 2, 1203, sbac, 1);
   }
   else if (sbarr==4) {					// 3 aligned, 1 opposing
     synapse_add (1, sbac, 1, 1253, sbac, 2);		// add synapse for rate plot
     synapse_add (1, sbac, 1,   72, sbac, 2);		// add synapse for rate plot
     synapse_add (1, sbac, 1,   92, sbac, 3);		// add synapse for rate plot
     synapse_add (1, sbac, 1,   53, sbac, 3);		// add synapse for rate plot
     synapse_add (1, sbac, 1, 1243, sbac, 3);		// add synapse for rate plot
     synapse_add (1, sbac, 1, 1193, sbac, 4);		// add synapse for rate plot
     synapse_add (1, sbac, 1,   50, sbac, 4);		// add synapse for rate plot
     synapse_add (1, sbac, 1, 1205, sbac, 4);		// add synapse for rate plot
     
     synapse_add (2, sbac, 2, 1174, sbac, 1);		// add synapse for rate plot
     synapse_add (2, sbac, 2, 1029, sbac, 1);		// add synapse for rate plot
     synapse_add (2, sbac, 2, 1205, sbac, 3);		// add synapse for rate plot
     synapse_add (2, sbac, 2, 1150, sbac, 3);		// add synapse for rate plot
     synapse_add (2, sbac, 2, 1102, sbac, 4);		// add synapse for rate plot
     synapse_add (2, sbac, 2, 1206, sbac, 4);		// add synapse for rate plot
    
     synapse_add (3, sbac, 3,  848, sbac, 1);		// add synapse for rate plot
     synapse_add (3, sbac, 3,  837, sbac, 1);		// add synapse for rate plot
     synapse_add (3, sbac, 3, 1174, sbac, 2);		// add synapse for rate plot
     synapse_add (3, sbac, 3, 1029, sbac, 2);		// add synapse for rate plot
     synapse_add (3, sbac, 3, 1129, sbac, 4);		// add synapse for rate plot
     synapse_add (3, sbac, 3, 1062, sbac, 4);		// add synapse for rate plot

     synapse_add (4, sbac, 4,  464, sbac, 1);		// add synapse for rate plot
     synapse_add (4, sbac, 4,  504, sbac, 1);		// add synapse for rate plot
     synapse_add (4, sbac, 4,  619, sbac, 1);		// add synapse for rate plot
     synapse_add (4, sbac, 4,  685, sbac, 2);		// add synapse for rate plot
     synapse_add (4, sbac, 4,  379, sbac, 2);		// add synapse for rate plot
     synapse_add (4, sbac, 4,  600, sbac, 3);		// add synapse for rate plot
     synapse_add (4, sbac, 4,  714, sbac, 3);		// add synapse for rate plot
     synapse_add (4, sbac, 4,  766, sbac, 3);		// add synapse for rate plot
     synapse_add (4, sbac, 4,  432, sbac, 3);		// add synapse for rate plot
   }
   else if (sbarr==7) {					// 3 aligned, 1 opposing
     synapse_add (1, sbac, 1, 1253, sbac, 2);		// add synapse for rate plot
     synapse_add (1, sbac, 1,   72, sbac, 2);		// add synapse for rate plot
     synapse_add (1, sbac, 1,   92, sbac, 3);		// add synapse for rate plot
     synapse_add (1, sbac, 1,   53, sbac, 3);		// add synapse for rate plot
     synapse_add (1, sbac, 1, 1243, sbac, 3);		// add synapse for rate plot
     synapse_add (1, sbac, 1, 1193, sbac, 4);		// add synapse for rate plot
     synapse_add (1, sbac, 1,   50, sbac, 4);		// add synapse for rate plot
     synapse_add (1, sbac, 1, 1205, sbac, 4);		// add synapse for rate plot
    
     synapse_add (2, sbac, 2, 1174, sbac, 1);		// add synapse for rate plot
     synapse_add (2, sbac, 2, 1029, sbac, 1);		// add synapse for rate plot
     synapse_add (2, sbac, 2, 1205, sbac, 3);		// add synapse for rate plot
     synapse_add (2, sbac, 2, 1150, sbac, 3);		// add synapse for rate plot
     synapse_add (2, sbac, 2, 1102, sbac, 4);		// add synapse for rate plot
     synapse_add (2, sbac, 2, 1206, sbac, 4);		// add synapse for rate plot
    
     //synapse_add (3, sbac, 3,  848, sbac, 1);		// add synapse for rate plot
     //synapse_add (3, sbac, 3,  837, sbac, 1);		// add synapse for rate plot
     synapse_add (3, sbac, 3, 1174, sbac, 2);		// add synapse for rate plot
     synapse_add (3, sbac, 3, 1029, sbac, 2);		// add synapse for rate plot
     synapse_add (3, sbac, 3, 1129, sbac, 4);		// add synapse for rate plot
     synapse_add (3, sbac, 3, 1062, sbac, 4);		// add synapse for rate plot

     synapse_add (4, sbac, 4,  464, sbac, 1);		// add synapse for rate plot
     synapse_add (4, sbac, 4,  504, sbac, 1);		// add synapse for rate plot
     synapse_add (4, sbac, 4,  619, sbac, 1);		// add synapse for rate plot
     synapse_add (4, sbac, 4,  685, sbac, 2);		// add synapse for rate plot
     synapse_add (4, sbac, 4,  379, sbac, 2);		// add synapse for rate plot

     synapse_add (5, sbac, 4,  1029, sbac, 6);		// add synapse for rate plot
     synapse_add (5, sbac, 4,  1118, sbac, 6);		// add synapse for rate plot
     synapse_add (5, sbac, 4,   999, sbac, 5);		// add synapse for rate plot
     synapse_add (5, sbac, 4,  1041, sbac, 5);		// add synapse for rate plot

     //synapse_add (6, sbac, 5, 1205, sbac, 6);		// add synapse for rate plot
     //synapse_add (6, sbac, 5,   79, sbac, 7);		// add synapse for rate plot
     //synapse_add (6, sbac, 5,   30, sbac, 7);		// add synapse for rate plot
     synapse_add (6, sbac, 5,  609, sbac, 1);		// add synapse for rate plot

     synapse_add (7, sbac, 6,  387, sbac, 4);		// add synapse for rate plot
     //synapse_add (7, sbac, 6, 1029, sbac, 5);		// add synapse for rate plot
    
     synapse_add (8, sbac, 7,  440, sbac, 5);		// add synapse for rate plot
     synapse_add (8, sbac, 7,  320, sbac, 4);		// add synapse for rate plot
     synapse_add (8, sbac, 7,  340, sbac, 3);		// add synapse for rate plot
   }
  }

   set_run_on_exit(runonexit);                         // set to erase savefile on ^C
   sprintf (savefile,"dsgc_sbac_bar%06d",getpid());       // add pid to file name


   stim_backgr(minten,start=0.0);				  	 /* background */

   if (notinit(ioffset)) ioffset = barwidth;
   if (notinit(movein))   movein = -1;
   if (movein) {
     mvbrt1 = movebar (prestimdur,0,0,400,-400,barwidth,theta,velocity,sinten);	 /* excitatory */
     if (light_inhib)
              movebar (prestimdur,ixoff,iyoff,300+ioffset,-300+ioffset,
		     		barwidth,theta,velocity,sinten); /* inhib */ 
   }
   if (movein <= 0) {
     stimdur = movebar (prestimdur+mvbrt1,0,0,-400,400,barwidth,theta,velocity,sinten);	 /* excitatory */
     if (light_inhib)
              movebar (prestimdur,ixoff,iyoff,-300+ioffset,300+ioffset,
		     		barwidth,theta,velocity,sinten); /* inhib */ 
   };

   if (disp) {
	double t;

      if (light_inhib) display_size(2500); else display_size(800); 
      disp_end = 1600/velocity;
      for (t=0; t<disp_end; t+= 0.005) {
	   display_stim(prestimdur+t, dscale=4); 
	   simwait(0.15);
      }

      return;
    }

   if (notinit(istim)) istim = 0; 
   if (istim != 0) cclamp(ndn(dsgc,1,soma), istim, start=0.02, dur=1);

   if (make_movie) {
     if (space_time) {  /* movie */ 
      plot_v_nod(ct=dsgc,cn=1,soma,Vmin,Vmaxg,c=1,"Vsoma",pl=10,0.35);
      plot_v_nod(ct=dsgc,cn=1,1336,Vmin,Vmaxg,c=green,"Vtip1",pl=10,0.35);
      plot_v_nod(ct=dsgc,cn=1,582,Vmin,Vmaxg,c=red,"Vtip2",pl=10,0.35);
      //plot_na_inact(dsgc, 1, soma, red, "Na[soma]", 12, .35);
     };
   }
   else { 
    plot_v_nod(ct=sbac,cn=1,soma,Vmin,Vmax,blue,   "Vsoma1",pl=10,0.5);/* V at soma */
    plot_v_nod(ct=sbac,cn=2,soma,Vmin,Vmax,green,  "Vsoma2",pl=10,0.5);/* V at soma */
    plot_v_nod(ct=sbac,cn=3,soma,Vmin,Vmax,cyan,   "Vsoma3",pl=10,0.5);/* V at soma */
    plot_v_nod(ct=sbac,cn=4,soma,Vmin,Vmax,red,    "Vsoma4",pl=10,0.5);/* V at soma */
    plot_v_nod(ct=sbac,cn=5,soma,Vmin,Vmax,magenta,"Vsoma5",pl=10,0.5);/* V at soma */
    plot_v_nod(ct=sbac,cn=6,soma,Vmin,Vmax,yellow, "Vsoma6",pl=10,0.5);/* V at soma */
    plot_v_nod(ct=sbac,cn=7,soma,Vmin,Vmax,gray,   "Vsoma7",pl=10,0.5);/* V at soma */

    if (sbarr==1) {
      if (strcmp(sbac_file,"morph_sb1")==0) {
        plot_v_nod(ct=sbac,cn=1,1173,Vmin,Vmax,blue, "Vden1",pl=11,0.5);
        plot_v_nod(ct=sbac,cn=2,502, Vmin,Vmax,green,"Vden2",pl=11,0.5);
      }
      else if (strcmp(sbac_file,"morph_sbac3b")==0) {
        plot_v_nod(ct=sbac,cn=1,1215,Vmin,Vmax,blue, "Vden1",pl=11,0.5);
        plot_v_nod(ct=sbac,cn=2,632, Vmin,Vmax,green,"Vden2",pl=11,0.5);
      }
      plot_func(rsyn_avg,1,rmax=2000,rmin=0); plot_param("Rsbac1",blue, 12,0.3);
      plot_func(rsyn_avg,2,rmax=2000,rmin=0); plot_param("Rsbac2",green,12,0.3);
    }
    else if (sbarr==2) {
      if (strcmp(sbac_file,"morph_sb1")==0) {
        plot_v_nod(ct=sbac,cn=1,  34, Vmin,Vmax,blue, "Vden1",pl=11,0.5);
        plot_v_nod(ct=sbac,cn=2,1062, Vmin,Vmax,green,"Vden2",pl=11,0.5);
      }
      else if (strcmp(sbac_file,"morph_sbac3b")==0) {
        plot_v_nod(ct=sbac,cn=1,1215, Vmin,Vmax,blue, "Vden1",pl=11,0.5);
        plot_v_nod(ct=sbac,cn=2,1718, Vmin,Vmax,green,"Vden2",pl=11,0.5);
      }
      plot_func(rsyn_avg,1,rmax=2000,rmin=0); plot_param("Rsbac1",blue, 12,0.3);
      plot_func(rsyn_avg,2,rmax=2000,rmin=0); plot_param("Rsbac2",green,12,0.3);
    }
    else if (sbarr==4) {
      plot_v_nod(ct=sbac,cn=1,  1205, Vmin,Vmax,blue,   "Vden1",pl=11,0.5);
      plot_v_nod(ct=sbac,cn=2,  1206, Vmin,Vmax,green,  "Vden2",pl=11,0.5);
      plot_v_nod(ct=sbac,cn=3,  1174, Vmin,Vmax,cyan,   "Vden3",pl=11,0.5);
      plot_v_nod(ct=sbac,cn=4,   504, Vmin,Vmax,red,    "Vden4",pl=11,0.5);

      plot_func(rsyn_avg,1,rmax=2000,rmin=0); plot_param("Rsbac1",blue, 12,0.3);
      plot_func(rsyn_avg,2,rmax=2000,rmin=0); plot_param("Rsbac2",green,12,0.3);
      plot_func(rsyn_avg,3,rmax=2000,rmin=0); plot_param("Rsbac3",cyan, 12,0.3);
      plot_func(rsyn_avg,4,rmax=2000,rmin=0); plot_param("Rsbac4",red,  12,0.3);
    }
    else if (sbarr==7) {
      plot_v_nod(ct=sbac,cn=1,  1205, Vmin,Vmax,blue,   "Vden1",pl=11,0.5);
      plot_v_nod(ct=sbac,cn=2,  1206, Vmin,Vmax,green,  "Vden2",pl=11,0.5);
      plot_v_nod(ct=sbac,cn=3,  1174, Vmin,Vmax,cyan,   "Vden3",pl=11,0.5);
      plot_v_nod(ct=sbac,cn=4,  1174, Vmin,Vmax,red,    "Vden4a",pl=11,0.5);
      plot_v_nod(ct=sbac,cn=4,   504, Vmin,Vmax,ltred,  "Vden4b",pl=11,0.5);
      plot_v_nod(ct=sbac,cn=5,   600, Vmin,Vmax,magenta,"Vden5",pl=11,0.5);
      plot_v_nod(ct=sbac,cn=6,   600, Vmin,Vmax,yellow, "Vden6",pl=11,0.5);
      plot_v_nod(ct=sbac,cn=7,   600, Vmin,Vmax,gray,   "Vden7",pl=11,0.5);

      plot_func(rsyn_avg,1,rmax=2000,rmin=0); plot_param("Rsbac1",blue, 12,0.3);
      plot_func(rsyn_avg,2,rmax=2000,rmin=0); plot_param("Rsbac2",green,12,0.3);
      plot_func(rsyn_avg,3,rmax=2000,rmin=0); plot_param("Rsbac3",cyan, 12,0.3);
      plot_func(rsyn_avg,4,rmax=2000,rmin=0); plot_param("Rsbac4a",red,  12,0.3);
      plot_func(rsyn_avg,5,rmax=2000,rmin=0); plot_param("Rsbac4b",ltred,12,0.3);
      plot_func(rsyn_avg,6,rmax=2000,rmin=0); plot_param("Rsbac5",magenta,  12,0.3);
      plot_func(rsyn_avg,7,rmax=2000,rmin=0); plot_param("Rsbac6",yellow,  12,0.3);
      plot_func(rsyn_avg,8,rmax=2000,rmin=0); plot_param("Rsbac7",gray,  12,0.3);
    }

    plot_v_nod(ct=dbp1,cn=cbps[0],soma,Vmin,Vmax,c=1,"cbp1",pl=20,0.5);
    plot_v_nod(ct=dbp1,cn=cbps[1],soma,Vmin,Vmax,c=2,"cbp2",pl=20,0.5);
    plot_v_nod(ct=dbp1,cn=cbps[2],soma,Vmin,Vmax,c=3,"cbp3",pl=20,0.5);
    plot_v_nod(ct=dbp1,cn=cbps[3],soma,Vmin,Vmax,c=4,"cbp4",pl=20,0.5);
    plot_v_nod(ct=dbp1,cn=cbps[4],soma,Vmin,Vmax,c=5,"cbp5",pl=20,0.5);
    plot_v_nod(ct=dbp1,cn=cbps[5],soma,Vmin,Vmax,c=6,"cbp6",pl=20,0.5);
    plot_v_nod(ct=dbp1,cn=cbps[6],soma,Vmin,Vmax,c=7,"cbp7",pl=20,0.5);
    plot_v_nod(ct=dbp1,cn=cbps[7],soma,Vmin,Vmax,c=8,"cbp8",pl=20,0.5);
    plot_v_nod(ct=dbp1,cn=cbps[8],soma,Vmin,Vmax,c=9,"cbp9",pl=20,0.5);
    plot_v_nod(ct=dbp1,cn=cbps[9],soma,Vmin,Vmax,c=10,"cbp10",pl=20,0.5);
    plot_v_nod(ct=dbp1,cn=cbps[10],soma,Vmin,Vmax,c=11,"cbp11",pl=20,0.5);
    plot_v_nod(ct=dbp1,cn=cbps[11],soma,Vmin,Vmax,c=12,"cbp12",pl=20,0.5);
    plot_v_nod(ct=dbp1,cn=cbps[12],soma,Vmin,Vmax,c=13,"cbp13",pl=20,0.5);

    //plot_ca_nod(dsgc,1,soma,cyan,1e-6,"Ca_soma", -1, -1);
    //plot_ca_nod(dsgc,1,gcdistnod,1e-6,yellow,"", -1, -1);
    //plot_v_nod(ct=cbp,cbp_cn,axtrm,   Vmin,Vmax,red,"", -1, 0.35);
    //plot_v_nod(ct=cbp,41,axtrm,      Vmin,Vmax,blue,"", -1, 0.35);
    //plot_v_nod(ct=dsgc,cn=1,1336,Vmin,Vmax,c=green,"Vtip1",pl=10,0.35);
    //plot_v_nod(ct=dsgc,cn=1,582,Vmin,Vmax,c=red,"Vtip2",pl=10,0.35);
    //plot_v_nod(ct=dsgc,cn=1,422,      Vmin,Vmax,red,"", 10, 0.35);
    //plot_v_nod(ct=dsgc,cn=1,gcdistnod,Vmin,Vmaxg,c=red,"Vtip2", pl=10, .35);
    //plot_v_nod(ct=dsgc,cn=1,1336,      Vmin,Vmaxg,c=green,"Vtip1", pl=10, .35);
    //plot_v_nod(ct=dsgc,cn=1,1464,     Vmin,Vmaxg,c=blue,"", -1, -1);
    //plot_v_nod(ct=dsgc,cn=1,2328,     Vmin,Vmaxg,c=magenta,"",pl=10,1);
    //plot_synrate_out(cbp,cbp_cn,0,500,green);
    //plot_synrate_out(cbp,241,0,500,blue);
    //plot_currents(ct=dsgc,plgain=200e-12);

     if (notinit(node_dist)) node_dist = 281;
     plot_chan_current(ct=dsgc, cn=1, node_dist, NMDA, 1, 3e-12, -3e-12);
     sprintf (sbuf,"Inmda  %d",node_dist);
     plot_param (sbuf, blue, plnum=5, plsize=0.5);
     plot_chan_current(ct=dsgc, cn=1, node_dist, AMPA, 5, 3e-12, -3e-12);
     sprintf (sbuf,"Iampa  %d",node_dist);
     plot_param (sbuf, gray, plnum=5, plsize=0.5);

    if (notinit(set_vclamp)) set_vclamp = 0;
    if (set_vclamp > 0) {
      vhold = -0.07;
      vclamp (ndn(ct=dsgc,cn=1,soma),   vhold, simtime,  2);
      plot_i_nod(ct=dsgc,cn=1,soma,     Imin=-5000e-12,Imax=5000e-12,red,"", 1, 1);
      plot_v_nod(ct=dsgc,cn=1,soma,   Vmin,Vmax,green,"", 2, 0.35);
      plot_v_nod(ct=dsgc,cn=1,node_dist, Vmin,Vmax,magenta,"", 2, 0.35);
    } else {
      plot_v_nod(ct=dsgc,cn=1,soma,   Vmin,Vmax,red,"", 1, 0.35);
      plot_v_nod(ct=dsgc,cn=1,node_dist,   Vmin,Vmax,blue,"", 1, 0.35);
      // plot_spike_rate(ct=dsgc, cn=1, soma, red, "spike rate", pl=6, psize=0.3); 
    } 
   };

  if (notinit(predur)) predur=0.05;

  /* set movie plot routine */

  // setonplot(onplot_movie);

  /* run experiment */

  setxmin=0;
  simtime=0-predur;
  endexp=prestimdur+stimdur+poststimdur;
  step(predur);

  savemodel (savefile);
  step(prestimdur+mvbrt1);

  restoremodel (savefile);
  step(prestimdur+stimdur-mvbrt1+poststimdur);

  unlink (savefile);
  savefile[0] = 0;
}
