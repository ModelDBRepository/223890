/*  Neuron parameters for makcel.cc simulation script */

/* nval.h */

/* To add parameters, edit "maknval.cc", compile and run "maknval > nval.n",
   then copy nval.n to "nval.h". Remove the param defs from the end of nval.n.
   Remove the nval.n table at the beginning of nval.h.
   Copy nval.h to "nval_var.h", "nval_var.cc", and "nval_var_set.cc"
   and edit these files, then remove this content from nval.h.
   Last, "make clean" and "make retsim".
*/

#define XCONE        0	/* cones */
#define XROD         1	/* rods */
#define HBAT         2	/* hbat */
#define HA           3	/* Type A horizontal cells */
#define HB           4	/* Type B horizontal cells */
#define RBP          5	/* Rod bipolar cells */
#define DBP1         6	/* Depolarizing cone bipolar cell, type 1 */
#define DBP2         7	/* Depolarizing cone bipolar cell, type 2 */
#define HBP1         8	/* Hyperpolarizing bipolar cell, type 1 */
#define HBP2         9	/* Hyperpolarizing bipolar cell, type 2 */
#define A17         10	/* A17 amacrine cells, feedback to RBP */
#define AII         11	/* AII amacrine cells */
#define SBAC        12	/* Starburst amacrine cells */
#define AM          13	/* Amacrine cells */
#define AM2         14	/* Amacrine cells */
#define AMH         15	/* Amacrine cells, hyperpolarizing */
#define AMH2        16	/* Amacrine cells, hyperpolarizing */
#define AMS         17	/* Amacrine cells, small-field */
#define AMHS        18	/* Amacrine cells, small-field hyperpol */
#define GCA         19	/* Ganglion cells, On-type, alpha */
#define GCB         20	/* Ganglion cells, On-type, beta */
#define DSGC        21	/* Direction-selective ganglion cells */
#define GCAOFF      22	/* Ganglion cells, Off-type, alpha */
#define GCBOFF      23	/* Ganglion cells, Off-type, beta */
#define NCELTYPES   24	/* Number of cell types */

#define MAKE         0	 /* whether to make this cell type */
#define MAKE_DEND    1	 /* whether to make dendrites */
#define MAKE_AXON    2	 /* whether to make axon */
#define MAKE_DIST    3	 /* whether to make axon distal */
#define NMADE        4	 /* number of cells made */
#define MAXNUM       5	 /* maximum number of cells of this type */
#define NCOLOR       6	 /* color of this cell type for display */
#define MAXCOV       7	 /* max coverage factor (for arrays) */
#define MAXSYNI      8	 /* max number of syn input cells */
#define MAXSYNO      9	 /* max number of syn output cells */
#define DENS        10	 /* density of this type (per mm2) */
#define REGU        11	 /* regularity (mean/stdev) of spacing */
#define MORPH       12	 /* morphology (=0 -> file, or artificial) */
#define COMPLAM     13	 /* compartment size (default=complam) */
#define BIOPHYS     14	 /* add biophys properties (chan dens file) */
#define CHNOISE     15	 /* add membrane channel noise properties   */
#define RATIOK      16	 /* set K density values as ratio from Na */
#define VSTART      17	 /* initial resting potential */
#define VREV        18	 /* membrane potential for Rm (VCl) */
#define NRM         19	 /* the cell's Rm */
#define SOMADIA     20	 /* Soma diameter */
#define SOMAZ       21	 /* Z location (x,y loc determ. by array) */
#define DENDARB     22	 /* type of dendritic tree */
#define DENDARBZ    23	 /* dendritic arborization level */
#define DENZDIST    24	 /* dendritic arborization z tolerance */
#define STRATDIA    25	 /* stratif. annulus dia (fract of treedia) */
#define DTIPDIA     26	 /* diameter of dendritic tips */
#define DTREEDIA    27	 /* diameter of dendritic tree */
#define ARBSCALE    28	 /* scale for dia of real morph dend tree */
#define AXARBT      29	 /* type of axonal tree */
#define AXARBZ      30	 /* axonal arborization level */
#define AXTIPDIA    31	 /* diameter of axonal tips */
#define AXARBDIA    32	 /* diameter of axonal arbor */
#define MAXSDIST    33	 /* maximum synaptic distance */
#define TAPERSPC    34	 /* space constant of diameter taper */
#define TAPERABS    35	 /* abs diameter for taper */
#define NDENDR      36	 /* number of first-order dendrites */
#define GROWTHR     37	 /* distance thresh for growth of dendrites */

#define CELPRE1     38	 /* cell type to connect to (neg, no conn) */
#define CONPRE1     39	 /* connection number of presyn cell */
#define CELCONV1    40	 /* number of presyn cells to connect to */
#define GROWPOST1   41	 /* grow when making conn from presyn cell */
#define CELPRE2     42	 /* cell type to connect to (neg, no conn) */
#define CONPRE2     43	 /* connection number of presyn cell */
#define CELCONV2    44	 /* number of presyn cells to connect to */
#define GROWPOST2   45	 /* grow when making conn from presyn cell */
#define CELPRE3     46	 /* cell type to connect to (neg, no conn) */
#define CONPRE3     47	 /* connection number of presyn cell */
#define CELCONV3    48	 /* number of presyn cells to connect to */
#define GROWPOST3   49	 /* grow when making conn from presyn cell */
#define CELPRE4     50	 /* cell type to connect to (neg, no conn) */
#define CONPRE4     51	 /* connection number of presyn cell */
#define CELCONV4    52	 /* number of presyn cells to connect to */
#define GROWPOST4   53	 /* grow when making conn from presyn cell */
#define CELPRE5     54	 /* cell type to connect to (neg, no conn) */
#define CONPRE5     55	 /* connection number of presyn cell */
#define CELCONV5    56	 /* number of presyn cells to connect to */
#define GROWPOST5   57	 /* grow when making conn from presyn cell */
#define CELPRE6     58	 /* cell type to connect to (neg, no conn) */
#define CONPRE6     59	 /* connection number of presyn cell */
#define CELCONV6    60	 /* number of presyn cells to connect to */
#define GROWPOST6   61	 /* grow when making conn from presyn cell */
#define CELPRE7     62	 /* cell type to connect to (neg, no conn) */
#define CONPRE7     63	 /* connection number of presyn cell */
#define CELCONV7    64	 /* number of presyn cells to connect to */
#define GROWPOST7   65	 /* grow when making conn from presyn cell */
#define CELPRE8     66	 /* cell type to connect to (neg, no conn) */
#define CONPRE8     67	 /* connection number of presyn cell */
#define CELCONV8    68	 /* number of presyn cells to connect to */
#define GROWPOST8   69	 /* grow when making conn from presyn cell */
#define CELPRE9     70	 /* cell type to connect to (neg, no conn) */
#define CONPRE9     71	 /* connection number of presyn cell */
#define CELCONV9    72	 /* number of presyn cells to connect to */
#define GROWPOST9   73	 /* grow when making conn from presyn cell */
#define CELPRE10    74	 /* cell type to connect to (neg, no conn) */
#define CONPRE10    75	 /* connection number of presyn cell */
#define CELCONV10   76	 /* number of presyn cells to connect to */
#define GROWPOST10  77	 /* grow when making conn from presyn cell */

#define CELPOST1    78	 /* cell type to connect to (neg, no conn) */
#define CONPOST1    79	 /* connection number for postsyn cell */
#define CELDIV1     80	 /* number of postsyn cells to connect to */
#define GROWPRE1    81	 /* grow when making conn to postsyn cell */
#define SYNREG1     82	 /* synaptic region in presyn dendritic tree */
#define SYNREGP1    83	 /* synaptic region in postsyn dendritic tree */
#define SYNSPAC1    84	 /* synaptic spacing in presyn dendritic tree */
#define SYNANNI1    85	 /* inner rad of annulus in presyn dendr tree */
#define SYNANNO1    86	 /* outer rad of annulus in presyn dendr tree */
#define SYNANPI1    87	 /* inner rad of annulus in postsyn dend tree */
#define SYNANPO1    88	 /* outer rad of annulus in postsyn dend tree */
#define SYNANG1     89	 /* angle for postsynaptic cell */
#define SYNRNG1     90	 /* range of angles for postsynaptic cell */
#define USEDYAD1    91	 /* synapse is dyad using preexisting type */
#define DYADTYP1    92	 /* type of dyad synapse to connect with */
#define AUTAPSE1    93	 /* synapse back to presynaptic node */
#define SYNNUM1     94	 /* number of synapses per connection */
#define SENSCA1     95	 /* synaptic release sensitivity calcium */
#define SRRPOOL1    96	 /* synaptic readily releasable pool */
#define SMRRPOOL1   97	 /* synaptic max readily releasable pool */
#define SMAXRATE1   98	 /* maximum synaptic release rate */
#define SGAIN1      99	 /* synaptic gain */
#define SVGAIN1    100	 /* synaptic vgain */
#define SDURH1     101	 /* synaptic high pass time const. */
#define SNFILTH1   102	 /* synaptic high pass nfilt */
#define SHGAIN1    103	 /* synaptic high pass gain */
#define SHOFFS1    104	 /* synaptic high pass offset */
#define SVSIZ1     105	 /* synaptic vesicle size */
#define SCOND1     106	 /* synaptic conductance */
#define SCMUL1     107	 /* synaptic conductance mult for region */
#define SCGRAD1    108	 /* synaptic conductance gradient from soma */
#define SEGRAD1    109	 /* synaptic conductance expon grad fr soma */
#define STHRESH1   110	 /* synaptic threshold */
#define SVNOISE1   111	 /* 1 -> vesicle noise, override, vnoise=0 */
#define SCOV1      112	 /* 1=Poisson, <1->more regular, gamma dist */
#define SDUR1      113	 /* synaptic event time const. */
#define SFALL1     114	 /* synaptic event fall time const. */
#define SNFILT1    115	 /* synaptic vesicle nfilt */
#define STRCONC1   116	 /* synaptic transmitter concentration. */
#define SRESP1     117	 /* synaptic response (ampa,gaba,gj,etc. */
#define SCNFILT1   118	 /* second mesng. nfilt */
#define SCDUR1     119	 /* second mesng. time const. */
#define SCGAIN1    120	 /* synaptic second messenger gain */
#define SCOFF1     121	 /* synaptic second messenger offset */
#define SCNOISE1   122	 /* 1 -> channel noise, override cnoise=0 */
#define SNCHAN1    123	 /* number of channels */
#define SUNIT1     124	 /* synaptic channel unitary conductace */
#define SVREV1     125	 /* synaptic reversal potential */

#define CELPOST2   126	 /* cell type to connect to (neg, no conn) */
#define CONPOST2   127	 /* connection number for postsyn cell */
#define CELDIV2    128	 /* number of postsyn cells to connect to */
#define GROWPRE2   129	 /* grow when making conn to postsyn cell */
#define SYNREG2    130	 /* synaptic region in presyn dendritic tree */
#define SYNREGP2   131	 /* synaptic region in postsyn dendritic tree */
#define SYNSPAC2   132	 /* synaptic spacing in presyn dendritic tree */
#define SYNANNI2   133	 /* inner rad of annulus in presyn dendr tree */
#define SYNANNO2   134	 /* outer rad of annulus in presyn dend tree */
#define SYNANPI2   135	 /* inner rad of annulus in postsyn dend tree */
#define SYNANPO2   136	 /* outer rad of annulus in postsyn dend tree */
#define SYNANG2    137	 /* angle for postsynaptic cell */
#define SYNRNG2    138	 /* range of angles for postsynaptic cell */
#define USEDYAD2   139	 /* synapse is dyad using preexisting type */
#define DYADTYP2   140	 /* type of dyad synapse to connect with */
#define AUTAPSE2   141	 /* synapse back to presynaptic node */
#define SYNNUM2    142	 /* number of synapses per connection */
#define SENSCA2    143	 /* synaptic release sensitivity calcium */
#define SRRPOOL2   144	 /* synaptic readily releasable pool */
#define SMRRPOOL2  145	 /* synaptic max readily releasable pool */
#define SMAXRATE2  146	 /* maximum synaptic release rate */
#define SGAIN2     147	 /* synaptic gain */
#define SVGAIN2    148	 /* synaptic vgain */
#define SDURH2     149	 /* synaptic high pass time const. */
#define SNFILTH2   150	 /* synaptic high pass nfilt */
#define SHGAIN2    151	 /* synaptic high pass gain */
#define SHOFFS2    152	 /* synaptic high pass offset */
#define SVSIZ2     153	 /* synaptic vesicle size */
#define SCOND2     154	 /* synaptic conductance */
#define SCMUL2     155	 /* synaptic conductance mult for region */
#define SCGRAD2    156	 /* synaptic conductance grad from soma */
#define SEGRAD2    157	 /* synaptic conductance expon grad fr soma */
#define STHRESH2   158	 /* synaptic threshold */
#define SVNOISE2   159	 /* 1 -> vesicle noise, override,vnoise=0 */
#define SCOV2      160	 /* 1=Poisson, <1->more regular, gamma dist */
#define SDUR2      161	 /* synaptic event time const. */
#define SFALL2     162	 /* synaptic event fall time const. */
#define SNFILT2    163	 /* synaptic vesicle nfilt */
#define STRCONC2   164	 /* synaptic transmitter concentration. */
#define SRESP2     165	 /* synaptic response (ampa,gaba,gj,etc. */
#define SCNFILT2   166	 /* second mesng. nfilt */
#define SCDUR2     167	 /* second mesng. time const. */
#define SCGAIN2    168	 /* synaptic second messenger gain */
#define SCOFF2     169	 /* synaptic second messenger offset */
#define SCNOISE2   170	 /* 1 -> channel noise, override,cnoise=0 */
#define SNCHAN2    171	 /* number of channels */
#define SUNIT2     172	 /* synaptic channel unitary conductace */
#define SVREV2     173	 /* synaptic reversal potential */

#define CELPOST3   174	 /* cell type to connect to (neg, no conn) */
#define CONPOST3   175	 /* connection number for postsyn cell */
#define CELDIV3    176	 /* number of postsyn cells to connect to */
#define GROWPRE3   177	 /* grow when making conn to postsyn cell */
#define SYNREG3    178	 /* synaptic region in presyn dendritic tree */
#define SYNREGP3   179	 /* synaptic region in postsyn dendritic tree */
#define SYNSPAC3   180	 /* synaptic spacing in presyn dendritic tree */
#define SYNANNI3   181	 /* inner rad of annulus in presyn dendr tree */
#define SYNANNO3   182	 /* outer rad of annulus in presyn dendr tree */
#define SYNANPI3   183	 /* inner rad of annulus in postsyn dend tree */
#define SYNANPO3   184	 /* outer rad of annulus in postsyn dend tree */
#define SYNANG3    185	 /* angle for postsynaptic cell */
#define SYNRNG3    186	 /* range of angles for postsynaptic cell */
#define USEDYAD3   187	 /* synapse is dyad using preexisting type */
#define DYADTYP3   188	 /* type of dyad synapse to connect with */
#define AUTAPSE3   189	 /* synapse back to presynaptic node */
#define SYNNUM3    190	 /* number of synapses per connection */
#define SENSCA3    191	 /* synaptic release sensitivity calcium */
#define SRRPOOL3   192	 /* synaptic readily releasable pool */
#define SMRRPOOL3  193	 /* synaptic max readily releasable pool */
#define SMAXRATE3  194	 /* maximum synaptic release rate */
#define SGAIN3     195	 /* synaptic gain */
#define SVGAIN3    196	 /* synaptic vgain */
#define SDURH3     197	 /* synaptic high pass time const. */
#define SNFILTH3   198	 /* synaptic high pass nfilt */
#define SHGAIN3    199	 /* synaptic high pass gain */
#define SHOFFS3    200	 /* synaptic high pass offset */
#define SVSIZ3     201	 /* synaptic vesicle size */
#define SCOND3     202	 /* synaptic conductance */
#define SCMUL3     203	 /* synaptic conductance mult for region */
#define SCGRAD3    204	 /* synaptic conductance gradient from soma */
#define SEGRAD3    205	 /* synaptic conductance expon grad fr soma */
#define STHRESH3   206	 /* synaptic threshold */
#define SVNOISE3   207	 /* 1 -> vesicle noise, override,vnoise=0 */
#define SCOV3      208	 /* 1=Poisson, <1->more regular, gamma dist */
#define SDUR3      209	 /* synaptic event time const. */
#define SFALL3     210	 /* synaptic event fall time const. */
#define SNFILT3    211	 /* synaptic vesicle nfilt */
#define STRCONC3   212	 /* synaptic transmitter concentration. */
#define SRESP3     213	 /* synaptic response (ampa,gaba,gj,etc. */
#define SCNFILT3   214	 /* second mesng. nfilt */
#define SCDUR3     215	 /* second mesng. time const. */
#define SCGAIN3    216	 /* synaptic second messenger gain */
#define SCOFF3     217	 /* synaptic second messenger offset */
#define SCNOISE3   218	 /* 1 -> channel noise, override,cnoise=0 */
#define SNCHAN3    219	 /* number of channels */
#define SUNIT3     220	 /* synaptic channel unitary conductace */
#define SVREV3     221	 /* synaptic reversal potential */

#define CELPOST4   222	 /* cell type to connect to (neg, no conn) */
#define CONPOST4   223	 /* connection number for postsyn cell */
#define CELDIV4    224	 /* number of postsyn cells to connect to */
#define GROWPRE4   225	 /* grow when making conn to postsyn cell */
#define SYNREG4    226	 /* synaptic region in presyn dendritic tree */
#define SYNREGP4   227	 /* synaptic region in postsyn dendritic tree */
#define SYNSPAC4   228	 /* synaptic spacing in presyn dendritic tree */
#define SYNANNI4   229	 /* inner rad of annulus in presyn dendr tree */
#define SYNANNO4   230	 /* outer rad of annulus in presyn dendr tree */
#define SYNANPI4   231	 /* inner rad of annulus in postsyn dend tree */
#define SYNANPO4   232	 /* outer rad of annulus in postsyn dend tree */
#define SYNANG4    233	 /* angle for postsynaptic cell */
#define SYNRNG4    234	 /* range of angles for postsynaptic cell */
#define USEDYAD4   235	 /* synapse is dyad using preexisting type */
#define DYADTYP4   236	 /* type of dyad synapse to connect with */
#define AUTAPSE4   237	 /* synapse back to presynaptic node */
#define SYNNUM4    238	 /* number of synapses per connection */
#define SENSCA4    239	 /* synaptic release sensitivity calcium */
#define SRRPOOL4   240	 /* synaptic readily releasable pool */
#define SMRRPOOL4  241	 /* synaptic max readily releasable pool */
#define SMAXRATE4  242	 /* maximum synaptic release rate */
#define SGAIN4     243	 /* synaptic gain */
#define SVGAIN4    244	 /* synaptic vgain */
#define SDURH4     245	 /* synaptic high pass time const. */
#define SNFILTH4   246	 /* synaptic high pass nfilt */
#define SHGAIN4    247	 /* synaptic high pass gain */
#define SHOFFS4    248	 /* synaptic high pass offset */
#define SVSIZ4     249	 /* synaptic vesicle size */
#define SCOND4     250	 /* synaptic conductance */
#define SCMUL4     251	 /* synaptic conductance mult for region */
#define SCGRAD4    252	 /* synaptic conductance gradient from soma */
#define SEGRAD4    253	 /* synaptic conductance expon grad fr soma */
#define STHRESH4   254	 /* synaptic threshold */
#define SVNOISE4   255	 /* 1 -> vesicle noise, override,vnoise=0 */
#define SCOV4      256	 /* 1=Poisson, <1->more regular, gamma dist */
#define SDUR4      257	 /* synaptic event time const. */
#define SFALL4     258	 /* synaptic event fall time const. */
#define SNFILT4    259	 /* synaptic vesicle nfilt */
#define STRCONC4   260	 /* synaptic transmitter concentration. */
#define SRESP4     261	 /* synaptic response (ampa,gaba,gj,etc. */
#define SCNFILT4   262	 /* second mesng. nfilt */
#define SCDUR4     263	 /* second mesng. time const. */
#define SCGAIN4    264	 /* synaptic second messenger gain */
#define SCOFF4     265	 /* synaptic second messenger offset */
#define SCNOISE4   266	 /* 1 -> channel noise, override,cnoise=0 */
#define SNCHAN4    267	 /* number of channels */
#define SUNIT4     268	 /* synaptic channel unitary conductace */
#define SVREV4     269	 /* synaptic reversal potential */

#define CELPOST5   270	 /* cell type to connect to (neg, no conn) */
#define CONPOST5   271	 /* connection number for postsyn cell */
#define CELDIV5    272	 /* number of postsyn cells to connect to */
#define GROWPRE5   273	 /* grow when making conn to postsyn cell */
#define SYNREG5    274	 /* synaptic region in presyn dendritic tree */
#define SYNREGP5   275	 /* synaptic region in postsyn dendritic tree */
#define SYNSPAC5   276	 /* synaptic spacing in presyn dendritic tree */
#define SYNANNI5   277	 /* inner rad of annulus in presyn dendr tree */
#define SYNANNO5   278	 /* outer rad of annulus in presyn dendr tree */
#define SYNANPI5   279	 /* inner rad of annulus in postsyn dend tree */
#define SYNANPO5   280	 /* outer rad of annulus in postsyn dend tree */
#define SYNANG5    281	 /* angle for postsynaptic cell */
#define SYNRNG5    282	 /* range of angles for postsynaptic cell */
#define USEDYAD5   283	 /* synapse is dyad using preexisting type */
#define DYADTYP5   284	 /* type of dyad synapse to connect with */
#define AUTAPSE5   285	 /* synapse back to presynaptic node */
#define SYNNUM5    286	 /* number of synapses per connection */
#define SENSCA5    287	 /* synaptic release sensitivity calcium */
#define SRRPOOL5   288	 /* synaptic readily releasable pool */
#define SMRRPOOL5  289	 /* synaptic max readily releasable pool */
#define SMAXRATE5  290	 /* maximum synaptic release rate */
#define SGAIN5     291	 /* synaptic gain */
#define SVGAIN5    292	 /* synaptic vgain */
#define SDURH5     293	 /* synaptic high pass time const. */
#define SNFILTH5   294	 /* synaptic high pass nfilt */
#define SHGAIN5    295	 /* synaptic high pass gain */
#define SHOFFS5    296	 /* synaptic high pass offset */
#define SVSIZ5     297	 /* synaptic vesicle size */
#define SCOND5     298	 /* synaptic conductance */
#define SCMUL5     299	 /* synaptic conductance mult for region */
#define SCGRAD5    300	 /* synaptic conductance gradient from soma */
#define SEGRAD5    301	 /* synaptic conductance expon grad fr soma */
#define STHRESH5   302	 /* synaptic threshold */
#define SVNOISE5   303	 /* 1 -> vesicle noise, override,vnoise=0 */
#define SCOV5      304	 /* 1=Poisson, <1->more regular, gamma dist */
#define SDUR5      305	 /* synaptic event time const. */
#define SFALL5     306	 /* synaptic event fall time const. */
#define SNFILT5    307	 /* synaptic vesicle nfilt */
#define STRCONC5   308	 /* synaptic transmitter concentration. */
#define SRESP5     309	 /* synaptic response (ampa,gaba,gj,etc. */
#define SCNFILT5   310	 /* second mesng. nfilt */
#define SCDUR5     311	 /* second mesng. time const. */
#define SCGAIN5    312	 /* synaptic second messenger gain */
#define SCOFF5     313	 /* synaptic second messenger offset */
#define SCNOISE5   314	 /* 1 -> channel noise, override,cnoise=0 */
#define SNCHAN5    315	 /* number of channels */
#define SUNIT5     316	 /* synaptic channel unitary conductace */
#define SVREV5     317	 /* synaptic reversal potential */

#define CELPOST6   318	 /* cell type to connect to (neg, no conn) */
#define CONPOST6   319	 /* connection number for postsyn cell */
#define CELDIV6    320	 /* number of postsyn cells to connect to */
#define GROWPRE6   321	 /* grow when making conn to postsyn cell */
#define SYNREG6    322	 /* synaptic region in presyn dendritic tree */
#define SYNREGP6   323	 /* synaptic region in postsyn dendritic tree */
#define SYNSPAC6   324	 /* synaptic spacing in presyn dendritic tree */
#define SYNANNI6   325	 /* inner rad of annulus in presyn dendr tree */
#define SYNANNO6   326	 /* outer rad of annulus in presyn dendr tree */
#define SYNANPI6   327	 /* inner rad of annulus in postsyn dend tree */
#define SYNANPO6   328	 /* outer rad of annulus in postsyn dend tree */
#define SYNANG6    329	 /* angle for postsynaptic cell */
#define SYNRNG6    330	 /* range of angles for postsynaptic cell */
#define USEDYAD6   331	 /* synapse is dyad using preexisting type */
#define DYADTYP6   332	 /* type of dyad synapse to connect with */
#define AUTAPSE6   333	 /* synapse back to presynaptic node */
#define SYNNUM6    334	 /* number of synapses per connection */
#define SENSCA6    335	 /* synaptic release sensitivity calcium */
#define SRRPOOL6   336	 /* synaptic readily releasable pool */
#define SMRRPOOL6  337	 /* synaptic max readily releasable pool */
#define SMAXRATE6  338	 /* maximum synaptic release rate */
#define SGAIN6     339	 /* synaptic gain */
#define SVGAIN6    340	 /* synaptic vgain */
#define SDURH6     341	 /* synaptic high pass time const. */
#define SNFILTH6   342	 /* synaptic high pass nfilt */
#define SHGAIN6    343	 /* synaptic high pass gain */
#define SHOFFS6    344	 /* synaptic high pass offset */
#define SVSIZ6     345	 /* synaptic vesicle size */
#define SCOND6     346	 /* synaptic conductance */
#define SCMUL6     347	 /* synaptic conductance mult for region */
#define SCGRAD6    348	 /* synaptic conductance gradient from soma */
#define SEGRAD6    349	 /* synaptic conductance expon grad fr soma */
#define STHRESH6   350	 /* synaptic threshold */
#define SVNOISE6   351	 /* 1 -> vesicle noise, override,vnoise=0 */
#define SCOV6      352	 /* 1=Poisson, <1->more regular, gamma dist */
#define SDUR6      353	 /* synaptic event time const. */
#define SFALL6     354	 /* synaptic event fall time const. */
#define SNFILT6    355	 /* synaptic vesicle nfilt */
#define STRCONC6   356	 /* synaptic transmitter concentration. */
#define SRESP6     357	 /* synaptic response (ampa,gaba,gj,etc. */
#define SCNFILT6   358	 /* second mesng. nfilt */
#define SCDUR6     359	 /* second mesng. time const. */
#define SCGAIN6    360	 /* synaptic second messenger gain */
#define SCOFF6     361	 /* synaptic second messenger offset */
#define SCNOISE6   362	 /* 1 -> channel noise, override,cnoise=0 */
#define SNCHAN6    363	 /* number of channels */
#define SUNIT6     364	 /* synaptic channel unitary conductace */
#define SVREV6     365	 /* synaptic reversal potential */

#define CELPOST7   366	 /* cell type to connect to (neg, no conn) */
#define CONPOST7   367	 /* connection number for postsyn cell */
#define CELDIV7    368	 /* number of postsyn cells to connect to */
#define GROWPRE7   369	 /* grow when making conn to postsyn cell */
#define SYNREG7    370	 /* synaptic region in presyn dendritic tree */
#define SYNREGP7   371	 /* synaptic region in postsyn dendritic tree */
#define SYNSPAC7   372	 /* synaptic spacing in presyn dendritic tree */
#define SYNANNI7   373	 /* inner rad of annulus in presyn dendr tree */
#define SYNANNO7   374	 /* outer rad of annulus in presyn dendr tree */
#define SYNANPI7   375	 /* inner rad of annulus in postsyn dend tree */
#define SYNANPO7   376	 /* outer rad of annulus in postsyn dend tree */
#define SYNANG7    377	 /* angle for postsynaptic cell */
#define SYNRNG7    378	 /* range of angles for postsynaptic cell */
#define USEDYAD7   379	 /* synapse is dyad using preexisting type */
#define DYADTYP7   380	 /* type of dyad synapse to connect with */
#define AUTAPSE7   381	 /* synapse back to presynaptic node */
#define SYNNUM7    382	 /* number of synapses per connection */
#define SENSCA7    383	 /* synaptic release sensitivity calcium */
#define SRRPOOL7   384	 /* synaptic readily releasable pool */
#define SMRRPOOL7  385	 /* synaptic max readily releasable pool */
#define SMAXRATE7  386	 /* maximum synaptic release rate */
#define SGAIN7     387	 /* synaptic gain */
#define SVGAIN7    388	 /* synaptic vgain */
#define SDURH7     389	 /* synaptic high pass time const. */
#define SNFILTH7   390	 /* synaptic high pass nfilt */
#define SHGAIN7    391	 /* synaptic high pass gain */
#define SHOFFS7    392	 /* synaptic high pass offset */
#define SVSIZ7     393	 /* synaptic vesicle size */
#define SCOND7     394	 /* synaptic conductance */
#define SCMUL7     395	 /* synaptic conductance mult for region */
#define SCGRAD7    396	 /* synaptic conductance gradient from soma */
#define SEGRAD7    397	 /* synaptic conductance expon grad fr soma */
#define STHRESH7   398	 /* synaptic threshold */
#define SVNOISE7   399	 /* 1 -> vesicle noise, override,vnoise=0 */
#define SCOV7      400	 /* 1=Poisson, <1->more regular, gamma dist */
#define SDUR7      401	 /* synaptic event time const. */
#define SFALL7     402	 /* synaptic event fall time const. */
#define SNFILT7    403	 /* synaptic vesicle nfilt */
#define STRCONC7   404	 /* synaptic transmitter concentration. */
#define SRESP7     405	 /* synaptic response (ampa,gaba,gj,etc. */
#define SCNFILT7   406	 /* second mesng. nfilt */
#define SCDUR7     407	 /* second mesng. time const. */
#define SCGAIN7    408	 /* synaptic second messenger gain */
#define SCOFF7     409	 /* synaptic second messenger offset */
#define SCNOISE7   410	 /* 1 -> channel noise, override,cnoise=0 */
#define SNCHAN7    411	 /* number of channels */
#define SUNIT7     412	 /* synaptic channel unitary conductace */
#define SVREV7     413	 /* synaptic reversal potential */

#define CELPOST8   414	 /* cell type to connect to (neg, no conn) */
#define CONPOST8   415	 /* connection number for postsyn cell */
#define CELDIV8    416	 /* number of postsyn cells to connect to */
#define GROWPRE8   417	 /* grow when making conn to postsyn cell */
#define SYNREG8    418	 /* synaptic region in presyn dendritic tree */
#define SYNREGP8   419	 /* synaptic region in postsyn dendritic tree */
#define SYNSPAC8   420	 /* synaptic spacing in presyn dendritic tree */
#define SYNANNI8   421	 /* inner rad of annulus in presyn dendr tree */
#define SYNANNO8   422	 /* outer rad of annulus in presyn dendr tree */
#define SYNANPI8   423	 /* inner rad of annulus in postsyn dend tree */
#define SYNANPO8   424	 /* outer rad of annulus in postsyn dend tree */
#define SYNANG8    425	 /* angle for postsynaptic cell */
#define SYNRNG8    426	 /* range of angles for postsynaptic cell */
#define USEDYAD8   427	 /* synapse is dyad using preexisting type */
#define DYADTYP8   428	 /* type of dyad synapse to connect with */
#define AUTAPSE8   429	 /* synapse back to presynaptic node */
#define SYNNUM8    430	 /* number of synapses per connection */
#define SENSCA8    431	 /* synaptic release sensitivity calcium */
#define SRRPOOL8   432	 /* synaptic readily releasable pool */
#define SMRRPOOL8  433	 /* synaptic max readily releasable pool */
#define SMAXRATE8  434	 /* maximum synaptic release rate */
#define SGAIN8     435	 /* synaptic gain */
#define SVGAIN8    436	 /* synaptic vgain */
#define SDURH8     437	 /* synaptic high pass time const. */
#define SNFILTH8   438	 /* synaptic high pass nfilt */
#define SHGAIN8    439	 /* synaptic high pass gain */
#define SHOFFS8    440	 /* synaptic high pass offset */
#define SVSIZ8     441	 /* synaptic vesicle size */
#define SCOND8     442	 /* synaptic conductance */
#define SCMUL8     443	 /* synaptic conductance mult for region */
#define SCGRAD8    444	 /* synaptic conductance gradient from soma */
#define SEGRAD8    445	 /* synaptic conductance expon grad fr soma */
#define STHRESH8   446	 /* synaptic threshold */
#define SVNOISE8   447	 /* 1 -> vesicle noise, override, vnoise=0 */
#define SCOV8      448	 /* 1=Poisson, <1->more regular, gamma dist */
#define SDUR8      449	 /* synaptic event time const. */
#define SFALL8     450	 /* synaptic event fall time const. */
#define SNFILT8    451	 /* synaptic vesicle nfilt */
#define STRCONC8   452	 /* synaptic transmitter concentration. */
#define SRESP8     453	 /* synaptic response (ampa,gaba,gj,etc. */
#define SCNFILT8   454	 /* second mesng. nfilt */
#define SCDUR8     455	 /* second mesng. time const. */
#define SCGAIN8    456	 /* synaptic second messenger gain */
#define SCOFF8     457	 /* synaptic second messenger offset */
#define SCNOISE8   458	 /* 1 -> channel noise, override,cnoise=0 */
#define SNCHAN8    459	 /* number of channels */
#define SUNIT8     460	 /* synaptic channel unitary conductace */
#define SVREV8     461	 /* synaptic reversal potential */

#define NPARAMS    462	 /* number of neuron parameters */

#define CELPRE       0	/* cell type to connect to (neg, no conn) */
#define CONPRE       1	/* connection number of presyn cell */
#define CELCONV      2	/* number of presyn cells to connect to */
#define GROWPOST     3	/* grow when making conn from presyn cell */
#define NCONNP       4	/* number of connection parameters */

#define CELPOST      0	/* cell type to connect to (neg, no conn) */
#define CONPOST      1	/* connection number for postsyn cell */
#define CELDIV       2	/* number of postsyn cells to connect to */
#define GROWPRE      3	/* grow when making conn to postsyn cell */
#define SYNREG       4	/* synaptic region in presyn dendritic tree */
#define SYNREGP      5	/* synaptic region in postsyn dendritic tree */
#define SYNSPAC      6	/* synaptic spacing in presyn dendritic tree */
#define SYNANNI      7	/* inner dia of annulus in presyn dendr tree */
#define SYNANNO      8	/* outer dia of annulus in presyn dendr tree */
#define SYNANPI      9	/* inner dia of annulus in postsyn dend tree */
#define SYNANPO     10	/* outer dia of annulus in postsyn dend tree */
#define SYNANG      11	/* angle for postsynaptic cell */
#define SYNRNG      12	/* range of angles for postsynaptic cell */
#define USEDYAD     13	/* synapse is dyad using preexisting type */
#define DYADTYP     14	/* type of dyad synapse to connect with */
#define AUTAPSE     15	/* synapse back to presynaptic node */
#define SYNNUM      16	/* number of synapses per connection */
#define SENSCA      17	/* synaptic release sensitivity calcium */
#define SRRPOOL     18	/* synaptic readily releasable pool */
#define SMRRPOOL    19	/* synaptic max readily releasable pool */
#define SMAXRATE    20	/* maximum synaptic release rate */
#define SGAIN       21	/* synaptic gain */
#define SVGAIN      22	/* synaptic vgain */
#define SDURH       23	/* synaptic high pass time const. */
#define SNFILTH     24	/* synaptic high pass nfilt */
#define SHGAIN      25	/* synaptic high pass gain */
#define SHOFFS      26	/* synaptic high pass offset */
#define SVSIZ       27	/* synaptic vesicle size */
#define SCOND       28	/* synaptic conductance */
#define SCMUL       29	/* synaptic conductance mult for region */
#define SCGRAD      30	/* synaptic conductance gradient from soma */
#define SEGRAD      31	/* synaptic conductance expon grad fr soma */
#define STHRESH     32	/* synaptic threshold */
#define SVNOISE     33	/* 1 -> vesicle noise, override,vnoise=0 */
#define SCOV        34	/* 1=Poisson, <1->more regular, gamma dist */
#define SDUR        35	/* synaptic event time const. */
#define SFALL       36	/* synaptic event fall time const. */
#define SNFILT      37	/* synaptic vesicle nfilt */
#define STRCONC     38	/* synaptic transmitter concentration. */
#define SRESP       39	/* synaptic response (ampa,gaba,gj,etc. */
#define SCNFILT     40	/* second mesng. nfilt */
#define SCDUR       41	/* second mesng. time const. */
#define SCGAIN      42	/* synaptic second messenger gain */
#define SCOFF       43	/* synaptic second messenger offset */
#define SCNOISE     44	/* 1 -> channel noise, override,cnoise=0 */
#define SNCHAN      45	/* number of channels */
#define SUNIT       46	/* synaptic channel unitary conductace */
#define SVREV       47	/* synaptic reversal potential */
#define NSYNP       48	/* number of synaptic parameters */

#define NCONNI      10	/* number of input connection cell types */
#define NCONNO       8	/* number of output connection cell types  */

#define XGLUT        1	/* generic glutamate response */
#define XAMPA        2	/* AMPA (type 1) synaptic response */
#define XAMPA1       3	/* AMPA type 1 synaptic response */
#define XAMPA2       4	/* AMPA type 2 synaptic response */
#define XAMPA3       5	/* AMPA type 3 synaptic response */
#define XAMPA4       6	/* AMPA type 4 synaptic response */
#define XAMPA5       7	/* AMPA type 5 synaptic response */
#define XNMDA        8	/* NMDA type 1 synaptic response */
#define XNMDA2       9	/* NMDA type 2 synaptic response */
#define XKAINATE    10	/* Kainate synaptic response */
#define XMGLUR6     11	/* mGluR6 synaptic response */
#define XGABA       12	/* GABA type 1 synaptic response */
#define XGABA1      13	/* GABA type 1 synaptic response */
#define XGABA2      14	/* GABA type 2 synaptic response */
#define XGABA3      15	/* GABA type 3 synaptic response */
#define XGLY        16	/* Glycine synaptic response */
#define XGAPJ       17	/* gap junction synaptic response */
#define XDYAD       18	/* dyad synapse (uses other resp type) */
#define NRESPTYPES  19	/* number of synaptic types */

