

The simulations in this directory were developed to test
the function of the spike generator in a beta ganglion cell
of cat.  The results are to be published in the Journal of
Neurophysiology, 2003.

   Van Rossum MCW, O'Brien BJ, Smith RG (2003) Effects of Noise
   on the Spike Timing Precision of Retinal Ganglion Cells. 
   J. Neurophysiol. 89:2406-2419. 
