
The simulations in this directory were developed to test the
effect of gap junctions on neural blur and S/N ratio in the cone
array. The results were published in 

  DeVries SH, Qi X, Smith R, Makous W, Sterling P, (2002)
  Electrical Coupling between Mammalian Cones.  Current Biology 12:
  1900-1907.

