
/* retcolors.h */

/* standard colors */

#define black	0
#define blue	1
#define green	2
#define cyan	3
#define red	4
#define magenta	5
#define yellow	6
#define white	7

#define gray	8
#define ltblue  9
#define ltgreen	10
#define ltcyan  11
#define ltred	12
#define ltmag	13
#define ltyel	14
#define brtwht  15

