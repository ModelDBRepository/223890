/* module ncio.h in program nc */

extern int ncfprintf(FILE *stream, const char *format, ...);

