/* ncnode.cc */

/* Routines to make and access nodes */

#include "nc.h"
#include "y.tab.h"
#include "ncsub.h"
#include "ncelem.h"

#define NHASHSIZ 199                     /* prime number to make better hash */

node *nhashtab[NHASHSIZ] = {0};  /* node hash table */

#ifdef __cplusplus
extern "C" {
#endif

#include <stdio.h>

#ifdef __cplusplus
}
#endif

#include "ncio.h"

extern node *nodepnt;
extern node *nodend;
extern int cumnode;

char *emalloc(unsigned int n);
void execerror(const char *s, const char *t);
void efree(void *ptr);

/*---------------------------------------------------*/

/*
void xdebugf(void)

{
   ncfprintf (stderr,"nhashtab %d\n",nhashtab[5]);
}
*/

/*---------------------------------------------------*/

void ninithash(void)
{
   int i;

   for (i=0; i<NHASHSIZ; i++) 
     nhashtab[i] = NULL;
}

/*---------------------------------------------------*/

int nodehash(nodeint nodea, nodeint nodeb, 
	     nodeint nodec, nodeint noded)

/* Make disordered index of node number */

{
   int i;

   i = 0;
   if (nodea!=NULLVAL) i += nodea; 
   if (nodeb!=NULLVAL) i += nodeb; 
   if (nodec!=NULLVAL) i += nodec; 
   if (noded!=NULLVAL) i += noded; 
   if (i<0) i = -i;
   return (i % NHASHSIZ); 
}

/*---------------------------------------------------*/

void ninstall (node *newnod, nodeint na, nodeint nb, 
			     nodeint nc, nodeint nd)
              
/* Install a symbol in hash table */
/*  Uses "direct chaining" with field "hnext". */

{
    int i;
    node *npnt,*nlast;
    static int ninitfl=0;

   if (!ninitfl) {			/* initialize table once at start */
        ninitfl = 1;
        ninithash();
   }
   newnod->hnext = 0;
   i=nodehash(na,nb,nc,nd); 		/* initial index into nhashtab*/ 
   if ((npnt=nhashtab[i])==NULL) {      /* install directly in table */
      nhashtab[i] = newnod;
   }
   else {                               /* otherwise, go to end of list */
      for (; npnt; npnt=npnt->hnext)    /* find last symbol */
          nlast = npnt;    
      nlast->hnext = newnod;            /* put new symbol at end of list */
   }
}

/*---------------------------------------------------*/

node *maknod(nodeint nodea, nodeint nodeb, 
	     nodeint nodec, nodeint noded)
                          
/* make a new node, and link it to the
   beginning of the node list. */

{
    node *npnt;
 
  if ((npnt=(node *)emalloc(sizeof(node))) == NULL) {
     ncfprintf (stderr,"no space left for node %d\n",cumnode+1);
     return ((node *)NULL);  
  }
  npnt->next = nodepnt;		/* Set up "next" to connect all nodes. */
  nodepnt = npnt;  		/*  We use "hnext" for hash table. */
  if (nodend==NULL)
    nodend = npnt;


  ninstall(npnt,nodea,nodeb,nodec,noded);	/* install in hash table */

  nodepnt->elemlst = (conlst *)NULL;
  nodepnt->comptr = (comp *)NULL;
  nodepnt->compnum = 0;
  nodepnt->ctype = NODE;
/*
  if (nodea > MAXSHORT || nodeb > MAXSHORT || 
      nodec > MAXSHORT || noded > MAXSHORT)   {
    ncfprintf (stderr,"Node number %d %d %d %d too large\n",
			nodea,nodeb,nodec,noded);
    execerror ("Bad node value: ","stopping...");
  }
*/
  if (nodea < 0 || nodeb < 0 || nodec < 0 || nodec < 0) {
    if (nodea > NULLVAL && nodeb > NULLVAL && 
	nodec > NULLVAL && noded > NULLVAL) { 
    ncfprintf (stderr,"Node number %d %d %d %d is negative\n",
			nodea,nodeb,nodec,noded);
    execerror ("Bad node value: ","stopping...");
   }
  }
  nodepnt->nodenm1 = nodea;
  nodepnt->nodenm2 = nodeb;
  nodepnt->nodenm3 = nodec;
  nodepnt->nodenm4 = noded;
  nodepnt->xloc = LARGENODE;
  nodepnt->yloc = LARGENODE;
  nodepnt->zloc = LARGENODE;
  nodepnt->region = NULLVAL;
  nodepnt->dendn = NULLVAL;
  nodepnt->label = NULLVAL;
  nodepnt->labeltext = NULL;
  cumnode++;                    /* increment total */
  return (nodepnt); 
}

/*---------------------------------------------------*/

void delnode (node *npnt)

/* Delete a node, given a pointer to it. */
/* Don't delete node's element list because this is done by "erasenode()" */

{
   int i,found;
   node *nlast,*npt;

  if (!npnt) return;
  if (npnt->comptr) {
     ncfprintf (stderr,"delnode: can't delete node: it has a compartment.\n");
	  return;			/* stop if compartment */ 
  }

/* ncfprintf (stderr," %d %d %d %d\n", 
	npnt->nodenm1,npnt->nodenm2,npnt->nodenm3,npnt->nodenm4); */

	/* First, delete from hash table: */

  i = nodehash (npnt->nodenm1,npnt->nodenm2,npnt->nodenm3,npnt->nodenm4);
  nlast = (node *)NULL;
  for (found=0, npt=nhashtab[i]; npt; nlast=npt, npt=npt->hnext) {
    if (npt==npnt) {
        found = 1;
        break;
    }
  }
  if (found) {
     if (nlast!=NULL) nlast->hnext = npt->hnext;     /* delete hash pointer */
     else nhashtab[i] = npt->hnext;
  }

	/* Patch next pointer */

  nlast = (node *)NULL;			/* find last node */
  for (found=0,npt=nodepnt; npt; nlast=npt, npt=npt->next) {
      if (npt==npnt) {
	 found = 1;
         break;
      }
  } 
  if (found) {
     if (nlast) nlast->next = npt->next;     /* patch last pointer */
     if (nodepnt==npt) nodepnt = npt->next; 
     if (nodend==npt)
         nodend = nlast; 
     efree (npnt);
     cumnode--;
  }
}

/*---------------------------------------------------*/

node *findnode(nodeint num1, nodeint num2, 
		nodeint num3, nodeint num4, const char *str)
                      
/* Find node among list of all nodes.
   Nodes are placed in hash table, which provides
   faster access than possible with one sequential list.
   The node itself is not moved, therefore only the 
   pointers of the node list need rearranging.
   Pointers in other lists that point to nodes remain correct.
*/

{
   node *npnt;
   int i,found;
   char sbuf[100];
   static int err=0;

  i = nodehash(num1,num2,num3,num4);
  for (found=0,npnt = nhashtab[i]; npnt; npnt = npnt->hnext) {
    if ((npnt->nodenm1==num1) && (npnt->nodenm2==num2) &&
        (npnt->nodenm3==num3) && (npnt->nodenm4==num4)) {
       found = 1;
       break;
    }
  }

  if (found) return npnt;
  else {
    if (str) {
      if (num4 != NULLVAL)
         sprintf (sbuf,"%.40s: can't find node %d %d %d %d\n",str,num1,num2,num3,num4);
      else if (num3 != NULLVAL)
         sprintf (sbuf,"%.40s: can't find node %d %d %d\n",str,num1,num2,num3);
      else if (num2 != NULLVAL)
         sprintf (sbuf,"%.40s: can't find node %d %d\n",str,num1,num2);
      else 
         sprintf (sbuf,"%.40s: can't find node %d\n",str,num1);

      if (!err) {
         execerror("nc: ",sbuf);
	 // ncfprintf (stderr,sbuf);
	 err = 1;
      }
    }
   return (node *)NULL; 
  }
}

/*---------------------------------------------------*/

node *findnode(nodeint num1, nodeint num2, nodeint num3, const char *str)

{
   findnode(num1, num2, num3, NULLVAL, str);
}

/*---------------------------------------------------*/

node *findnode(nodeint num1, nodeint num2, const char *str)

{
   findnode(num1, num2, NULLVAL, NULLVAL, str);
}
	/*---------------------------------------------------*/

node *findnode(nodeint num1, const char *str)

{
   findnode(num1, NULLVAL, NULLVAL, NULLVAL, str);
}

/*---------------------------------------------------*/
                      
