/* ncinit.h */

/* defines "setptrs()" to null proc if not already defined */

#ifndef SETPTRS
void setptrs(void) {}
#endif
