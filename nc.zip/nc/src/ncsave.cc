/* Module ncsave in Program nc */

/* saves parameters */

#include <sys/types.h>
#include <unistd.h>
#include <string.h>

#include "ncsub.h"
#include "ncomp.h"

#ifdef __cplusplus
extern "C" {
#endif

#include <stdio.h>
#include <stdlib.h>

#ifdef __cplusplus
}
#endif

#include "nc.h"
#include "y.tab.h"
#include "control.h"

#include "ncio.h"

extern comp  *compnt;
extern synap *synpnt;
extern photrec *recpnt;
extern chan *chanpnt;

extern int cumcomp;
extern int cumsynap;
extern int cumgj;
extern int cumphotrec;
extern int cumchan;
extern int cumdbuf;

extern char *infile;

void execerror(const char *s, const char *t);
char *emalloc (unsigned int n);
comp *findcomp(int num, const char *str);
int findphotrec(int num1, int num2, int num3, int num4, photrec **rpnt, const char *str);
char *print_version(double version);

static char ebuf[200];

/*---------------------------------------*/

void savemodel (const char *filnam)

/* save all state variables into a file for later restoration */

{
   int i, nf, cashell,caoshell, delay;
   double gain;
   double v, offset;
   comp *cpnt;
   photrec *rpnt;
   synap *spnt;
   chan *chpnt;
   FILE *sfil;
   cacomp *capnt;
   ntcomp *ntpnt,*npt;
   lpfilt *lpf;
   
 if      (strcmp(filnam,"stdout") ==0) sfil = stdout;
 else if (strcmp(filnam,"stderr") ==0) sfil = stderr;
 else if ((sfil=fopen(filnam,"w"))==NULL) {
    sprintf (ebuf,"savemodel: can't open file '%.50s'.\n",filnam);
    execerror ("warning,",ebuf);
    return; 
 }

 fprintf (sfil,"## nc version %s pid %d running '%s'\n", 
		print_version(ncversion), getpid(),infile);
 fprintf (sfil,"## model save at %g sec\n",simtime);
 fprintf (sfil,"## comps=%d chans=%d syns=%d photorecs=%d\n",
			cumcomp,cumchan,cumsynap+cumgj+cumdbuf,cumphotrec);

 if (cumcomp >= 1) {
  fprintf (sfil,"# compartments num v relax\n");
  for (cpnt=compnt; cpnt; cpnt=cpnt->next) {            /* save compartments */
    fprintf (sfil,"c   %4d %.16g %.16g %.8g\n",cpnt->num,cpnt->v,cpnt->oldv,cpnt->relax);
    if (capnt=cpnt->capnt) {
      cashell = capnt->cashell;
      fprintf (sfil,"cai vr %.16g sh %d ",capnt->vrev,cashell);
      if (capnt->cab) {
        fprintf (sfil,"b %d",1);
        for (i=0; i<cashell; i++) {
          fprintf (sfil," %.16g %.16g",capnt->cais[i],capnt->cab[i]);
        }
      }
      else {
        fprintf (sfil,"b %d",0);
      	  for (i=0; i<cashell; i++) {
            fprintf (sfil," %.16g",capnt->cais[i]);
	  }
      }
      caoshell = capnt->caoshell;
      fprintf (sfil," cao sh %d ",caoshell);
      if (capnt->caos!=NULL)
        for (i=0; i<caoshell; i++) {
           fprintf (sfil," %.16g",capnt->caos[i]);
        }
      fprintf (sfil," %.16g %.16g",capnt->cas,capnt->cas2);	/* CICR local Ca store */
      fprintf (sfil,"\n");
    }  /* if capnt */
    if (ntpnt=cpnt->ntpnt) {
       for (npt=ntpnt; npt; npt=npt->ntpnt) {        /* save nt list */
          fprintf (sfil,"cn    %4d c %.8g\n",npt->ctype,npt->val);
       } 
    }
  } /* for (cpnt;;) */
  fprintf (sfil,"#  \n");
 } /* if (cumcomp>0) */

 if (cumchan > 0) {
  fprintf (sfil,"# kchannels ctype stype num conduct vrev nchan numstate states \n");
  for (chpnt=chanpnt; chpnt; chpnt=(chan*)chpnt->next) {         /* channels */
    fprintf (sfil,"c typ %d %d n %d g %.16g vr %.16g nch %g st %d ", 
			chpnt->ctype,chpnt->stype,
			chpnt->num,chpnt->conduct,chpnt->vrev,
			chpnt->nchan, chpnt->numstate);
    if (chpnt->chtyp->hh) {
      fprintf (sfil,"m %.16g h %.16g ",((hhchan*)chpnt)->m, ((hhchan*)chpnt)->h); /* HH */
    } 
    if (chpnt->cstate!=NULL) {
	 int rndsiz=RNDSIZ/sizeof(int);
      fprintf (sfil,"rn(%d) ",rndsiz); 			/* rng state */
      for (i=0; i<rndsiz; i++) {
        fprintf (sfil,"%d ",*((int *)&chpnt->cstate[i*sizeof(int)]));
      }
    }
    if (chpnt->nchan > 0) { 		/* if noise, print nchans in each state */
       for (i=0; i<chpnt->numstate; i++) {
	 fprintf (sfil,"%.16g %d ",chpnt->conc[i].cest,chpnt->conc[i].nchan);
       }
    } else {				/* no noise, don't print out nchan */
       for (i=0; i<chpnt->numstate; i++) {
	 fprintf (sfil,"%.16g ",chpnt->conc[i].cest);
       }
    }
    fprintf (sfil,"\n");
  }
  fprintf (sfil,"#\n");
 }

 if (cumsynap > 0 || cumgj > 0 || cumdbuf) {
  fprintf (sfil,"# synapses num conduct 1 1h 2 3\n");
  for (spnt=synpnt; spnt; spnt=(synap *)spnt->next) {      /* save synapses */

   switch (spnt->ctype) {

    case SYNAPSE:
    fprintf (sfil,"s    %4d %.16g %.8g %.8g %d %.8g ",
			spnt->num,spnt->conduct,
			spnt->vtint,spnt->vtime,spnt->vflag,
			spnt->rrpool);

    if (spnt->vstate!=NULL) {
	 int rndsiz=RNDSIZ/sizeof(int);
      fprintf (sfil,"vt(%d) ",rndsiz); 			/* ves timing rng state */
      for (i=0; i<rndsiz; i++) {
        fprintf (sfil,"%d ",*((int *)&spnt->vstate[i*sizeof(int)]));
      }
    }
    if (spnt->gstate!=NULL) {
	 int rndsiz=RNDSIZ/sizeof(int);
      fprintf (sfil,"vs(%d) ",rndsiz); 			/* ves size rng state */
      for (i=0; i<rndsiz; i++) {
        fprintf (sfil,"%d ",*((int *)&spnt->gstate[i*sizeof(int)]));
      }
    }
    fprintf (sfil,"\n");  				/* end of first line */
    if (lpf=spnt->filt1) {
       fprintf (sfil,"sfa  %4d",lpf->nfilt);
       for (i=0; i<lpf->nfilt; i++) {
            fprintf (sfil," %.8g",lpf->lfilt[i]);
       } 
       fprintf (sfil,"\n");
    }
    if (lpf=spnt->filt1h) {
       fprintf (sfil,"sfah %4d",lpf->nfilt);
       for (i=0; i<lpf->nfilt; i++) {
            fprintf (sfil," %.8g",lpf->lfilt[i]);
       } 
       fprintf (sfil,"\n");
    }
    if (lpf=spnt->filt2) {
       fprintf (sfil,"sfb  %4d",lpf->nfilt);
       for (i=0; i<lpf->nfilt; i++) {
            fprintf (sfil," %.8g",lpf->lfilt[i]);
       } 
       fprintf (sfil,"\n");
    }
    if (lpf=spnt->filt3) {
       fprintf (sfil,"sfc  %4d",lpf->nfilt);
       for (i=0; i<lpf->nfilt; i++) {
            fprintf (sfil," %.8g",lpf->lfilt[i]);
       } 
       fprintf (sfil,"\n");
    }
    break;

    case GJ:
     fprintf (sfil,"g    %4d %.16g %.8g\n", spnt->num,spnt->conduct,((gj*)spnt)->n);
    break;

    case BUF:
     gain = ((dbuf *)spnt)->gain;
     offset = ((dbuf *)spnt)->offset;
     v = ((dbuf *)spnt)->v;
     delay = int(((dbuf *)spnt)->delay);
     if ((lpf=((dbuf*)spnt)->filt)!=NULL) 
           nf = lpf->nfilt;
     else  nf = 0; 
     fprintf (sfil,"b    %4d %.8g %.8g %.8g %d %d", spnt->num, gain, offset, v, delay, nf);
     if (delay > 0) {
       fprintf (sfil," %ld", (long int)(((dbuf *)spnt)->delpnt));
       for (i=0; i<delay; i++) {
	 fprintf (sfil," %.8g",((dbuf *)spnt)->delbuf[i]);
       }
     }
     if (nf > 0) {
       for (i=0; i<nf; i++) {
            fprintf (sfil," %.8g",lpf->lfilt[i]);
       } 
     }
     fprintf (sfil,"\n");
    break;

   } /* switch (spnt->ctype) */
  }
  fprintf (sfil,"#\n");
 }

 if (cumphotrec > 0) {
  fprintf (sfil,"# photoreceptors node(4) conduct rhod rhodk rstar gpr pde cycg gcyc cond ca cax ksens\n");
  for (rpnt=recpnt; rpnt; rpnt=(photrec *)rpnt->next) {    /* save photorecs */
      fprintf (sfil,"p %-d %-d %-d %-d %-.9g %-.9g %-.9g %-.9g %-.9g %-.9g %-.9g %-.9g %-.9g %-.9g %-.9g %-.9g %-.9g %-.9g %-.9g %-.9g %-.9g %-.9g %-.9g %-.9g %-.9g\n",
	(rpnt->recnm1<0?-1:rpnt->recnm1),
	(rpnt->recnm2<0?-1:rpnt->recnm2),
	(rpnt->recnm3<0?-1:rpnt->recnm3),
	(rpnt->recnm4<0?-1:rpnt->recnm4),
	rpnt->conduct,
	rpnt->rhod,
	rpnt->rhodk,
	rpnt->rhod2,
	rpnt->rstar,
	rpnt->gpr,
	rpnt->pde,
	rpnt->cycg,
	rpnt->gcyc,
	rpnt->cond,
	rpnt->ca,
	rpnt->cax,
	rpnt->cab,
	rpnt->ksens,
	rpnt->resp_r,
	rpnt->resp_b,
	rpnt->resp_e,
	rpnt->resp_x,
	rpnt->resp_c,
	rpnt->resp_is,
	rpnt->atten_i
	);
  }
  fprintf (sfil,"#\n");
 }
 fclose(sfil);
} /* savemodel */

/*---------------------------------------*/

char *scantoken (char *cp, int n)

/* find n'th text token */

{
    int i;
    char *np;

  for (i=0; i<n; i++) {
     np = strtok (cp," ,\t\n");
     cp = NULL;
  }
  return np;
}

/*---------------------------------------*/

#define INBUFSIZ 4000

void restoremodel (const char *filnam)

/* restore all state variables from a file */

{
   int i, caoshell, compnum, n, npl, nf, ntype, snum, chnum;
   int tcomps, tchans, tsyns, tphotrecs;
   int vflag, delay;
   int cashell, cabfl;
   int ctype, stype, numstate;
   long int bpnt;
   size_t inbufsiz=INBUFSIZ;
   double gain;
   double offset, v; 
   double cais,cab;
   double val, scond, gjfrac,rrpool,vtint,vtime;
   double compv, oldv, relax;
   double nchan, chcond, vrev;
   int recnm1, recnm2, recnm3, recnm4;
   comp *cpnt,*tcpnt;
   FILE *sfil;
   static char *inbuf;
   cacomp *capnt;
   ntcomp *ntpnt,*npt;
   synap *spnt,*tspnt;
   lpfilt *lpf;
   photrec *rpnt;
   chan *chpnt;
   char *cp;

  if (!(sfil=fopen(filnam,"r"))) {
    sprintf (ebuf,"restoremodel: can't open file '%.50s'.\n",filnam);
    execerror ("warning,",ebuf);
    return; 
  }

  if (!(inbuf = (char *)emalloc (INBUFSIZ))) {
     ncfprintf (stderr,"Error, restoremodel: can't allocate line buffer\n");
     return;
  }

  tcomps = tchans = tsyns = tphotrecs = 0;
  for (npl=0; getline(&inbuf,&inbufsiz,sfil)>0; npl++) {		/* scan file */

   if (inbuf[0]=='#')  {				/* comps, synapses, photrecs */
     switch (inbuf[2])  {

      case ' ':	break;

      case 'c':						/* found "# compartments */
       if ((cpnt=compnt)==NULL) break;
       for (; getline(&inbuf,&inbufsiz,sfil)>0; npl++) {
          if (inbuf[0]=='#') break;  			/* stop at last comps */
          switch (inbuf[0])  {

         case 'c':					/* comp line */
           switch (inbuf[1])  {
            case ' ':					/* compartment */
            sscanf(inbuf,"c %d %lg %lg %lg",&compnum,&compv,&oldv,&relax);
	    if (cpnt->num != compnum) {			/* if not in correct order */
	       cpnt=findcomp(compnum,"restore_model");
	    }
	    if (cpnt!=NULL) {
		cpnt->v     = compv;
		cpnt->oldv  = oldv;
		cpnt->relax = relax;
		tcpnt = cpnt;				/* save ptr for calcium, nt */
	        cpnt = cpnt->next;			/* fast way of finding next comp */
		if (cpnt==NULL) cpnt=compnt;
		tcomps++;
	    }
 	    break;

            case 'a':		/* "ca" line */
	      if ((capnt=tcpnt->capnt)!=NULL) {
                n = sscanf(inbuf,"%*s vr %lg sh %d b %d",&vrev,&cashell,&cabfl); 
		capnt->vrev = vrev;
		cp=scantoken(inbuf,8);			/* find 8th token */
		if ((cashell<=capnt->cashell) && capnt->cais!=NULL) {
		  if (cabfl) {
		    for (i=0; i<cashell; i++) {
    		      if (cp==NULL) {
			sprintf (ebuf,"restoremodel: error in comp %d reading (buf) caicomp: %d.\n",compnum,i);
     	                execerror ("warning,",ebuf);
		      }
                      capnt->cais[i] = atof(cp);
		      cp=scantoken(NULL,1);
		      capnt->cab[i] = atof(cp); 
		      cp=scantoken(NULL,1);
		    }
		  } else {
		    for (i=0; i<cashell; i++) { 
    		      if (cp==NULL) {
			sprintf (ebuf,"restoremodel: error in comp %d reading caicomp: %d.\n",compnum,i);
     	                execerror ("warning,",ebuf);
		      }
                      capnt->cais[i] = atof(cp);
		      // fprintf (stderr,"%g\n",capnt->cais[i]);
		      cp=scantoken(NULL,1);
		    }
		  }
                  // n = sscanf(inbuf,"%*s sh %d",&caoshell); 
		  cp=scantoken(NULL,2);			/* skip "cao sh" */
                  caoshell = atof(cp);
		  cp=scantoken(NULL,1);			/* get caoshell */
		  if ((caoshell<=capnt->caoshell) && (capnt->caos!=NULL)) {
		    cp=scantoken(NULL,1);			/* get cao number */
		    for (i=0; i<caoshell; i++) {
    		      if (cp==NULL) {
			sprintf (ebuf,"restoremodel: error reading caocomp: %d.\n",i);
     	                execerror ("warning,",ebuf);
		      }
                      capnt->caos[i] = atof(cp);
		      cp=scantoken(NULL,1); 			/* get cao number */
		    }
		  }
                  capnt->cas = atof(cp);			/* get CICR Ca store */
		  cp=scantoken(NULL,1);
                  capnt->cas2 = atof(cp);
		  cp=scantoken(NULL,1);
		}
	      }
 	    break;

            case 'n':		/* "cn" line */
	      if ((ntpnt=tcpnt->ntpnt)!=NULL) {
	        if (sscanf(inbuf,"%*s %d c %lg\n",&ntype,&val) ==2) {
		   while (ntpnt->ctype!=ntype) {
		     ntpnt=ntpnt->ntpnt;
		     if (ntpnt==NULL) break;
		   }
		   if (ntpnt!=NULL) {
		     ntpnt->val = val;			/* set nt conc */
		   }
	        }
	      }
 	    break;
	    default: break;
	  
	      }   /* switch (inbuf[1]) */
 	    break;
	    default: break;
	   }  /* switch (inbuf[0]) */
          }  /* for all comp lines */
      break;  /* " compartment c?" */

      case 'k':						/* found "# kchannels" */
       if ((chpnt=chanpnt) == NULL) {
    	 sprintf (ebuf,"restoremodel: no channels\n");
     	 execerror ("warning,",ebuf);
       }
       for (; getline(&inbuf,&inbufsiz,sfil)>0; npl++) {
        if (inbuf[0]=='#') break;  			/* stop at last chans */
        switch (inbuf[0])  {

         case 'c':					/* chan */
	    n = sscanf (inbuf,"%*s %*s %d %d n %d g %lg vr %lg nch %lg st %d ", 
			&ctype, &stype, &chnum, &chcond, &vrev, &nchan, &numstate);
	    if (n != 7) {
    		sprintf (ebuf,"restoremodel: can't read channel.\n",filnam);
     	        execerror ("warning,",ebuf);
		return;
	    }
	    if (chpnt->num!=chnum) {
	      for (chpnt=chanpnt; chpnt; chpnt=(chan*)chpnt->next)          /* channels */
		if (chpnt->num==chnum) break;
	      if (chpnt==NULL) {
	         ncfprintf (stderr,"restoremodel, can't find chan %d\n",chnum);
     	         execerror ("warning,","can't find chan");
		return;
	      }
	    }
	    chpnt->conduct = chcond;
	    chpnt->vrev    = vrev;
	    tchans++;
	    cp = scantoken (inbuf,15);			/* find 15th token */
	    if (chpnt->chtyp->hh) {
		cp=scantoken(NULL,1);
                ((hhchan *)chpnt)->m  = atof(cp);
		cp=scantoken(NULL,2);
                ((hhchan *)chpnt)->h  = atof(cp);
		cp=scantoken(NULL,1);
	    }
	    if (chpnt->cstate!=NULL) {			/* rng state */
		int rndsiz=RNDSIZ/sizeof(int);
	      cp=scantoken(NULL,1);			/* skip over "rn" */
	      for (i=0; i<rndsiz; i++) {
		*((int *)&chpnt->cstate[i*sizeof(int)]) = atoi(cp);
		cp=scantoken(NULL,1);
	      }
	    }
	    if (chpnt->nchan > 0) {			/* channel noise */
              for (i=0; i<numstate; i++) {
		if (cp==NULL) {
		    sprintf (ebuf,"restoremodel: error reading channel state: %d.\n",i);
     	            execerror ("warning,",ebuf);
		    return;
		}
                chpnt->conc[i].cval  = atof(cp);
		cp=scantoken(NULL,1);
                chpnt->conc[i].nchan = int(atof(cp));
		cp=scantoken(NULL,1);
	      }
	    }
	    else {					/* no channel noise */
              for (i=0; i<numstate; i++) {
		if (cp==NULL) {
		    sprintf (ebuf,"restoremodel: error reading channel state: %d.\n",i);
     	            execerror ("warning,",ebuf);
		    return;
		}
                chpnt->conc[i].cest  = atof(cp);
		cp=scantoken(NULL,1);
	      }
	    }
	    chpnt = (chan *)chpnt->next;
	 break;
	default: break;

  	}  /* switch (inbuf[0]) */
       } /* for all chan lines */
       break;

      case 's':						/* found "# synapses" */
       if ((spnt=synpnt) == NULL) {
    	  sprintf (ebuf,"restoremodel: no synapses\n");
     	  execerror ("warning,",ebuf);
       }
       for (; getline(&inbuf,&inbufsiz,sfil)>0; npl++) {
        if (inbuf[0]=='#') break;  			/* stop at last synapse */
        switch (inbuf[0])  {

         case 'b':					/* voltage buffer */
            sscanf(inbuf,"b  %d %lg %lg %lg %d %d",&snum,&gain,&offset,&v,&delay,&nf);
	    if (spnt==NULL || spnt->ctype!=BUF || spnt->num!=snum) {
               for (spnt=synpnt; spnt; spnt=(synap *)spnt->next) 
		if (spnt->ctype==BUF && spnt->num==snum) break;
	      if (spnt==NULL) 
		ncfprintf (stderr,"restoremodel, can't find buf %d\n",snum);
	    } 
	    ((dbuf *)spnt)->gain   = gain;
	    ((dbuf *)spnt)->offset = offset;
	    ((dbuf *)spnt)->v      = v;

		/* look for delay buf */

            if (delay>0) {
	      sscanf(inbuf," %ld",&bpnt); 
	      ((dbuf *)spnt)->delpnt  = (double *)bpnt;
	      ((dbuf *)spnt)->delay  = delay;
	      cp = scantoken (inbuf,9);			/* find 9th token */
	      for (i=0; i<delay; i++) { 
	        ((dbuf *)spnt)->delbuf[i] = atof(cp);
	        cp=scantoken(NULL,1);
	      }
	    }
		/* look for lp filter */

            if (nf >= 1) {
 	      if ((lpf=((dbuf*)spnt)->filt)!=NULL) {
	        if (nf > lpf->nfilt) {
    	  	  sprintf (ebuf,"restoremodel: synapse filter too big: %d.\n",nf);
     	          execerror ("warning,",ebuf);
		  return;
	        }
	  	for (i=0; i<nf; i++) {
		  if (cp==NULL) {
		       sprintf (ebuf,"restoremodel: error reading synapse filter: %d.\n",i);
     	               execerror ("warning,",ebuf);
		  }
                  lpf->lfilt[i]  = atof(cp);
		  cp=scantoken(NULL,1);
		}
	      }
	    }
	    tsyns++;
	    spnt = (synap *)spnt->next;			/* fast way of finding next synap */
	    if (spnt==NULL) spnt = synpnt;
	    break;

         case 'g':					/* gap junction */
            sscanf(inbuf,"g  %d %lg %lg",&snum,&scond,&gjfrac);
	    if (spnt==NULL || spnt->ctype!=GJ || spnt->num!=snum) {
               for (spnt=synpnt; spnt; spnt=(synap *)spnt->next) 
		if (spnt->ctype==GJ && spnt->num==snum) break;
	      if (spnt==NULL) 
		ncfprintf (stderr,"restoremodel, can't find gj %d\n",snum);
	    } 
	    spnt->conduct  = scond;
	    ((gj*)spnt)->n = gjfrac;
	    tsyns++;
	    spnt = (synap *)spnt->next;			/* fast way of finding next synap */
	    if (spnt==NULL) spnt = synpnt;
	    break;

         case 's':					/* synapse */
           switch (inbuf[1])  {

            case ' ':				/* s num conduct vting time vflag rrpool */
            sscanf(inbuf,"s %d %lg %lg %lg %d %lg",&snum,&scond,&vtint,&vtime,&vflag,&rrpool);
	    if (spnt==NULL || spnt->num!=snum) {
               for (spnt=synpnt; spnt; spnt=(synap *)spnt->next) 
		if (spnt->num==snum) break;
	      if (spnt==NULL) 
		ncfprintf (stderr,"restoremodel, can't find synapse %d\n",snum);
	    } 
	    spnt->conduct = scond;
	    spnt->vtint   = vtint;
	    spnt->vtime   = vtime;
	    spnt->vtime   = vflag;
	    spnt->rrpool  = rrpool;
	    tsyns++;
	    cp = scantoken (inbuf,8);			/* find 8th token */
	    if (spnt->vstate!=NULL) {			/* ves timing rng state */
		int rndsiz=RNDSIZ/sizeof(int);
	      cp=scantoken(NULL,1);			/* skip over "vt" */
	      for (i=0; i<rndsiz; i++) {
		*((int *)&spnt->vstate[i*sizeof(int)]) = atoi(cp);
		cp=scantoken(NULL,1);
	      }
	    }
	    if (spnt->gstate!=NULL) {			/* ves size rng state */
		int rndsiz=RNDSIZ/sizeof(int);
	      cp=scantoken(NULL,1);			/* skip over "vs" */
	      for (i=0; i<rndsiz; i++) {
		*((int *)&spnt->gstate[i*sizeof(int)]) = atoi(cp);
		cp=scantoken(NULL,1);
	      }
	    }
	    tspnt = spnt;
	    spnt = (synap *)spnt->next;			/* fast way of finding next synap */
	    if (spnt==NULL) spnt = synpnt;
 	    break;

            case 'f':		/* "sf" */
              switch (inbuf[2])  {
		case 'a':		/* "sfa" */
		 if      (inbuf[3]==' ') lpf=tspnt->filt1;
		 else if (inbuf[3]=='h') lpf=tspnt->filt1h;
		 break;
		case 'b':		/* "sfb" */
		 if (inbuf[3]==' ')      lpf=tspnt->filt2;
		 break;
		case 'c':		/* "sfc" */
		 if (inbuf[3]==' ')      lpf=tspnt->filt3;
		 break;
		default: break;
	      } /* switch (inbuf[2]) */
	      if (lpf==NULL) break;
              if (sscanf(inbuf,"%*s %d",&nf) == 1) {
	        if (nf > lpf->nfilt) {
    		  sprintf (ebuf,"restoremodel: synapse filter too big: %d.\n",nf);
     	          execerror ("warning,",ebuf);
		  return;
		}
	        cp = scantoken (inbuf,3);	/* find 3rd token */
		for (i=0; i<nf; i++) {
		  if (cp==NULL) {
		     sprintf (ebuf,"restoremodel: error reading synapse filter: %d.\n",i);
     	             execerror ("warning,",ebuf);
		  }
                  lpf->lfilt[i]  = atof(cp);
		  cp=scantoken(NULL,1);
		}
	      }
 	     break;
	     default: break;
	     } /* switch (inbuf[1]) */
 	    break;
	    default: break;
	  } /* switch (inbuf[0]) */
	} /* for getline() */

      break;  /* synapses */

      case 'p':					/* photoreceptors */
       if ((rpnt=recpnt)==NULL) {
    	  sprintf (ebuf,"restoremodel: no synapses\n");
     	  execerror ("warning,",ebuf);
	  break;
       }
       for (; getline(&inbuf,&inbufsiz,sfil)>0; npl++) {
         if (inbuf[0]=='#') break;  			/* stop at last comps */
         switch (inbuf[0])  {

          case 'p':					/* chan */
           sscanf(inbuf,"%*s  %d %d %d %d ", &recnm1, &recnm2, &recnm3, &recnm4);
	   if (rpnt->recnm1 != recnm1 &&
	       rpnt->recnm2 != recnm2 &&
	       rpnt->recnm3 != recnm3 &&
	       rpnt->recnm4 != recnm4 ) {
		   findphotrec(recnm1,recnm2,recnm3,recnm4,&rpnt,"restoremodel");
	   }
            sscanf(inbuf,"%lg %lg %lg %lg %lg %lg %lg %lg %lg %lg %lg %lg %lg %lg %lg %lg %lg %lg %lg %lg %lg\n",
		&rpnt->conduct,
		&rpnt->rhod,
		&rpnt->rhodk,
		&rpnt->rhod2,
		&rpnt->rstar,
		&rpnt->gpr,
		&rpnt->pde,
		&rpnt->cycg,
		&rpnt->gcyc,
		&rpnt->cond,
		&rpnt->ca,
		&rpnt->cax,
		&rpnt->cab,
		&rpnt->ksens,
		&rpnt->resp_r,
		&rpnt->resp_b,
		&rpnt->resp_e,
		&rpnt->resp_x,
		&rpnt->resp_c,
		&rpnt->resp_is,
		&rpnt->atten_i);
		tphotrecs++;
          break;  /* one photoreceptor line */
	  default: break;

         }  /* switch (inbuf[0]); */
       }  /* for all photoreceptor lines */
       break;
       default: break;
     }  /* switch (inbuf[2])  looking for # comps, # syns, # photrecs, # kchans, etc */
   } /* if (inbuf[0])=='#') */
  }
  // if (tcomps!=cumcomp || 
  //     tchans!=cumchan || 
  //      tsyns!=cumsynap+cumgj+cumdbuf || 
  //  tphotrecs!=cumphotrec) {
  //    fprintf (stderr,"# restore model: comps=%d chans=%d syns=%d photrecs=%d\n",
  //		tcomps, tchans, tsyns, tphotrecs);
  // }
 fclose(sfil);
}

