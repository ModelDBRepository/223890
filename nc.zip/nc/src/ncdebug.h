
#define NCBASE    1
#define NCCONVERT 2
#define NCELEM    4
#define NCMAK     8
#define NCOMP     0x10
#define NCOMPCA   0x20
#define NCSTIM    0x40
#define NCPHOT    0x80
#define NCPLOT    0x100
#define NCRECORD  0x200
#define NCPRCOMP  0x400
#define NCDISP    0x800
#define NOCOND    0x1000

