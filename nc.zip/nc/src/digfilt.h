

void init_digfilt  (double init_val, double tau, double timestep);
void init_digfilt2 (double init_val, double tau, double timestep);

double digfilt  (double val);
double digfilt2 (double val);

