/* ncval.h */

/* defaults for command-line args */

#define VVSIZE 100			/* number of command line var sets */

#define LINEWIDTH .001			/* line width for ncdisp.c */
#define CHARSIZ .018			/* size of char for plot labels */

