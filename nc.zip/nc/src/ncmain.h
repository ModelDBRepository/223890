#ifndef _NCMAIN_H_
#define _NCMAIN_H_

int ncmain(int argc, char **argv);

#endif //_NCMAIN_H_
