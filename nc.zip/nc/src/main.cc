#include "ncmain.h"

int main(int argc, char **argv)
{
  return ncmain(argc, argv);
}

void setptrs(void)
{}


