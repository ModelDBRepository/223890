
/* ncsetvar.h */
/* Used to set type of variables from command line */

#define VINT 0
#define VFLOAT 1
#define VDOUBLE 2
#define VNUMBER 3
#define VSTRING 4

